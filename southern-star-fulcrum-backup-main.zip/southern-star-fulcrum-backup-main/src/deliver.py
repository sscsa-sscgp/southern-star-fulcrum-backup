"""Deliver one staged cycle to the landing zone (SFTP).

The contract with Southern Star's ingestion:

  * one folder per cycle, named like the local cycle folder -- the same names
    in UAT and Production;
  * every file is uploaded as <name>.part and renamed once its size checks
    out, so a half-written file never appears under its real name;
  * _SUCCESS goes last, only after every file has been verified on the
    server. Ingestion must only read folders that have it.

Safe to re-run. A folder that already has _SUCCESS is left alone. A folder
left behind by an interrupted delivery is resumed: files already there at the
right size are kept, anything else is re-sent. Files in that folder that the
cycle doesn't list are never touched -- we don't delete what we didn't create.

Attachment files sit in the cycle's attachments/ subfolder, created on the
landing zone like the cycle folder itself. Once _SUCCESS is up, the
landing zone's attachment state records them (src/attachments.py), so the
next cycle doesn't send them again.
"""

import csv
import json
import os
import posixpath
from dataclasses import dataclass, field
from datetime import datetime, timezone

from src.attachments import INDEX_NAME, AttachmentStateError, basis_problem, record_delivery
from src.export import MANIFEST_NAME, SCHEMA_NAME, SUCCESS_NAME, long_path
from src.sftp_client import UploadError

#: Local record that a cycle reached an environment: <cycle>/.delivered-<env>.json.
#: A dot-file, so it is never uploaded itself.
MARKER_PREFIX = ".delivered-"

#: <cycle>/.dry-run: the cycle was made by `run --dry-run`, which never uploads.
#: deliver skips it, and staging cleanup treats it as disposable.
DRY_RUN_MARKER = ".dry-run"


class DeliveryError(Exception):
    """The local cycle cannot be delivered as it stands. Nothing was sent."""


@dataclass
class DeliveryResult:
    cycle: str
    env: str
    remote_path: str
    started_at: datetime
    finished_at: datetime | None = None
    uploaded: list = field(default_factory=list)        # sent this run
    kept: list = field(default_factory=list)            # already there, right size
    unknown_remote: list = field(default_factory=list)  # in the folder, not ours
    bytes_sent: int = 0
    already_delivered: bool = False
    attachments_recorded: int = 0   # NEW attachments noted in the landing zone's state
    state_path: str = ""


def local_file(cycle_path, name):
    """Local path of a cycle file. Manifest names use '/', as on the server."""
    return long_path(os.path.join(cycle_path, *name.split("/")))


def cycle_files(cycle_path):
    """The files a delivery sends before _SUCCESS, in order: every table and
    attachment file the manifest lists as OK, then _ATTACHMENTS.csv and
    _SCHEMA.csv (when present), then _MANIFEST.csv."""
    if not os.path.isfile(os.path.join(cycle_path, SUCCESS_NAME)):
        raise DeliveryError(f"{cycle_path} has no {SUCCESS_NAME}: its export did not complete, so it is not delivered")
    manifest = os.path.join(cycle_path, MANIFEST_NAME)
    if not os.path.isfile(manifest):
        raise DeliveryError(f"{cycle_path} has {SUCCESS_NAME} but no {MANIFEST_NAME}")
    with open(manifest, newline="", encoding="utf-8") as fh:
        listed = [row["file"] for row in csv.DictReader(fh) if row.get("status") == "OK" and row.get("file")]
    files = listed + [name for name in (INDEX_NAME, SCHEMA_NAME) if os.path.isfile(os.path.join(cycle_path, name))]
    files.append(MANIFEST_NAME)
    missing = [name for name in files if not os.path.isfile(local_file(cycle_path, name))]
    if missing:
        raise DeliveryError(f"{len(missing)} file(s) listed in the manifest are missing locally: {', '.join(missing[:5])}")
    return files


def marker_path(cycle_path, env):
    return os.path.join(cycle_path, f"{MARKER_PREFIX}{env}.json")


def is_delivered(cycle_path, env):
    return os.path.isfile(marker_path(cycle_path, env))


def find_cycle(staging_root, env):
    """The newest complete cycle in staging not yet delivered to env, or None."""
    if not os.path.isdir(staging_root):
        return None
    candidates = []
    for name in os.listdir(staging_root):
        path = os.path.join(staging_root, name)
        success = os.path.join(path, SUCCESS_NAME)
        if (os.path.isfile(success) and not is_delivered(path, env)
                and not os.path.isfile(os.path.join(path, DRY_RUN_MARKER))):
            candidates.append((os.path.getmtime(success), path))
    return max(candidates)[1] if candidates else None


def _write_marker(cycle_path, result):
    record = {
        "env": result.env,
        "remote_path": result.remote_path,
        "delivered_at": result.finished_at.isoformat(),
        "already_delivered": result.already_delivered,
        "files_sent": len(result.uploaded),
        "files_kept": len(result.kept),
        "bytes_sent": result.bytes_sent,
        "attachments_recorded": result.attachments_recorded,
    }
    with open(marker_path(cycle_path, result.env), "w", encoding="utf-8") as fh:
        json.dump(record, fh, indent=2)


def _remote_files(landing, remote, subdirs):
    """{relative name: size} for the cycle folder and its subfolders, or None
    if the cycle folder doesn't exist. A missing subfolder lists as empty."""
    top = landing.listing(remote)
    if top is None:
        return None
    files = dict(top)
    for sub in subdirs:
        listing = landing.listing(posixpath.join(remote, sub)) or {}
        files.update({f"{sub}/{name}": size for name, size in listing.items()})
    return files


def _finish(cycle_path, result, state_dir):
    result.finished_at = datetime.now(timezone.utc)
    if state_dir:
        try:
            result.attachments_recorded, result.state_path = record_delivery(cycle_path, result.env, state_dir)
        except AttachmentStateError as exc:
            # No marker either, so the next `deliver` finds the folder's
            # _SUCCESS, calls it delivered, and records the files then.
            raise AttachmentStateError(
                f"{result.cycle} IS delivered to {result.env.upper()} (_SUCCESS is on the server), but its "
                f"attachments could not be recorded: {exc}. Until they are, the next cycle sends them again, "
                f"which is harmless") from exc
    _write_marker(cycle_path, result)
    return result


def deliver_cycle(landing, cycle_path, remote_root, env, log=print, verbose=False, state_dir=None):
    """Deliver cycle_path into <remote_root>/<cycle folder> on an open Landing.

    state_dir is where the attachment state lives. Without it the landing
    zone's state isn't updated, and the next cycle re-sends these files.
    """
    files = cycle_files(cycle_path)
    if os.path.isfile(os.path.join(cycle_path, DRY_RUN_MARKER)):
        raise DeliveryError(f"{os.path.basename(os.path.normpath(cycle_path))} was made by a dry run, which never "
                            f"uploads. Run without --dry-run to make a backup that is delivered")
    problem = basis_problem(cycle_path, env)
    if problem:
        raise DeliveryError(f"{os.path.basename(os.path.normpath(cycle_path))} can't go to {env.upper()}: {problem}")
    folder = os.path.basename(os.path.normpath(cycle_path))
    remote = posixpath.join(landing.resolve(remote_root or "."), folder)
    result = DeliveryResult(cycle=folder, env=env, remote_path=remote, started_at=datetime.now(timezone.utc))
    subdirs = sorted({posixpath.dirname(name) for name in files if "/" in name})

    existing = _remote_files(landing, remote, subdirs)
    if existing is not None and SUCCESS_NAME in existing:
        # Delivered before (maybe from another machine). Leave it exactly as is.
        result.already_delivered = True
        return _finish(cycle_path, result, state_dir)
    if existing is None:
        landing.ensure_dir(remote)
        existing = {}
    for sub in subdirs:
        if sub not in existing:
            landing.ensure_dir(posixpath.join(remote, sub))

    expected = set(files) | {SUCCESS_NAME} | set(subdirs)
    # Our own leftover .part files are simply overwritten by the re-upload.
    result.unknown_remote = sorted(name for name in existing if name not in expected and not name.endswith(".part"))

    for index, name in enumerate(files, start=1):
        local = local_file(cycle_path, name)
        if existing.get(name) == os.path.getsize(local):
            result.kept.append(name)
            continue
        sent = landing.upload(local, posixpath.join(remote, name), replace=name in existing)
        result.uploaded.append(name)
        result.bytes_sent += sent
        if verbose:
            log(f"  [{index}/{len(files)}] {name} -- {sent} bytes")

    # Check everything on the server before blessing the folder with _SUCCESS.
    final = _remote_files(landing, remote, subdirs) or {}
    wrong = [name for name in files if final.get(name) != os.path.getsize(local_file(cycle_path, name))]
    if wrong:
        raise UploadError(f"{len(wrong)} file(s) missing or the wrong size on the server: {', '.join(wrong[:5])}")

    result.bytes_sent += landing.upload(local_file(cycle_path, SUCCESS_NAME), posixpath.join(remote, SUCCESS_NAME))
    result.uploaded.append(SUCCESS_NAME)
    return _finish(cycle_path, result, state_dir)
