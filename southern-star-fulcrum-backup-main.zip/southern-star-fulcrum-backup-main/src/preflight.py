"""Install-time preflight: checks one by one that this machine can run the
backup, with PASS / FAIL / WARN / SKIP per item (python -m src.main preflight).

Read-only throughout: it reads from Fulcrum, logs in to the SFTP and lists
the landing directory, and asks the SMTP relay whether it would take the
alert (MAIL FROM / RCPT TO, then reset). Nothing is uploaded and no email is
sent. A check whose settings are still Southern Star placeholders is
skipped, not failed, so the rest still tell you something.
"""

import os
import smtplib
import socket
import sys
import uuid
from dataclasses import dataclass

import requests

from src import alerts
from src.config import SECRET_ENV_OVERRIDES, dig, is_placeholder, placeholders
from src.fulcrum_client import FulcrumAuthError, FulcrumClient, FulcrumError, FulcrumUnavailable
from src.naming import Namer, NamingError
from src.sftp_client import LandingError, connect

DEFAULT_CONTENT_HOST = "content.fulcrumapp.com"


@dataclass
class Check:
    status: str   # PASS, FAIL, WARN, SKIP
    item: str
    detail: str = ""


def _writable(path):
    os.makedirs(path, exist_ok=True)
    probe = os.path.join(path, f".preflight-{uuid.uuid4().hex}")
    with open(probe, "w", encoding="utf-8") as fh:
        fh.write("ok")
    os.remove(probe)


def run_checks(config, env, folders, base_dir, client_factory=None, http_get=None, smtp=None, smtp_ssl=None):
    """Every check, in order. folders maps a label to a local path. The
    factories default to the real Fulcrum client, requests and smtplib."""
    client_factory = client_factory or FulcrumClient
    http_get = http_get or requests.get
    smtp, smtp_ssl = smtp or smtplib.SMTP, smtp_ssl or smtplib.SMTP_SSL
    checks = []
    add = lambda status, item, detail="": checks.append(Check(status, item, detail))  # noqa: E731

    # -- placeholders and local setup ----------------------------------------
    pending = placeholders(config, env)
    if pending:
        add("FAIL", "placeholders", f"{len(pending)} value(s) still to fill in: " + ", ".join(k for k, _ in pending))
    else:
        add("PASS", "placeholders", "none left")

    version = sys.version_info
    add("PASS" if version >= (3, 11) else "FAIL", "python", f"{version.major}.{version.minor}.{version.micro}"
        + ("" if version >= (3, 11) else " -- 3.11 or newer is required"))

    try:
        namer = Namer(dig(config, "naming") or {})
        add("PASS", "timezone", f"{namer.tz.key}, so cycles are named in Central time")
    except NamingError as exc:
        add("FAIL", "timezone", str(exc))

    for label, path in folders.items():
        try:
            _writable(path)
            add("PASS", f"{label} folder", path)
        except OSError as exc:
            add("FAIL", f"{label} folder", f"{path} is not writable -- {exc}")

    expected_host = dig(config, "site.vm_hostname")
    if not expected_host or is_placeholder(expected_host):
        add("SKIP", "machine", "site.vm_hostname not filled in")
    elif expected_host.lower() == socket.gethostname().lower():
        add("PASS", "machine", socket.gethostname())
    else:
        add("WARN", "machine", f"this is {socket.gethostname()}, but site.vm_hostname says {expected_host}")

    install_path = dig(config, "site.install_path")
    if not install_path or is_placeholder(install_path):
        add("SKIP", "install path", "site.install_path not filled in")
    elif os.path.normcase(os.path.abspath(install_path)) == os.path.normcase(os.path.abspath(base_dir)):
        add("PASS", "install path", base_dir)
    else:
        add("WARN", "install path", f"the code runs from {base_dir}, but site.install_path says {install_path}")

    # -- Fulcrum --------------------------------------------------------------
    token = dig(config, "fulcrum.api_token")
    base_url = dig(config, "fulcrum.base_url") or "https://api.fulcrumapp.com"
    if not token or is_placeholder(token):
        add("FAIL", "Fulcrum API", "no token: set FULCRUM_API_TOKEN")
    else:
        if not os.environ.get(SECRET_ENV_OVERRIDES["fulcrum.api_token"]):
            add("WARN", "Fulcrum token", "read from the config file; set FULCRUM_API_TOKEN instead and leave "
                                         "fulcrum.api_token empty")
        client = client_factory(token, base_url=base_url, log=lambda *_: None)
        try:
            body = client.get_json("/api/v2/forms.json", params={"schema": "false", "per_page": 1})
            total = body.get("total_count")
            add("PASS", "Fulcrum API", f"{base_url} reachable, token accepted"
                + (f", {total} apps visible" if total is not None else ""))
            rows = client.query_rows("SELECT COUNT(*) AS n FROM tables")
            add("PASS", "Fulcrum Query API", f"{rows[0]['n']} tables")
        except FulcrumAuthError as exc:
            add("FAIL", "Fulcrum API", f"token rejected -- {exc}")
        except FulcrumUnavailable as exc:
            add("FAIL", "Fulcrum API", f"can't reach {base_url} on port 443 -- {exc}")
        except FulcrumError as exc:
            add("FAIL", "Fulcrum API", str(exc))

    content_host = dig(config, "fulcrum.content_host") or DEFAULT_CONTENT_HOST
    try:
        resp = http_get(f"https://{content_host}/", timeout=20)
        add("PASS", "attachment downloads", f"{content_host}:443 reachable (HTTP {resp.status_code}; any answer "
                                            f"is fine, real downloads use signed links)")
    except requests.exceptions.RequestException as exc:
        add("FAIL", "attachment downloads", f"can't reach {content_host} on port 443 -- {exc.__class__.__name__}: "
                                            f"{exc}. Allow it by host name: it runs on CloudFront, whose IPs change")

    # -- SFTP -----------------------------------------------------------------
    sftp_keys = ["sftp.host", "sftp.port", "sftp.host_key_fingerprint", f"sftp.accounts.{env}.username",
                 f"sftp.accounts.{env}.password", f"sftp.accounts.{env}.remote_dir"]
    pending_sftp = [key for key in sftp_keys if is_placeholder(dig(config, key))]
    if pending_sftp:
        add("SKIP", "SFTP", "still placeholders: " + ", ".join(pending_sftp))
    else:
        host, port = dig(config, "sftp.host"), int(dig(config, "sftp.port") or 22)
        remote_dir = dig(config, f"sftp.accounts.{env}.remote_dir") or "."
        try:
            with connect(host, port, dig(config, f"sftp.accounts.{env}.username"),
                         dig(config, f"sftp.accounts.{env}.password"), dig(config, "sftp.host_key_fingerprint"),
                         timeout=float(dig(config, "sftp.timeout_sec") or 20)) as landing:
                add("PASS", "SFTP login", f"{host}:{port} as {dig(config, f'sftp.accounts.{env}.username')}, "
                                          f"server key matches the pinned one")
                listing = landing.listing(remote_dir)
                if listing is None:
                    add("FAIL", "SFTP landing directory", f"{remote_dir!r} does not exist")
                else:
                    add("PASS", "SFTP landing directory", f"{landing.resolve(remote_dir)} ({len(listing)} entries)")
        except LandingError as exc:
            add("FAIL", "SFTP login", str(exc))

    # -- SMTP relay -----------------------------------------------------------
    try:
        alert = alerts.settings(config)
    except alerts.AlertConfigError as exc:
        add("SKIP" if "placeholders" in str(exc) else "FAIL", "SMTP relay", str(exc))
    else:
        if alert is None:
            add("FAIL", "SMTP relay", "alerts.smtp_host is not set, so no failure alert can be sent")
        else:
            try:
                problems = alerts.check_relay(alert, smtp=smtp, smtp_ssl=smtp_ssl)
            except (smtplib.SMTPException, OSError) as exc:
                add("FAIL", "SMTP relay", alerts.describe_error(exc, alert))
            else:
                if problems:
                    add("FAIL", "SMTP relay", f"{alert.host}:{alert.port} " + "; ".join(problems))
                else:
                    add("PASS", "SMTP relay", f"{alert.host}:{alert.port} accepts {alert.sender} -> "
                                              f"{', '.join(alert.recipients)} (nothing sent)")
    return checks
