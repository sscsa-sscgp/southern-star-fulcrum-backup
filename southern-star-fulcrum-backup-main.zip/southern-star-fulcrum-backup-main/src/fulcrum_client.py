"""Fulcrum API client -- read-only.

The backup never writes to Fulcrum, so there is deliberately no
write surface here, not even an unused one.

Authenticates with an API token sent as header `X-ApiToken` against
https://api.fulcrumapp.com. The token lives only in memory and only ever
travels as a header: never logged, never placed in a URL, where it would land
in server logs and shell history.
"""

import time

import requests

DEFAULT_BASE_URL = "https://api.fulcrumapp.com"

#: Statuses worth retrying. Every call here is a read, and reads are
#: idempotent, so a repeat is free. Any other 4xx means the request itself is
#: wrong, and retrying just repeats it.
RETRYABLE_STATUSES = frozenset({429, 500, 502, 503, 504})

#: Longest wait honoured from a Retry-After header, in seconds.
MAX_RETRY_WAIT = 60


class FulcrumError(Exception):
    """A Fulcrum API call failed in a way the caller cannot paper over."""


class FulcrumAuthError(FulcrumError):
    """401/403. Every later call would fail the same way, so the run stops."""


class FulcrumUnavailable(FulcrumError):
    """The API could not be reached at all, after retries. The run stops
    rather than grinding through every table's retries one by one."""


class FulcrumNotFound(FulcrumError):
    """HTTP 404: the thing asked for does not exist -- e.g. an attachment a
    record still references but Fulcrum no longer has."""


class QueryRejected(FulcrumError):
    """The Query API rejected the SQL itself (HTTP 400) -- typically because a
    table identifier did not resolve. The export tries the table's next
    identifier candidate on this; anything else is a real failure."""


def _retry_after(resp, default):
    try:
        return min(float(resp.headers.get("Retry-After", "")), MAX_RETRY_WAIT)
    except (TypeError, ValueError):
        return default


def _error_text(resp):
    try:
        body = resp.json()
    except ValueError:
        return resp.text[:300]
    if isinstance(body, dict) and body.get("error"):
        return str(body["error"])[:300]
    return str(body)[:300]


class FulcrumClient:
    """Thin authenticated wrapper over the parts of the Fulcrum API the backup
    reads: forms.json (which apps exist), the Query API (their data) and the
    Attachments API (the files attached to records)."""

    def __init__(self, api_token, base_url=DEFAULT_BASE_URL, timeout=120,
                 max_attempts=4, log=None, session=None):
        if not api_token:
            raise FulcrumError("No Fulcrum API token configured (fulcrum.api_token, or set FULCRUM_API_TOKEN)")
        self._api_token = api_token
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        self.max_attempts = max_attempts
        # A retry that says nothing is indistinguishable from a hang.
        self._log = log if log is not None else print
        self._session = session if session is not None else requests.Session()
        self._sleep = time.sleep

    def __repr__(self):
        # Explicit, so an accidental repr() in a log or traceback cannot leak
        # the token.
        return f"<FulcrumClient base_url={self.base_url!r} api_token=***>"

    def _headers(self):
        return {"X-ApiToken": self._api_token, "Accept": "application/json"}

    def _get(self, path, params):
        url = f"{self.base_url}/{path.lstrip('/')}"
        backoff = 2
        for attempt in range(1, self.max_attempts + 1):
            try:
                resp = self._session.get(url, headers=self._headers(), params=params, timeout=self.timeout)
            except requests.exceptions.RequestException as exc:
                if attempt < self.max_attempts:
                    self._log(f"  [fulcrum] GET {path} failed ({exc}); retrying in {backoff}s "
                              f"(attempt {attempt}/{self.max_attempts})")
                    self._sleep(backoff)
                    backoff *= 2
                    continue
                raise FulcrumUnavailable(f"could not reach the Fulcrum API -- {exc}")

            if resp.status_code == 200:
                return resp
            if resp.status_code in RETRYABLE_STATUSES and attempt < self.max_attempts:
                wait = _retry_after(resp, backoff)
                self._log(f"  [fulcrum] GET {path} -> HTTP {resp.status_code}; retrying in {wait:g}s "
                          f"(attempt {attempt}/{self.max_attempts})")
                self._sleep(wait)
                backoff *= 2
                continue
            if resp.status_code == 401:
                raise FulcrumAuthError("HTTP 401 -- the Fulcrum API token is invalid, or belongs to another org")
            if resp.status_code == 403:
                raise FulcrumAuthError(f"HTTP 403 from {path} -- the token's user lacks permission")
            if resp.status_code == 400 and path.rstrip("/").endswith("/query"):
                raise QueryRejected(f"HTTP 400 -- {_error_text(resp)}")
            if resp.status_code == 404:
                raise FulcrumNotFound(f"HTTP 404 from {path}")
            raise FulcrumError(f"HTTP {resp.status_code} from {path} -- {_error_text(resp)}")
        raise FulcrumError(f"{path} failed after {self.max_attempts} attempts")

    def get_json(self, path, params=None):
        resp = self._get(path, params)
        try:
            return resp.json()
        except ValueError:
            raise FulcrumError(f"HTTP 200 from {path} but the body was not JSON")

    def forms(self):
        """Every app in the org. schema=false leaves out the element
        definitions, which listing apps does not need and which are large."""
        forms, page = [], 1
        while True:
            body = self.get_json("/api/v2/forms.json", params={"schema": "false", "page": page})
            forms.extend(body.get("forms", []))
            total_pages = body.get("total_pages") or 1
            if page >= total_pages:
                return forms
            page += 1

    def query_rows(self, sql):
        """Run read-only SQL through the Query API; rows come back as dicts."""
        body = self.get_json("/api/v2/query", params={"q": sql, "format": "json"})
        if isinstance(body, list):
            return body
        fields = [field.get("name") for field in body.get("fields") or []]
        return [row if isinstance(row, dict) else dict(zip(fields, row)) for row in body.get("rows", [])]

    def query_csv(self, sql, headers=True, per_page=None):
        """Run SQL; return the CSV body as bytes, exactly as Fulcrum produced it."""
        params = {"q": sql, "format": "csv", "headers": "true" if headers else "false"}
        if per_page:
            params["per_page"] = per_page
        return self._get("/api/v2/query", params).content

    def record_attachments(self, record_id):
        """Every attachment of one record: metadata plus a signed download
        URL that expires after about an hour.

        Record attachments can only be listed per record. With form_id the
        endpoint returns the app's reference files instead (OpenAPI,
        GET /v2/attachments), so there is no per-app listing to use.
        """
        found, page = {}, 1
        while True:
            body = self.get_json("/api/v2/attachments", params={
                "owner_type": "record", "record_id": record_id, "page": page, "per_page": 1000})
            batch = [item for item in body.get("attachments") or [] if item.get("id") not in found]
            for item in batch:
                found[item.get("id")] = item
            # Pages are not documented for this endpoint: stop as soon as a
            # page adds nothing, so an API that ignores `page` can't loop us.
            if not batch or len(found) >= int(body.get("total_count") or 0):
                return list(found.values())
            page += 1

    def attachment(self, attachment_id):
        """One attachment's metadata and a fresh signed URL. Raises
        FulcrumNotFound when Fulcrum has no such attachment."""
        body = self.get_json(f"/api/v2/attachments/{attachment_id}")
        # The OpenAPI example is the bare object; other v2 endpoints wrap
        # theirs ({"record": {...}}). Accept either.
        return body["attachment"] if isinstance(body.get("attachment"), dict) else body
