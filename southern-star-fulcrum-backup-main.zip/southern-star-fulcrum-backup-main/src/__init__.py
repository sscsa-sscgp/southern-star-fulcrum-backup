"""Southern Star <-> Fulcrum full data backup. See README.md and INSTALL.md."""
