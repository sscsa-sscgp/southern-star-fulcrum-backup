"""Keeping runs from colliding, and the staging folder from growing forever.

The run lock. Two runs at once -- the scheduler's 8 PM run and a manual
re-run, say -- would race on the staging folder, the attachment state and
the landing zone. export, deliver and run therefore take an OS file lock on
<state_dir>/run.lock first. The operating system drops the lock when the
process ends, however it ends, so a crash or a killed run never leaves a
stale lock behind. A run that finds the lock held stops with exit code 6,
and that sends an alert: a run that hangs must not quietly skip every backup
after it.

Staging cleanup. Each backup is about 60 MB locally, twice a day. After a
successful delivery the oldest local cycle folders go, keeping the newest
export.keep_cycles. Only our own folders (they have _MANIFEST.csv) are
considered, and a complete backup that hasn't been delivered anywhere is
never deleted: it may still need to go out. The landing zone is never
touched; its retention is Southern Star's.
"""

import json
import os
import shutil
import socket
from datetime import datetime

from src.deliver import DRY_RUN_MARKER, MARKER_PREFIX
from src.export import MANIFEST_NAME, SUCCESS_NAME, long_path

LOCK_NAME = "run.lock"
LOCK_INFO_NAME = "run.lock.json"
DEFAULT_KEEP_CYCLES = 14


class RunLocked(Exception):
    """Another export, deliver or run is in progress."""


def _lock_fd(fd):
    if os.name == "nt":
        import msvcrt  # noqa: PLC0415 -- Windows only
        os.lseek(fd, 0, os.SEEK_SET)
        msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
    else:
        import fcntl  # noqa: PLC0415 -- POSIX only
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)


def _unlock_fd(fd):
    if os.name == "nt":
        import msvcrt  # noqa: PLC0415
        os.lseek(fd, 0, os.SEEK_SET)
        msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
    else:
        import fcntl  # noqa: PLC0415
        fcntl.flock(fd, fcntl.LOCK_UN)


class RunLock:
    """with RunLock(state_dir, "run"): ... -- raises RunLocked if held."""

    def __init__(self, state_dir, command):
        self.state_dir = state_dir
        self.command = command
        self.path = os.path.join(state_dir, LOCK_NAME)
        self.info_path = os.path.join(state_dir, LOCK_INFO_NAME)
        self._fd = None

    def __enter__(self):
        os.makedirs(self.state_dir, exist_ok=True)
        fd = os.open(self.path, os.O_RDWR | os.O_CREAT, 0o644)
        try:
            _lock_fd(fd)
        except OSError:
            os.close(fd)
            raise RunLocked(self._held_by())
        self._fd = fd
        info = {"command": self.command, "host": socket.gethostname(), "pid": os.getpid(),
                "started": datetime.now().isoformat(timespec="seconds")}
        with open(self.info_path, "w", encoding="utf-8") as fh:
            json.dump(info, fh)
        return self

    def __exit__(self, *exc):
        try:
            os.remove(self.info_path)
        except OSError:
            pass
        try:
            _unlock_fd(self._fd)
        except OSError:
            pass
        os.close(self._fd)
        self._fd = None

    def _held_by(self):
        try:
            with open(self.info_path, encoding="utf-8") as fh:
                info = json.load(fh)
        except (OSError, ValueError):
            return f"another backup run holds {self.path}"
        return (f"another backup run is in progress: '{info.get('command')}' on {info.get('host')} "
                f"(process {info.get('pid')}), started {info.get('started')}. This run did nothing. If that "
                f"run is stuck, end that process; its lock is released as soon as it exits")


def prune_staging(staging_root, keep=DEFAULT_KEEP_CYCLES, protect=()):
    """Delete old local cycle folders. Returns (removed, kept_undelivered):
    folder names deleted, and old complete-but-undelivered ones left alone.

    The newest `keep` cycles stay regardless. Of the older ones, a folder is
    deleted when it was delivered somewhere, was a dry run, or never completed
    (no _SUCCESS, so it can never be delivered). Folders in `protect` are never touched.
    """
    if keep is None or keep < 0 or not os.path.isdir(staging_root):
        return [], []
    cycles = []
    for name in os.listdir(staging_root):
        path = os.path.join(staging_root, name)
        manifest = os.path.join(path, MANIFEST_NAME)
        if os.path.isdir(path) and os.path.isfile(manifest):
            cycles.append((os.path.getmtime(manifest), name, path))
    cycles.sort(reverse=True)
    protected = {os.path.basename(os.path.normpath(p)) for p in protect}
    removed, kept_undelivered = [], []
    for _mtime, name, path in cycles[keep:]:
        if name in protected:
            continue
        delivered = any(entry.startswith(MARKER_PREFIX) or entry == DRY_RUN_MARKER for entry in os.listdir(path))
        complete = os.path.isfile(os.path.join(path, SUCCESS_NAME))
        if delivered or not complete:
            shutil.rmtree(long_path(os.path.abspath(path)))
            removed.append(name)
        else:
            kept_undelivered.append(name)
    return removed, kept_undelivered
