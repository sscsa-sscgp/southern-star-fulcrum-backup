"""Backup runner. Fulcrum is only ever read.

    python -m src.main export      --config config/config.yaml [--dry-run [--check-identifiers]] [--tag dev]
    python -m src.main deliver     --config config/config.yaml [--env uat|prod] [--cycle PATH]
    python -m src.main run         --config config/config.yaml [--env uat|prod] [--tag dev] [--full-snapshot]
                                   [--dry-run] [--at-hours 8,20]
    python -m src.main preflight   --config config/config.yaml [--env uat|prod]
    python -m src.main attachments --config config/config.yaml [--cycle PATH]
    python -m src.main alert-test  --config config/config.yaml

export       writes one cycle folder of CSVs under export.staging_dir (step 2),
             plus the record attachments --env doesn't have yet (step 3).
deliver      uploads the newest complete cycle not yet delivered to --env (step 4).
run          checks the landing zone first, then exports and delivers that cycle.
             This is what the scheduled job calls. --dry-run pulls and writes
             locally only: no landing zone, no upload, no email, and Southern
             Star placeholders may still be in the config. --at-hours makes it
             a no-op outside those hours in naming.timezone (for cron on UTC).
preflight    checks this machine one item at a time, PASS/FAIL each: placeholders,
             Python, folders, the Fulcrum API, attachment downloads, the SFTP
             login and the SMTP relay. Uploads nothing, sends nothing.
attachments  counts and sizes the attachments a finished cycle's CSVs reference,
             from the API's metadata. Read-only: downloads nothing.
alert-test   sends one sample failure alert through the configured relay
             (alerts.*), with the real subject and From so the routing is tested.

A real run (run, deliver, alert-test) refuses to start while any value in the
config is still a Southern Star placeholder (<<SOUTHERN_STAR: ...>>), and lists
them. Relative paths in the config are relative to the install folder (the
folder holding src/), so cron can run it from anywhere.

export, deliver and run write everything they print to a log file as well
(logging.dir), and when they fail they email an alert (alerts.*, off until
alerts.smtp_host is set). The exit code is the same either way.

A dry run reads the catalog (apps, tables, columns) and prints what a cycle
would export, and under which file names, without fetching any data.
--check-identifiers adds one LIMIT 0 query per table to show which identifier
resolves.

Exit codes: 0 done; 1 incomplete (a table failed, or a delivery was
interrupted -- either way no _SUCCESS -- or an attachment failed to
download: the cycle went without it and the next one retries it); 2 config
problem; 3 Fulcrum unreachable or token rejected; 4 landing zone
unreachable, unverified, or login rejected; 5 unexpected error (a bug: the
log has the traceback); 6 another export/deliver/run holds the run lock,
so this one did nothing.

export, deliver and run hold a lock on <state_dir>/run.lock while they work,
and after a successful delivery they delete old local cycle folders, keeping
the newest export.keep_cycles (src/housekeeping.py).
"""

import argparse
import os
import smtplib
import sys
import traceback
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timezone

from src import alerts, housekeeping, preflight, runlog

from src.attachments import (
    AttachmentState, AttachmentStateError, AttachmentStep, Downloader, describe, inventory, read_basis,
)
from src.catalog import MAX_IDENTIFIER, attachment_column_home, build_plan, identifier_length
from src.config import (
    ENVIRONMENTS, REQUIRED_KEYS_EXPORT, ConfigError, PlaceholderError, dig, is_placeholder, load, placeholders,
    redacted_summary, require, required_keys_delivery,
)
from src.deliver import DRY_RUN_MARKER, DeliveryError, deliver_cycle, find_cycle
from src.export import MANIFEST_NAME, MAX_BATCH, check_identifiers, export_cycle, file_name_for
from src.fulcrum_client import FulcrumClient, FulcrumError
from src.naming import Namer, NamingError, slugify
from src.sftp_client import LandingError, UploadError, connect

#: The install folder: the one holding src/. Relative paths in the config
#: resolve against it, not against the current directory, so a cron job
#: started from $HOME still finds staging/, state/ and logs/.
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_CONFIG = os.path.join(BASE_DIR, "config", "config.yaml")

DEFAULT_BATCH_SIZE = 10000
DEFAULT_STATE_DIR = "state"
DEFAULT_LOG_DIR = "logs"

#: Commands that change something: they get a log file and, on failure, an alert.
LOGGED_COMMANDS = ("export", "deliver", "run")


@dataclass
class RunContext:
    """What a failure alert needs to know about the run so far."""
    config: dict | None = None
    env: str | None = None
    folder: str | None = None
    failures: list = field(default_factory=list)   # everything that failed, for the one alert


RUN = RunContext()


def _heading(title):
    print()
    print(f"=== {title} ===")


def _format_counts(counter):
    return ", ".join(f"{key or '?'} {count}" for key, count in sorted(counter.items()))


def print_plan(plan, namer, stamp, verbose=False, brief=False):
    children = [t for t in plan.tables if t.is_child]
    print(f"  {len(plan.apps)} apps, {len(plan.tables)} tables to export "
          f"({len(plan.tables) - len(children)} app tables + {len(children)} child tables)"
          + (f"; {len(plan.skipped)} unqueryable tables skipped" if brief and plan.skipped else ""))
    if brief:
        return
    if children:
        print("  child tables by field_type: " + _format_counts(Counter(t.field_type for t in children)))
    if plan.excluded:
        print("  excluded by export.exclude_apps: " + ", ".join(repr(a.name) for a in plan.excluded))
    if plan.columns is None:
        print("  WARN: no `columns` catalog -- CSV headers will not be validated")
    else:
        print(f"  columns catalog: {sum(len(c) for c in plan.columns.values())} columns across {len(plan.columns)} tables")
    if plan.uncovered:
        print(f"  not exported ({len(plan.uncovered)} tables with no app in forms.json -- system tables, "
              f"Issues/Tasks):")
        print("    " + ", ".join(f"{name} [{kind}]" if kind else name for name, kind in plan.uncovered))
    if plan.skipped:
        print(f"  {len(plan.skipped)} tables skipped: " + _format_counts(Counter(t.field_type for t, _ in plan.skipped))
              + " -- the Query API refuses them ('invalid field'); attachment files and their")
        print("    records come from the Attachments API instead")
        homes = {table.name: attachment_column_home(table, plan.columns) for table, _ in plan.skipped}
        in_app = sum(1 for t, _ in plan.skipped if homes[t.name] == t.app.name)
        in_child = sum(1 for t, _ in plan.skipped if homes[t.name] and homes[t.name] != t.app.name)
        missing = [t for t, _ in plan.skipped if homes[t.name] == ""]
        unknown = sum(1 for home in homes.values() if home is None)
        print(f"    attachment column carried by an exported CSV: {in_app + in_child} of {len(plan.skipped)} "
              f"(app table {in_app}, child table {in_child}); missing {len(missing)}, unknown {unknown}")
        for table in missing:
            print(f"      missing: {table.name}")
        if verbose:
            for table, _ in plan.skipped:
                if homes[table.name]:
                    print(f"      {table.name}  ->  column in {homes[table.name]}")
    long_names = [t for t in children if identifier_length(t.name) > MAX_IDENTIFIER]
    if long_names:
        print(f"  {len(long_names)} child tables have names over {MAX_IDENTIFIER} bytes; candidates tried in order:")
        for table in long_names:
            print(f"    {table.name}")
            print(f"      -> {' | '.join(table.candidates)}")
    print(f"  cycle folder: {namer.cycle_folder(stamp)}")
    shown = plan.tables if verbose else plan.tables[:5]
    for table in shown:
        print(f"    {file_name_for(table, namer, stamp)}   <- {table.name}")
    if not verbose and len(plan.tables) > len(shown):
        print(f"    ... and {len(plan.tables) - len(shown)} more (--verbose lists every file)")


def print_identifier_report(report):
    failures = [(t, notes) for t, found, notes in report if found is None]
    fallbacks = [(t, found) for t, found, _ in report if found is not None and found != t.candidates[0]]
    noted = [(t, notes) for t, found, notes in report if found is not None and notes]
    print(f"  {len(report) - len(failures)}/{len(report)} tables resolve; "
          f"{len(fallbacks)} needed a fallback identifier")
    for table, found in fallbacks:
        print(f"    FALLBACK {table.name}  ->  {found}")
    for table, notes in noted:
        print(f"    NOTE {table.name}: {'; '.join(notes)}")
    for table, notes in failures:
        print(f"    FAIL {table.name}: {'; '.join(notes)}")
    return not failures


def print_summary(result, skipped=()):
    print(f"  folder:  {result.path}")
    print(f"  tables:  {len(result.tables) - len(result.failed)} OK, {len(result.failed)} failed, "
          f"{len(skipped)} skipped (unqueryable field types, listed in the manifest)")
    print(f"  rows:    {result.total_rows}")
    if result.attachments is not None:
        print(f"  attachments: {describe(result.attachments)}")
    elapsed = (result.finished_at - result.started_at).total_seconds() if result.finished_at else 0
    print(f"  elapsed: {elapsed:.0f}s")
    fell_back = [r for r in result.tables if r.ok and r.identifier != r.table.candidates[0]]
    for r in fell_back:
        print(f"  NOTE {r.table.name} resolved via fallback identifier {r.identifier!r}")
    for r in result.failed:
        print(f"  FAIL {r.table.name}: {r.error}")
    for entry in result.attachment_failures:
        print(f"  FAIL attachment {entry.attachment_id} ({entry.app_name}, record {entry.record_id}): {entry.error}")
    if result.aborted:
        print(f"  ABORTED: {result.aborted}")
    print(f"  RESULT: {'COMPLETE (_SUCCESS written)' if result.complete else 'INCOMPLETE (no _SUCCESS)'}")
    if result.complete and result.attachment_failures:
        print(f"  {len(result.attachment_failures)} attachment(s) failed and are not in this cycle; "
              f"the next cycle tries them again")


def _mb(size):
    return f"{size / 1e6:,.1f} MB"


def print_inventory(inv, state_label):
    entries = inv.entries
    ready = [e for e in entries if e.status in ("NEW", "EARLIER")]
    new = [e for e in entries if e.status == "NEW"]
    ready_bytes = sum(e.bytes or 0 for e in ready)
    print(f"  attachment ID columns: {inv.columns}, in {inv.tables} exported tables")
    print(f"  attachments referenced: {len(entries)}, in {len({e.record_id for e in entries})} records "
          f"of {len({e.app_id for e in entries})} apps")
    others = [f"{sum(1 for e in entries if e.status == s)} {words}" for s, words in
              (("PENDING", "still uploading"), ("MISSING", "not in Fulcrum"), ("FAILED", "lookup failed"))
              if any(e.status == s for e in entries)]
    print(f"  ready in Fulcrum: {len(ready)}, {ready_bytes:,} bytes ({_mb(ready_bytes)})"
          + (f"; {', '.join(others)}" if others else ""))
    by_app = {}
    for entry in ready:
        count, size = by_app.get(entry.app_name, (0, 0))
        by_app[entry.app_name] = (count + 1, size + (entry.bytes or 0))
    for app_name, (count, size) in sorted(by_app.items(), key=lambda item: -item[1][1]):
        print(f"    {app_name.strip():<55} {count:>6} files {_mb(size):>12}")
    new_bytes = sum(e.bytes or 0 for e in new)
    print(f"  {state_label} already has {len(ready) - len(new)}; its next cycle downloads {len(new)} "
          f"({new_bytes:,} bytes, {_mb(new_bytes)})")
    if inv.unparsed:
        print(f"  WARN: {inv.unparsed} cell(s) in attachment columns held no attachment ID")
    for entry in [e for e in entries if e.status in ("MISSING", "FAILED")][:10]:
        print(f"  {entry.status} {entry.attachment_id} ({entry.app_name.strip()}, record {entry.record_id}): {entry.error}")


def print_delivery(result):
    print(f"  remote:  {result.remote_path}  ({result.env.upper()})")
    if result.already_delivered:
        print("  RESULT:  ALREADY DELIVERED -- the folder has _SUCCESS; left untouched")
        return
    elapsed = (result.finished_at - result.started_at).total_seconds() if result.finished_at else 0
    print(f"  files:   {len(result.uploaded)} sent, {len(result.kept)} already there (resumed)")
    print(f"  bytes:   {result.bytes_sent:,}")
    print(f"  elapsed: {elapsed:.0f}s")
    for name in result.unknown_remote:
        print(f"  NOTE {name} is in the folder but not in this cycle -- left untouched")
    if result.attachments_recorded:
        print(f"  state:   {result.attachments_recorded} attachments recorded as delivered ({result.state_path})")
    print("  RESULT:  DELIVERED (_SUCCESS written last)")


def _load_config(path, required_keys):
    _heading("Configuration")
    config = load(path, required_keys)
    RUN.config = config
    print(redacted_summary(config))
    return config


def _env_name(config, args):
    env = (getattr(args, "env", None) or dig(config, "delivery.env") or "uat").lower()
    if env not in ENVIRONMENTS:
        raise ConfigError(f"unknown environment {env!r}; expected one of {', '.join(ENVIRONMENTS)}")
    RUN.env = env
    return env


def _delivery_env(config, args):
    env = _env_name(config, args)
    require(config, required_keys_delivery(env))
    return env


def _config_path(config, key, default):
    """A folder from the config; relative ones are under the install folder."""
    path = dig(config or {}, key) or default
    return path if os.path.isabs(path) else os.path.join(BASE_DIR, path)


def _state_dir(config):
    return _config_path(config, "export.state_dir", DEFAULT_STATE_DIR)


def _staging(config, args):
    return args.staging or _config_path(config, "export.staging_dir", "staging")


def _log_dir(config):
    return _config_path(config, "logging.dir", DEFAULT_LOG_DIR)


def _refuse_placeholders(config, env=None, what="a real run"):
    found = placeholders(config, env)
    if found:
        raise PlaceholderError(found, what)


def _attachment_step(client, config, args, env, namer):
    """The attachment step for a cycle meant for env. What that landing zone
    already has comes from its state file; --full-snapshot ignores it."""
    state = AttachmentState(AttachmentState.path_for(_state_dir(config), env, namer.tag))
    return AttachmentStep(client, state, env, tag=namer.tag, full_snapshot=args.full_snapshot,
                          downloader=Downloader(), verbose=args.verbose)


def _open_landing(config, env):
    return connect(
        dig(config, "sftp.host"),
        int(dig(config, "sftp.port") or 22),
        dig(config, f"sftp.accounts.{env}.username"),
        dig(config, f"sftp.accounts.{env}.password"),
        dig(config, "sftp.host_key_fingerprint"),
        timeout=float(dig(config, "sftp.timeout_sec") or 20),
    )


def _export_setup(config, args):
    namer = Namer(dig(config, "naming") or {}, tag=args.tag)
    batch_size = args.batch_size or int(dig(config, "export.batch_size") or DEFAULT_BATCH_SIZE)
    if not 1 <= batch_size <= MAX_BATCH:
        raise ConfigError(f"export.batch_size must be between 1 and {MAX_BATCH}, got {batch_size}")
    staging = _staging(config, args)
    token = dig(config, "fulcrum.api_token")
    if is_placeholder(token):
        raise ConfigError("the Fulcrum token is still a placeholder; set FULCRUM_API_TOKEN (even a dry run "
                          "needs it to read from Fulcrum)")
    client = FulcrumClient(token, base_url=dig(config, "fulcrum.base_url"))
    return namer, batch_size, staging, client


def _plan(client, config, args):
    plan = build_plan(client, exclude=dig(config, "export.exclude_apps") or [], only=args.app or [])
    if not plan.tables:
        raise ConfigError("nothing to export -- check --app and export.exclude_apps")
    return plan


def cmd_export(args):
    config = _load_config(args.config, REQUIRED_KEYS_EXPORT)
    namer, batch_size, staging, client = _export_setup(config, args)

    _heading("Catalog")
    plan = _plan(client, config, args)
    print_plan(plan, namer, namer.stamp(datetime.now(timezone.utc)), verbose=args.verbose)

    if args.check_identifiers:
        _heading("Identifier check (LIMIT 0 per table)")
        all_resolve = print_identifier_report(check_identifiers(client, plan))
        if args.dry_run:
            return 0 if all_resolve else 1

    if args.dry_run:
        print()
        print("Dry run: no data fetched, nothing written.")
        return 0

    env = _env_name(config, args)
    with _run_lock(config, "export"):
        _heading("Export")
        now = _start_cycle(namer)
        result = export_cycle(client, plan, namer, staging, batch_size=batch_size, verbose=args.verbose, now=now,
                              attachments=_attachment_step(client, config, args, env, namer))
    _heading("Summary")
    print_summary(result, plan.skipped)
    _record_failures(result)
    return 0 if result.complete and not result.attachment_failures else 1


def cmd_deliver(args):
    config = _load_config(args.config, ())
    env = _delivery_env(config, args)
    _refuse_placeholders(config, env)
    staging = _staging(config, args)
    with _run_lock(config, "deliver"):
        cycle = args.cycle or find_cycle(staging, env)
        if not cycle:
            print(f"\nNothing to deliver: no complete cycle in {staging} that hasn't already gone to {env.upper()}.")
            return 0
        RUN.folder = os.path.basename(os.path.normpath(cycle))
        _heading(f"Delivery to {env.upper()}: {RUN.folder}")
        with _open_landing(config, env) as landing:
            result = deliver_cycle(landing, cycle, dig(config, f"sftp.accounts.{env}.remote_dir") or ".", env,
                                   verbose=args.verbose, state_dir=_state_dir(config))
        print_delivery(result)
        _clean_staging(config, staging, protect=[cycle])
    return 0


def cmd_run(args):
    config = _load_config(args.config, REQUIRED_KEYS_EXPORT)
    if args.dry_run:
        env = _env_name(config, args)
    else:
        env = _delivery_env(config, args)
        _refuse_placeholders(config, env)
    if args.tag and env == "prod" and not args.dry_run:
        raise ConfigError("tagged cycles are for development; deliver them to UAT, not Production")
    namer, batch_size, staging, client = _export_setup(config, args)
    with _run_lock(config, "run"):
        return _run_locked(args, config, env, namer, batch_size, staging, client)


def _record_failures(result):
    """Everything in this export that failed, for the run's one alert."""
    RUN.failures.extend(f'table "{r.table.name}" ({r.table.app.name.strip()}): {r.error}' for r in result.failed)
    RUN.failures.extend(f"attachment {e.attachment_id} ({e.app_name.strip()}, record {e.record_id}): {e.error}"
                        for e in result.attachment_failures)
    if result.aborted:
        RUN.failures.append(f"export stopped: {result.aborted}")


def _run_locked(args, config, env, namer, batch_size, staging, client):
    if args.dry_run:
        _heading("Dry run")
        print("  Pulls from Fulcrum and writes locally only: no landing zone, no upload, no email.")
    else:
        # Fail before exporting if the landing zone can't be reached or verified:
        # an export that can't be delivered only fills the staging folder.
        _heading(f"Landing zone ({env.upper()})")
        _open_landing(config, env).close()
        print("  reachable, host key verified, login OK")

    _heading("Export")
    plan = _plan(client, config, args)
    now = _start_cycle(namer)
    print_plan(plan, namer, namer.stamp(now), brief=True)
    result = export_cycle(client, plan, namer, staging, batch_size=batch_size, verbose=args.verbose, now=now,
                          attachments=_attachment_step(client, config, args, env, namer))
    print_summary(result, plan.skipped)
    _record_failures(result)
    if args.dry_run:
        with open(os.path.join(result.path, DRY_RUN_MARKER), "w", encoding="utf-8") as fh:
            fh.write("made by run --dry-run; never delivered\n")
        print(f"  Dry run: the backup is in {result.path}. Nothing was uploaded and no email was sent.")
        return 0 if result.complete and not result.attachment_failures else 1
    if not result.complete:
        print("  Not delivered: the export is incomplete. The tables that did export are in the local folder; "
              "the next run tries everything again.")
        RUN.failures.append("not delivered: the export is incomplete, so this backup is not on the landing zone")
        return 1

    _heading(f"Delivery to {env.upper()}")
    with _open_landing(config, env) as landing:
        delivery = deliver_cycle(landing, result.path, dig(config, f"sftp.accounts.{env}.remote_dir") or ".", env,
                                 verbose=args.verbose, state_dir=_state_dir(config))
    print_delivery(delivery)
    _clean_staging(config, staging, protect=[result.path])
    return 1 if result.attachment_failures else 0


def _run_lock(config, command):
    return housekeeping.RunLock(_state_dir(config), command)


def _clean_staging(config, staging, protect=()):
    """After a successful delivery: drop old local cycles (src/housekeeping.py)."""
    raw = dig(config, "export.keep_cycles")
    keep = housekeeping.DEFAULT_KEEP_CYCLES if raw is None else int(raw)
    removed, undelivered = housekeeping.prune_staging(staging, keep, protect=protect)
    if removed:
        print(f"  cleanup: removed {len(removed)} old local backup(s), keeping the newest {keep}")
    for name in undelivered:
        print(f"  NOTE {name} is complete but was never delivered; kept (run deliver --cycle to send it)")


def _start_cycle(namer):
    """The cycle's start time, fixed here so that a failure alert can name the
    backup folder even when the export stops halfway."""
    now = datetime.now(timezone.utc)
    RUN.folder = namer.cycle_folder(namer.stamp(now))
    return now


def cmd_alert_test(args):
    config = _load_config(args.config, ())
    alert = alerts.settings(config)
    _heading("Alert test")
    if alert is None:
        print("[FAIL] alerts are off: alerts.smtp_host is not set in the config")
        return 2
    expected = dig(config, "site.vm_hostname")
    message = alerts.sample_failure_message(alert, expected_host=None if is_placeholder(expected) else expected)
    print(f"  relay:   {alert.host}:{alert.port} ({alert.security})")
    print(f"  from:    {alert.sender}")
    print(f"  to:      {', '.join(alert.recipients)}")
    print(f"  subject: {message['Subject']}")
    try:
        refused = alerts.send(alert, message)
    except (smtplib.SMTPException, OSError) as exc:
        print(f"[FAIL] {alerts.describe_error(exc, alert)}")
        return 4
    for recipient, (code, reason) in (refused or {}).items():
        print(f"  WARN the relay refused {recipient}: {code} {reason!r}")
    print("  RESULT:  SENT -- check that it arrived (and, for help@, that a ticket opened)")
    return 0


def cmd_preflight(args):
    config = _load_config(args.config, ())
    env = _env_name(config, args)
    folders = {"staging": _staging(config, args), "state": _state_dir(config), "logs": _log_dir(config)}
    _heading(f"Preflight ({env.upper()} landing zone)")
    checks = preflight.run_checks(config, env, folders, BASE_DIR)
    for check in checks:
        print(f"  [{check.status}] {check.item}" + (f": {check.detail}" if check.detail else ""))
    pending = placeholders(config, env)
    if pending:
        print()
        print("  Still to fill in:")
        for key, text in pending:
            print(f"    {key}: {text}")
    failed = [c for c in checks if c.status == "FAIL"]
    counts = {status: sum(1 for c in checks if c.status == status) for status in ("PASS", "FAIL", "WARN", "SKIP")}
    print()
    print("  RESULT: " + ("READY" if not failed else "NOT READY") + " -- "
          + ", ".join(f"{n} {status.lower()}" for status, n in counts.items() if n))
    return 0 if not failed else 1


def _latest_cycle(staging):
    """The most recently exported cycle folder in staging (by its manifest)."""
    if not os.path.isdir(staging):
        return None
    found = [(os.path.getmtime(os.path.join(staging, name, MANIFEST_NAME)), os.path.join(staging, name))
             for name in os.listdir(staging) if os.path.isfile(os.path.join(staging, name, MANIFEST_NAME))]
    return max(found)[1] if found else None


def cmd_attachments(args):
    config = _load_config(args.config, REQUIRED_KEYS_EXPORT)
    staging = _staging(config, args)
    cycle = args.cycle or _latest_cycle(staging)
    if not cycle:
        print(f"\nNo cycle in {staging} to count from: run export first.")
        return 0
    # Compare with the state the cycle was made for; failing that, --env/--tag.
    basis = read_basis(cycle) or {}
    env = basis.get("env") or _env_name(config, args)
    tag = basis.get("tag") if basis else (slugify(args.tag) if args.tag else None)
    state = AttachmentState(AttachmentState.path_for(_state_dir(config), env, tag))
    client = FulcrumClient(dig(config, "fulcrum.api_token"), base_url=dig(config, "fulcrum.base_url"))
    _heading(f"Attachments referenced by {os.path.basename(os.path.normpath(cycle))} (read-only)")
    print_inventory(inventory(client, cycle, state), f"{env.upper()}{f' ({tag})' if tag else ''}")
    return 0


def parse_args(argv):
    parser = argparse.ArgumentParser(prog="python -m src.main", description="Southern Star full data backup.")
    sub = parser.add_subparsers(dest="command", required=True)

    def common(p):
        p.add_argument("--config", default=DEFAULT_CONFIG, help="path to config.yaml (default: config/config.yaml "
                                                                 "in the install folder)")
        p.add_argument("--staging", help="staging root (default: export.staging_dir, else staging/ in the "
                                         "install folder)")
        p.add_argument("--verbose", action="store_true", help="list every table and file")

    def export_options(p):
        p.add_argument("--tag", help="prefix for the cycle folder, e.g. dev -> dev_backup_...")
        p.add_argument("--app", action="append", help="export only this app (exact name or form ID); repeatable")
        p.add_argument("--batch-size", type=int, help=f"rows per Query API request (max {MAX_BATCH})")
        p.add_argument("--full-snapshot", action="store_true",
                       help="download every attachment, not only those the landing zone doesn't have yet")

    def env_option(p, help_text="landing account (default: delivery.env, else uat)"):
        p.add_argument("--env", choices=ENVIRONMENTS, help=help_text)

    export = sub.add_parser("export", help="export every app as CSV into a local staging folder (no upload)")
    common(export)
    export_options(export)
    env_option(export, "landing account the cycle is for: its attachment state decides which attachments are new "
                       "(default: delivery.env, else uat)")
    export.add_argument("--dry-run", action="store_true", help="print the plan; fetch no data, write nothing")
    export.add_argument("--check-identifiers", action="store_true",
                        help="also try each table's identifier candidates with LIMIT 0 and report which resolves")

    deliver = sub.add_parser("deliver", help="upload a staged cycle to the landing zone")
    common(deliver)
    env_option(deliver)
    deliver.add_argument("--cycle", help="cycle folder to deliver (default: newest complete one not yet delivered)")

    run = sub.add_parser("run", help="check the landing zone, export, then deliver (the scheduled job)")
    common(run)
    export_options(run)
    env_option(run)
    run.add_argument("--dry-run", action="store_true",
                     help="pull and write locally only: no landing zone, no upload, no email; placeholders allowed")
    run.add_argument("--at-hours", type=_hours,
                     help="only run if the hour in naming.timezone is one of these (e.g. 8,20); otherwise exit 0 "
                          "quietly. For cron on a machine that isn't on Central time")

    attachments = sub.add_parser("attachments", help="count and size a cycle's attachments (read-only)")
    common(attachments)
    env_option(attachments, "compare with this landing account's state (default: the cycle's own, else delivery.env)")
    attachments.add_argument("--tag", help="the tag whose state to compare with, when the cycle doesn't say")
    attachments.add_argument("--cycle", help="cycle folder to count from (default: the newest in staging)")

    alert_test = sub.add_parser("alert-test", help="send one sample failure alert through the configured relay")
    alert_test.add_argument("--config", default=DEFAULT_CONFIG, help="path to config.yaml")

    check = sub.add_parser("preflight", help="check this machine one item at a time (install time)")
    common(check)
    env_option(check)
    return parser.parse_args(argv)


def _hours(text):
    try:
        hours = sorted({int(part) for part in text.split(",") if part.strip()})
    except ValueError:
        raise argparse.ArgumentTypeError(f"expected hours like 8,20, got {text!r}")
    if not hours or any(not 0 <= h <= 23 for h in hours):
        raise argparse.ArgumentTypeError(f"hours must be 0-23, got {text!r}")
    return hours


COMMANDS = {
    "export": cmd_export, "deliver": cmd_deliver, "run": cmd_run, "attachments": cmd_attachments,
    "alert-test": cmd_alert_test, "preflight": cmd_preflight,
}


def _send_failure_alert(args, code, log):
    """Email the failure, if alerts are configured. Never changes the exit
    code: a broken mail setup must not hide, or replace, a failed backup."""
    try:
        alert = alerts.settings(RUN.config)
    except alerts.AlertConfigError as exc:
        print(f"  WARN no failure alert sent: {exc}")
        return
    if alert is None:
        print("  Alerts are off (alerts.smtp_host is not set): this failure is in the log and the exit code only.")
        return
    expected = dig(RUN.config or {}, "site.vm_hostname")
    message = alerts.failure_message(
        alert, command=" ".join([args.command] + (["--env", RUN.env] if RUN.env else [])), code=code,
        failures=RUN.failures, env=RUN.env, folder=RUN.folder, log_path=log.path, tail=list(log.tail),
        expected_host=None if is_placeholder(expected) else expected)
    try:
        refused = alerts.send(alert, message)
    except (smtplib.SMTPException, OSError) as exc:
        print(f"  WARN could not send the failure alert: {alerts.describe_error(exc, alert)}")
        return
    sent_to = [r for r in alert.recipients if r not in (refused or {})]
    print(f"  Alert sent to {', '.join(sent_to)}: {message['Subject']}")
    for recipient, (status, reason) in (refused or {}).items():
        print(f"  WARN the relay refused {recipient}: {status} {reason!r}")


def _outside_schedule(args):
    """For `run --at-hours`: True when this isn't one of those hours in the
    backup's timezone (naming.timezone, America/Chicago by default). Lets cron
    on a UTC machine fire at both candidate UTC hours and run only at 8 AM
    and 8 PM Central, daylight saving or not."""
    if args.command != "run" or not getattr(args, "at_hours", None):
        return False
    try:
        config = load(args.config, ())
        namer = Namer(dig(config, "naming") or {})
    except (ConfigError, NamingError):
        return False   # let the normal path report it, logged and alerted
    hour = datetime.now(namer.tz).hour
    if hour in args.at_hours:
        return False
    print(f"Not a scheduled hour: it is {hour:02d}:xx in {namer.tz.key}, and --at-hours is "
          f"{','.join(str(h) for h in args.at_hours)}. Nothing to do.")
    return True


def main(argv=None):
    args = parse_args(argv)
    global RUN
    RUN = RunContext()
    plan_only = args.command == "export" and args.dry_run
    if args.command not in LOGGED_COMMANDS or plan_only:
        return _dispatch(args)
    if _outside_schedule(args):
        return 0

    log = runlog.RunLog(args.command, sys.stdout)
    sys.stdout = log
    try:
        code = _dispatch(args)
        log_dir = _log_dir(RUN.config)
        try:
            log.open(log_dir)
            runlog.prune(log_dir, int(dig(RUN.config or {}, "logging.keep_days") or runlog.DEFAULT_KEEP_DAYS))
        except OSError as exc:
            print(f"  WARN could not write the log file in {log_dir}: {exc}")
        if code != 0 and getattr(args, "dry_run", False):
            print("  Dry run: no alert sent.")
        elif code != 0:
            _send_failure_alert(args, code, log)
        if log.path:
            print(f"Log: {log.path}")
        return code
    finally:
        sys.stdout = log.console
        log.close()


def _fail(exc):
    print(f"[FAIL] {exc}")
    RUN.failures.append(str(exc).splitlines()[0])


def _dispatch(args):
    try:
        return COMMANDS[args.command](args)
    except (ConfigError, NamingError, FileExistsError, AttachmentStateError, alerts.AlertConfigError) as exc:
        _fail(exc)
        return 2
    except FulcrumError as exc:
        # Includes FulcrumAuthError / FulcrumUnavailable: token rejected, API
        # unreachable, or the catalog could not be read -- nothing to export.
        _fail(exc)
        return 3
    except LandingError as exc:
        _fail(exc)
        return 4
    except (DeliveryError, UploadError) as exc:
        _fail(exc)
        print("  The folder on the landing zone has no _SUCCESS, so ingestion will ignore it; "
              "re-running deliver resumes where this stopped.")
        return 1
    except housekeeping.RunLocked as exc:
        _fail(exc)
        return 6
    except Exception as exc:  # noqa: BLE001 -- a scheduled job must report a bug, not die silently
        print(f"[FAIL] unexpected error: {exc!r}")
        RUN.failures.append(f"unexpected error: {exc!r}")
        print(traceback.format_exc().rstrip())
        return 5


if __name__ == "__main__":
    sys.exit(main())
