"""The run's log file (acceptance criterion 3: a failed run leaves a log
entry, as well as an alert).

Everything a command prints still goes to the console, and for the commands
that change something (export, deliver, run) it also goes to
<logging.dir>/fulcrum-backup_<command>_<YYYYmmdd_HHMMSS>.log, one timestamped
line each. The lines are held in memory until the config says where the log
directory is, so even a config error ends up in a file.
"""

import collections
import os
from datetime import datetime, timedelta

LOG_PREFIX = "fulcrum-backup_"
DEFAULT_KEEP_DAYS = 90

#: How many of the last lines a failure alert quotes.
TAIL_LINES = 60


class RunLog:
    """Stands in for sys.stdout: writes to the console and to the log file."""

    def __init__(self, command, console, now=None):
        self.command = command
        self.console = console
        self.started = now or datetime.now()
        self.path = None
        self.tail = collections.deque(maxlen=TAIL_LINES)
        self._fh = None
        self._held = []
        self._partial = ""

    # -- the file-like surface print() needs --------------------------------

    def write(self, text):
        self.console.write(text)
        self._partial += text
        *lines, self._partial = self._partial.split("\n")
        for line in lines:
            self._line(line)
        return len(text)

    def flush(self):
        self.console.flush()
        if self._fh:
            self._fh.flush()

    @property
    def encoding(self):
        return getattr(self.console, "encoding", "utf-8")

    def isatty(self):
        return False

    # -- the log file -------------------------------------------------------

    def _line(self, line):
        self.tail.append(line)
        stamped = f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {line}"
        if self._fh:
            self._fh.write(stamped + "\n")
        else:
            self._held.append(stamped)

    def open(self, directory):
        """Start writing to a file in directory (once). Returns its path."""
        if self._fh:
            return self.path
        os.makedirs(directory, exist_ok=True)
        name = f"{LOG_PREFIX}{self.command}_{self.started:%Y%m%d_%H%M%S}.log"
        path = os.path.abspath(os.path.join(directory, name))
        self._fh = open(path, "a", encoding="utf-8")
        self.path = path
        for line in self._held:
            self._fh.write(line + "\n")
        self._held = []
        return path

    def close(self):
        if self._partial:
            self._line(self._partial)
            self._partial = ""
        if self._fh:
            self._fh.close()
            self._fh = None


def prune(directory, keep_days=DEFAULT_KEEP_DAYS, now=None):
    """Delete this tool's own log files older than keep_days. Returns how many."""
    if not keep_days or not os.path.isdir(directory):
        return 0
    cutoff = (now or datetime.now()) - timedelta(days=keep_days)
    removed = 0
    for name in os.listdir(directory):
        path = os.path.join(directory, name)
        if name.startswith(LOG_PREFIX) and name.endswith(".log") and os.path.isfile(path):
            if datetime.fromtimestamp(os.path.getmtime(path)) < cutoff:
                os.remove(path)
                removed += 1
    return removed
