"""Export one backup cycle to a local staging folder.

For every table in the plan: count its rows, fetch it from the Query API as CSV
(in batches when it is bigger than one request), check the count, and write it
into the cycle folder. Then the attachments those tables reference (step 3,
src/attachments.py), then _MANIFEST.csv, _SCHEMA.csv and -- only if every
table succeeded -- _SUCCESS.

Files are written as <name>.part and renamed when complete, so a crash never
leaves a truncated file that looks finished. Delivery (step 4) uploads only
cycle folders that have _SUCCESS.

Fulcrum's CSV bytes are written exactly as received: no re-encoding, no
reformatting. What Southern Star ingests is what Fulcrum produced.
"""

import csv
import hashlib
import io
import ntpath
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone

from src.catalog import quote_identifier
from src.fulcrum_client import FulcrumAuthError, FulcrumError, FulcrumUnavailable, QueryRejected
from src.naming import slugify

MANIFEST_NAME = "_MANIFEST.csv"
SCHEMA_NAME = "_SCHEMA.csv"
SUCCESS_NAME = "_SUCCESS"

#: The Query API's page size. A batch bigger than this would be cut short by
#: the API itself, so batch_size is capped here.
MAX_BATCH = 20000

MANIFEST_FIELDS = [
    "file", "status", "app_name", "app_id", "table", "data_name", "field_type",
    "identifier", "rows", "bytes", "sha256", "notes", "error",
]


class TableExportError(Exception):
    """One table could not be exported. The cycle carries on with the others
    but ends without _SUCCESS."""


class HeaderMismatch(TableExportError):
    """The CSV that came back belongs to a different table."""


@dataclass
class TableResult:
    table: object
    file: str = ""
    identifier: str = ""
    rows: int = 0
    bytes: int = 0
    sha256: str = ""
    notes: list = field(default_factory=list)
    error: str = ""

    @property
    def ok(self):
        return not self.error


@dataclass
class CycleResult:
    folder: str
    path: str
    stamp: str
    started_at: datetime
    finished_at: datetime | None = None
    tables: list = field(default_factory=list)
    aborted: str = ""
    attachments: list | None = None   # AttachmentEntry per attachment; None if that step didn't run

    @property
    def failed(self):
        return [result for result in self.tables if not result.ok]

    @property
    def attachment_failures(self):
        return [entry for entry in self.attachments or () if entry.status == "FAILED"]

    @property
    def complete(self):
        return bool(self.tables) and not self.failed and not self.aborted

    @property
    def total_rows(self):
        return sum(result.rows for result in self.tables)


# ---------------------------------------------------------------------------
# CSV helpers
# ---------------------------------------------------------------------------

def _decode(data):
    return data.decode("utf-8-sig")


def parse_header(data):
    """Column names from the first CSV record ([] for an empty body)."""
    return next(csv.reader(io.StringIO(_decode(data), newline="")), [])


def count_records(data, has_header):
    """CSV records, not lines: note fields can contain newlines."""
    records = sum(1 for _ in csv.reader(io.StringIO(_decode(data), newline="")))
    if has_header and records:
        records -= 1
    return records


def _first_line(data):
    end = data.find(b"\n")
    return data if end < 0 else data[:end + 1]


def _ensure_trailing_newline(data):
    if data and not data.endswith(b"\n"):
        data += b"\r\n" if b"\r\n" in data else b"\n"
    return data


def check_header(header, table_name, columns):
    """Validate a CSV header against the `columns` catalog.

    Returns a note (str) when the header differs from what the catalog lists
    for this table but belongs to no other table either -- a catalog quirk,
    worth recording, not worth failing over. Raises HeaderMismatch when the
    header is exactly some OTHER table's columns: that is the truncated
    identifier resolving to the wrong table, which must never be written under
    this table's name.
    """
    if columns is None or not header:
        return ""
    expected = columns.get(table_name)
    if expected is not None and set(header) == set(expected):
        return ""
    others = [name for name, cols in columns.items() if name != table_name and set(cols) == set(header)]
    if others:
        raise HeaderMismatch(f"the CSV columns are those of {others[0]!r}, not {table_name!r}")
    if expected is None:
        return "table not in the columns catalog; header not validated"
    missing = sorted(set(expected) - set(header))[:5]
    extra = sorted(set(header) - set(expected))[:5]
    return f"header differs from the columns catalog (missing {missing}, extra {extra})"


def _order_clause(header):
    """A total order, so batches never skip or repeat a row.

    _child_record_id is unique in repeatable tables and _record_id in app
    tables; media and record-link tables have no unique key (one row per photo
    or link), so every column is appended as a tie-breaker.
    """
    positions = ", ".join(str(i) for i in range(1, len(header) + 1))
    for key in ("_child_record_id", "_record_id"):
        if key in header:
            return f'ORDER BY "{key}", {positions}'
    return f"ORDER BY {positions}"


# ---------------------------------------------------------------------------
# Fetching one table
# ---------------------------------------------------------------------------

def count_rows(client, identifier):
    rows = client.query_rows(f"SELECT COUNT(*) AS n FROM {quote_identifier(identifier)}")
    return int(rows[0]["n"])


def _fetch_pages(client, ident, order, batch_size):
    chunks, total, offset, header_line = [], 0, 0, b""
    while True:
        first = offset == 0
        data = client.query_csv(
            f"SELECT * FROM {ident} {order} LIMIT {batch_size} OFFSET {offset}",
            headers=first, per_page=batch_size,
        )
        if first:
            header_line = _first_line(data)
        elif header_line and data.startswith(header_line):
            data = data[len(header_line):]  # headers=false was ignored
        rows = count_records(data, has_header=first)
        chunks.append(_ensure_trailing_newline(data))
        total += rows
        if rows < batch_size:
            return b"".join(chunks), total
        offset += batch_size


def _fetch_with_identifier(client, table, identifier, columns, batch_size):
    """Returns (csv_bytes, rows, notes) or raises QueryRejected / HeaderMismatch
    / TableExportError."""
    ident = quote_identifier(identifier)
    notes = []
    for attempt in (1, 2):
        expected_rows = count_rows(client, identifier)
        if expected_rows <= batch_size:
            data = client.query_csv(f"SELECT * FROM {ident}", headers=True, per_page=batch_size)
            header = parse_header(data)
            note = check_header(header, table.name, columns)
            rows = count_records(data, has_header=bool(header))
        else:
            header = parse_header(client.query_csv(f"SELECT * FROM {ident} LIMIT 0", headers=True, per_page=1))
            note = check_header(header, table.name, columns)
            data, rows = _fetch_pages(client, ident, _order_clause(header), batch_size)

        if not data.strip() and expected_rows == 0 and columns and columns.get(table.name):
            # An empty table can come back with no header at all; the DBAs
            # still need its columns to create the table, so take them from
            # the catalog.
            buffer = io.StringIO()
            csv.writer(buffer, lineterminator="\r\n").writerow(columns[table.name])
            data = buffer.getvalue().encode("utf-8")
            note = "empty table; header taken from the columns catalog"

        if rows == expected_rows:
            return data, rows, notes + ([note] if note else [])
        # Field crews keep syncing while a cycle runs, so a table can
        # legitimately change between the count and the fetch. Recount once
        # before calling it a failure.
        recount = count_rows(client, identifier)
        if rows == recount:
            notes.append(f"row count changed during export ({expected_rows} -> {recount})")
            return data, rows, notes + ([note] if note else [])
        if attempt == 2:
            raise TableExportError(
                f"row count mismatch: fetched {rows}, table reports {recount} -- "
                f"likely truncated by the API's page size (batch_size {batch_size})"
            )
    raise TableExportError("unreachable")


def fetch_table(client, table, columns, batch_size):
    """Try each candidate identifier in turn. Returns (identifier, csv_bytes,
    rows, notes); raises TableExportError when none of them works."""
    errors = []
    for identifier in table.candidates:
        try:
            data, rows, notes = _fetch_with_identifier(client, table, identifier, columns, batch_size)
            return identifier, data, rows, notes
        except (QueryRejected, HeaderMismatch) as exc:
            errors.append(f"{identifier!r}: {exc}")
    raise TableExportError("no identifier resolved -- " + "; ".join(errors))


def check_identifiers(client, plan):
    """For --check-identifiers: which candidate resolves for every table,
    using LIMIT 0 so no data is fetched. Returns [(table, identifier_or_None,
    notes)]."""
    report = []
    for table in plan.tables:
        found, notes = None, []
        for identifier in table.candidates:
            try:
                header = parse_header(client.query_csv(
                    f"SELECT * FROM {quote_identifier(identifier)} LIMIT 0", headers=True, per_page=1))
                note = check_header(header, table.name, plan.columns)
            except (QueryRejected, HeaderMismatch) as exc:
                notes.append(f"{identifier!r}: {exc}")
                continue
            found = identifier
            if note:
                notes.append(note)
            break
        report.append((table, found, notes))
    return report


# ---------------------------------------------------------------------------
# Writing a cycle
# ---------------------------------------------------------------------------

def long_path(path, windows=None):
    """The path to hand to open() and friends.

    Windows refuses paths of 260 characters or more unless long paths are
    enabled machine-wide, which we can't count on for Southern Star's host.
    Near that limit this returns the extended-length form (\\\\?\\D:\\...),
    which works regardless. Elsewhere, and for short paths, the path as is.
    """
    if windows is None:
        windows = os.name == "nt"
    if not windows:
        return path
    full = ntpath.abspath(path)
    if len(full) < 240 or full.startswith("\\\\?\\"):
        return path
    if full.startswith("\\\\"):  # a share: \\server\share\... -> \\?\UNC\server\share\...
        return "\\\\?\\UNC\\" + full[2:]
    return "\\\\?\\" + full


def write_file(path, data):
    """Write via <path>.part + rename. Returns (bytes, sha256)."""
    part = path + ".part"
    with open(long_path(part), "wb") as fh:
        fh.write(data)
    os.replace(long_path(part), long_path(path))
    return len(data), hashlib.sha256(data).hexdigest()


def file_name_for(table, namer, stamp):
    if table.is_child:
        return namer.child_table_file(table.app.slug, slugify(table.data_name), stamp)
    return namer.table_file(table.app.slug, stamp)


def write_csv(path, fieldnames, rows):
    """One of our own CSVs (manifest, schema, attachment index): UTF-8, CRLF."""
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=fieldnames, lineterminator="\r\n", extrasaction="ignore")
    writer.writeheader()
    writer.writerows(rows)
    return write_file(path, buffer.getvalue().encode("utf-8"))


def write_manifest(result, skipped=(), extra_rows=()):
    """One row per table: OK, FAILED, or SKIPPED (with the reason), so the
    manifest says what a cycle deliberately left out, not just what it holds.
    extra_rows are the attachment files the cycle holds, one OK row each."""
    rows = [{
        "file": r.file,
        "status": "OK" if r.ok else "FAILED",
        "app_name": r.table.app.name,
        "app_id": r.table.app.id,
        "table": r.table.name,
        "data_name": r.table.data_name or "",
        "field_type": r.table.field_type or "",
        "identifier": r.identifier,
        "rows": r.rows if r.ok else "",
        "bytes": r.bytes if r.ok else "",
        "sha256": r.sha256,
        "notes": "; ".join(r.notes),
        "error": r.error,
    } for r in result.tables]
    rows += [{
        "status": "SKIPPED",
        "app_name": table.app.name,
        "app_id": table.app.id,
        "table": table.name,
        "data_name": table.data_name or "",
        "field_type": table.field_type or "",
        "notes": reason,
    } for table, reason in skipped]
    rows += list(extra_rows)
    write_csv(os.path.join(result.path, MANIFEST_NAME), MANIFEST_FIELDS, rows)


def write_schema(result, plan):
    """The `columns` catalog rows for every exported table, so each cycle
    carries the exact column list and types it was produced with."""
    if not plan.schema_rows:
        return False
    exported = {r.table.name for r in result.tables if r.ok}
    table_key = next((k for k in ("table_name", "table") if k in plan.schema_rows[0]), None)
    if table_key is None:
        return False
    rows = [row for row in plan.schema_rows if str(row.get(table_key)) in exported]
    write_csv(os.path.join(result.path, SCHEMA_NAME), list(plan.schema_rows[0].keys()), rows)
    return True


def export_cycle(client, plan, namer, staging_root, batch_size=10000, log=print, verbose=False, now=None,
                 attachments=None):
    """Export every table in the plan into a new cycle folder. Always writes
    the manifest (even when aborted), and _SUCCESS only when complete.

    FulcrumAuthError / FulcrumUnavailable abort the cycle (every remaining
    table would fail the same way) and are re-raised after the manifest is
    written. Any other failure is recorded against its table.

    attachments, when given, is the attachment step (src.attachments.
    AttachmentStep). It runs once every table is in, and returns the
    manifest rows for the files it downloaded. An attachment that fails
    doesn't hold back the tables: the cycle still completes, the failure is
    in _ATTACHMENTS.csv, and the next cycle tries it again.
    """
    if not 1 <= batch_size <= MAX_BATCH:
        raise ValueError(f"batch_size must be between 1 and {MAX_BATCH}, got {batch_size}")
    started = now or datetime.now(timezone.utc)
    stamp = namer.stamp(started)
    folder = namer.cycle_folder(stamp)
    path = os.path.join(staging_root, folder)
    if os.path.exists(path):
        raise FileExistsError(f"cycle folder {path} already exists -- a cycle already ran this minute")
    os.makedirs(path)
    result = CycleResult(folder=folder, path=path, stamp=stamp, started_at=started)
    # _SUCCESS needs the loop to have run to the end. Without this, an
    # unexpected exception halfway through would leave a partial cycle whose
    # finished tables all look OK -- and the finally block would bless it.
    # The same goes for the attachment step.
    tables_finished = loop_finished = False
    attachment_rows = []

    try:
        for index, table in enumerate(plan.tables, start=1):
            table_result = TableResult(table=table, file=file_name_for(table, namer, stamp))
            try:
                identifier, data, rows, notes = fetch_table(client, table, plan.columns, batch_size)
                table_result.identifier, table_result.rows, table_result.notes = identifier, rows, notes
                table_result.bytes, table_result.sha256 = write_file(os.path.join(path, table_result.file), data)
            except (FulcrumAuthError, FulcrumUnavailable):
                raise
            except (TableExportError, FulcrumError) as exc:
                table_result.error = str(exc)
            result.tables.append(table_result)
            if table_result.error:
                log(f"  [{index}/{len(plan.tables)}] FAIL {table.name}: {table_result.error}")
            elif verbose:
                log(f"  [{index}/{len(plan.tables)}] {table_result.file} -- {table_result.rows} rows"
                    + (f" ({'; '.join(table_result.notes)})" if table_result.notes else ""))
        tables_finished = True
        if attachments is not None and result.complete:
            # Only for a complete cycle: an incomplete one is never
            # delivered, so its downloads would be wasted.
            attachment_rows = attachments.run(result, plan, namer)
        loop_finished = True
    except (FulcrumAuthError, FulcrumUnavailable) as exc:
        result.aborted = str(exc)
        raise
    finally:
        result.finished_at = datetime.now(timezone.utc)
        if not loop_finished and not result.aborted:
            result.aborted = ("interrupted while fetching attachments" if tables_finished
                              else "interrupted before every table was exported")
        write_manifest(result, plan.skipped, attachment_rows)
        write_schema(result, plan)
        if loop_finished and result.complete:
            summary = (
                f"{folder}\n"
                f"{len(result.tables)} tables, {result.total_rows} rows\n"
                + (f"{len(attachment_rows)} attachment files\n" if result.attachments is not None else "")
                + f"exported {started.isoformat()} to {result.finished_at.isoformat()}\n"
            )
            write_file(os.path.join(path, SUCCESS_NAME), summary.encode("utf-8"))
    return result
