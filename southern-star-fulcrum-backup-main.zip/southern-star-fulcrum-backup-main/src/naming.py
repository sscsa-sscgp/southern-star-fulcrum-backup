"""File and folder names for a backup cycle.

Every name comes from a config template (the naming section). The defaults,
which match the sample backups Southern Star already has, look like:

    backup_20261015_2000_CT/
      master_well_data__20261015_2000.csv
      master_well_data__surface_valves_data_v2__20261015_2000.csv

Each file name carries the app identifier and the timestamp on its own
(acceptance criterion 2), so a file still identifies itself if Southern Star
moves it out of the cycle folder.
"""

import importlib.util
import os
import re
import sys
import unicodedata
import zoneinfo
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

DEFAULTS = {
    # Names are in Central time. America/Chicago follows
    # daylight saving, so the "CT" in the folder name is deliberately not
    # "CST" or "CDT".
    "timezone": "America/Chicago",
    "stamp_format": "%Y%m%d_%H%M",
    "cycle_folder": "backup_{stamp}_CT",
    "table_file": "{app}__{stamp}.csv",
    "child_table_file": "{app}__{child}__{stamp}.csv",
    # Record attachments, in the cycle's attachments/ folder. App and record
    # in the name tie each file to its parent (acceptance criterion 4); the
    # attachment ID keeps two files of one record apart and matches
    # the ID column in the CSVs. The original file name is left out by
    # default: it would push paths past Windows' 260-character limit, and
    # _ATTACHMENTS.csv carries it. {name} adds a shortened copy if wanted.
    "attachment_file": "{app}__{record_id}__{attachment_id}{ext}",
}

#: Placeholders an attachment_file template may use, and the ones it must.
ATTACHMENT_PLACEHOLDERS = ("app", "record_id", "attachment_id", "name", "ext")
ATTACHMENT_REQUIRED = ("app", "record_id", "attachment_id")

#: {name} is cut to this many characters, before the extension.
MAX_NAME_STEM = 60


class NamingError(Exception):
    """A naming template or timezone in config is unusable."""


def _has_tz_database():
    """True if zoneinfo has timezone data to read.

    Linux and macOS ship one (zoneinfo.TZPATH); Windows doesn't, so there the
    tzdata package is the only source.
    """
    if importlib.util.find_spec("tzdata") is not None:
        return True
    return any(os.path.isdir(path) for path in zoneinfo.TZPATH)


def _install_command():
    """The pip command for the Python that is running, ready to paste.

    It names this interpreter's path, because the usual cause is a second
    Python: a system `python` that has tzdata next to a `.venv` that doesn't.
    """
    exe = sys.executable
    if " " in exe:
        exe = f'& "{exe}"'   # PowerShell needs the call operator before a quoted path
    return f"{exe} -m pip install -r requirements.txt"


def slugify(text):
    """ASCII, lowercase, underscores: 'Form 42 SSCGP' -> 'form_42_sscgp'.

    Southern Star's app names include a leading non-breaking space, '&',
    brackets and parentheses. None of that belongs in
    a file name that a SQL Server job has to parse.
    """
    normalized = unicodedata.normalize("NFKD", text or "")
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-z0-9]+", "_", ascii_text.lower()).strip("_")
    return slug or "unnamed"


def split_file_name(name):
    """('SW_33_HIGH_SEAL_TEST', '.pdf') from 'SW 33 HIGH SEAL TEST.pdf'.

    Both parts are made safe for Windows and SFTP: ASCII letters, digits,
    '.', '-' and '_' only. Field crews name files freely ('s.s elk#33 void
    test fail.xlsx', 29 Sep 2026). An extension that isn't short and
    alphanumeric is dropped rather than trusted.
    """
    normalized = unicodedata.normalize("NFKD", name or "")
    ascii_name = normalized.encode("ascii", "ignore").decode("ascii").strip()
    stem, ext = os.path.splitext(ascii_name)
    if not re.fullmatch(r"\.[A-Za-z0-9]{1,10}", ext or ""):
        stem, ext = ascii_name, ""
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", stem).strip("._-")[:MAX_NAME_STEM].rstrip("._-")
    return stem or "file", ext.lower()


class Namer:
    """Builds cycle-folder and file names from the `naming` config section."""

    def __init__(self, naming_config=None, tag=None):
        cfg = dict(DEFAULTS)
        cfg.update({key: value for key, value in (naming_config or {}).items() if value})
        try:
            self.tz = ZoneInfo(cfg["timezone"])
        except (ZoneInfoNotFoundError, ValueError):
            if not _has_tz_database():
                raise NamingError(
                    f"no timezone database: the tzdata package is not installed in "
                    f"{sys.executable} -- install the requirements into that Python: "
                    f"{_install_command()}"
                )
            raise NamingError(
                f"unknown timezone {cfg['timezone']!r} in naming.timezone -- use an "
                f"IANA name such as America/Chicago"
            )
        self.stamp_format = cfg["stamp_format"]
        self._templates = {
            "cycle_folder": cfg["cycle_folder"],
            "table_file": cfg["table_file"],
            "child_table_file": cfg["child_table_file"],
        }
        self._attachment_template = cfg["attachment_file"]
        self.tag = slugify(tag) if tag else None
        self._validate()
        self._validate_attachment_template()

    def _validate(self):
        samples = {"stamp": "20260101_0000", "app": "app", "child": "child"}
        for key, template in self._templates.items():
            try:
                name = template.format(**samples)
            except (KeyError, IndexError, ValueError) as exc:
                raise NamingError(
                    f"naming.{key} template {template!r} is invalid ({exc}); "
                    f"allowed placeholders are {{stamp}}, {{app}} and {{child}}"
                )
            if "/" in name or "\\" in name:
                raise NamingError(f"naming.{key} template {template!r} must not contain a path separator")
            if "{stamp}" not in template:
                raise NamingError(f"naming.{key} template {template!r} must include {{stamp}} (acceptance criterion 2)")

    def _validate_attachment_template(self):
        template = self._attachment_template
        allowed = ", ".join(f"{{{key}}}" for key in ATTACHMENT_PLACEHOLDERS)
        try:
            name = template.format(**{key: key for key in ATTACHMENT_PLACEHOLDERS})
        except (KeyError, IndexError, ValueError) as exc:
            raise NamingError(f"naming.attachment_file template {template!r} is invalid ({exc}); "
                              f"allowed placeholders are {allowed}")
        if "/" in name or "\\" in name:
            raise NamingError(f"naming.attachment_file template {template!r} must not contain a path separator")
        missing = [f"{{{key}}}" for key in ATTACHMENT_REQUIRED if f"{{{key}}}" not in template]
        if missing:
            raise NamingError(f"naming.attachment_file template {template!r} must include {', '.join(missing)}: "
                              f"each file has to name its app and record (acceptance criterion 4)")

    def stamp(self, when):
        """`when` is a timezone-aware datetime; rendered in the configured zone."""
        return when.astimezone(self.tz).strftime(self.stamp_format)

    def cycle_folder(self, stamp):
        name = self._templates["cycle_folder"].format(stamp=stamp, app="", child="")
        return f"{self.tag}_{name}" if self.tag else name

    def table_file(self, app_slug, stamp):
        return self._templates["table_file"].format(app=app_slug, stamp=stamp, child="")

    def child_table_file(self, app_slug, child_slug, stamp):
        return self._templates["child_table_file"].format(app=app_slug, child=child_slug, stamp=stamp)

    def attachment_file(self, app_slug, record_id, attachment_id, original_name):
        """File name for one attachment. The IDs are Fulcrum UUIDs, already
        safe; the original name is sanitized (split_file_name)."""
        stem, ext = split_file_name(original_name)
        return self._attachment_template.format(
            app=app_slug, record_id=record_id, attachment_id=attachment_id, name=stem, ext=ext)
