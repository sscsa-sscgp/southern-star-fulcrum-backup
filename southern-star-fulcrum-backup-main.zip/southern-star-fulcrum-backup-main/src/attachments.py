"""Record attachments for a backup cycle.

The files attached to records (PDFs, scans, DOCX, ...) go alongside
the CSVs, each named so it ties back to its record and app, and a cycle
sends only files that are new or changed, with a full snapshot on demand.

Where the attachment IDs come from. The Attachments API cannot list an app's
record attachments: it lists them per record_id, and with form_id it returns
the app's reference files instead (OpenAPI, GET /v2/attachments). But the
cycle's own CSVs already name every attachment. Each AttachmentField exports
two columns into its app or repeatable table:

    <data_name>        the attachment IDs       (`columns`.part empty)
    <data_name>_names  the original file names  (`columns`.part "names")

So the IDs are read from the CSVs, and only attachments this landing zone
doesn't have yet are looked up and downloaded: one listing call per record
with something new, nothing for the rest.

New or changed. Fulcrum keeps a file under its attachment ID; a changed file
is a new upload with a new ID. "Not yet delivered here", by ID, therefore
covers new or changed, and --full-snapshot re-sends everything anyway.

The state, state/attachments-<env>[-<tag>].json, lists what each landing
zone already holds. It changes only once that landing zone has the cycle's
_SUCCESS (record_delivery), so a failed delivery just re-sends next cycle.
Tagged cycles keep their own state, so a dev cycle on UAT can't hide a file
from a real UAT cycle.

Each cycle's _ATTACHMENTS.csv has one row per attachment its CSVs reference:
  NEW      the file is in this cycle's attachments/ folder
  EARLIER  delivered before, in the cycle named in delivered_in
  PENDING  Fulcrum doesn't have the whole file yet; tried again next cycle
  MISSING  a record references it, but Fulcrum has no such attachment -- often
           not uploaded yet (a record syncs before its files); tried again
  FAILED   the download failed; tried again next cycle
"""

import csv
import hashlib
import json
import os
import re
import time
from dataclasses import dataclass
from datetime import datetime, timezone

import requests

from src.export import MANIFEST_NAME, SCHEMA_NAME, long_path, write_csv, write_file
from src.fulcrum_client import FulcrumAuthError, FulcrumError, FulcrumNotFound, FulcrumUnavailable

ATTACHMENTS_DIR = "attachments"
INDEX_NAME = "_ATTACHMENTS.csv"
#: Local only (a dot-file, never uploaded): which landing zone's state the
#: cycle's NEW set was worked out against.
BASIS_NAME = ".attachments.json"

UUID_RE = re.compile(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")

INDEX_FIELDS = [
    "attachment_id", "status", "file", "delivered_in", "app_name", "app_id", "record_id",
    "child_record_id", "table", "column", "name", "bytes", "sha256", "uploaded_at", "references", "error",
]

STATUS_WORDS = {
    "NEW": "new", "EARLIER": "already delivered", "PENDING": "still uploading to Fulcrum",
    "MISSING": "not in Fulcrum", "FAILED": "failed",
}


class AttachmentStateError(Exception):
    """The state file can't be read or written."""


class DownloadError(Exception):
    """A file could not be fetched from storage."""


class UrlExpired(DownloadError):
    """The signed URL was refused; a fresh one from the API may work."""


@dataclass
class Source:
    """One exported CSV that has attachment ID columns."""
    table: str
    path: str
    app_name: str
    app_id: str
    app_slug: str
    columns: list


@dataclass
class AttachmentEntry:
    attachment_id: str
    app_name: str
    app_id: str
    app_slug: str
    record_id: str
    child_record_id: str
    table: str
    column: str
    references: int = 1
    status: str = ""
    file: str = ""           # attachments/<name>, relative to its cycle folder
    delivered_in: str = ""   # the cycle folder that holds the file
    name: str = ""           # original file name
    bytes: int | None = None
    sha256: str = ""
    uploaded_at: str = ""
    error: str = ""


# ---------------------------------------------------------------------------
# Finding the IDs
# ---------------------------------------------------------------------------

def id_columns_from_schema(schema_rows):
    """{table name: [attachment ID columns]} from `columns` catalog rows."""
    found = {}
    for row in schema_rows or ():
        if str(row.get("field_type") or "") != "AttachmentField" or (row.get("part") or ""):
            continue
        table = str(row.get("table_name") or row.get("table") or "")
        name = str(row.get("name") or row.get("column_name") or "")
        if table and name:
            found.setdefault(table, []).append(name)
    return found


def _header(path):
    with open(long_path(path), newline="", encoding="utf-8-sig") as fh:
        return next(csv.reader(fh), [])


def _by_header(candidates, wanted):
    """Without a catalog: a table carries an attachment field when its CSV
    has a column named exactly after the field (the IDs; the names column
    has a _names suffix). candidates are (table, csv path, app_id) and
    wanted maps app_id to the app's attachment field names."""
    found = {}
    for table, path, app_id in candidates:
        names = wanted.get(app_id)
        if names:
            columns = [column for column in _header(path) if column in names]
            if columns:
                found[table] = columns
    return found


def sources_for_cycle(result, plan):
    """The CSVs of an export in progress that carry attachment IDs."""
    done = [r for r in result.tables if r.ok]
    columns = id_columns_from_schema(plan.schema_rows)
    if not columns:
        wanted = {}
        for table, _reason in plan.skipped:
            if table.field_type == "AttachmentField":
                wanted.setdefault(table.app.id, set()).add(table.data_name)
        columns = _by_header([(r.table.name, os.path.join(result.path, r.file), r.table.app.id) for r in done], wanted)
    return [
        Source(r.table.name, os.path.join(result.path, r.file), r.table.app.name, r.table.app.id, r.table.app.slug,
               columns[r.table.name])
        for r in done if columns.get(r.table.name)
    ]


def _read_csv(path):
    with open(long_path(path), newline="", encoding="utf-8-sig") as fh:
        return list(csv.DictReader(fh))


def sources_from_folder(cycle_path):
    """The same, from a finished cycle folder: _MANIFEST.csv says which file
    holds which table, _SCHEMA.csv which columns hold attachment IDs."""
    manifest = _read_csv(os.path.join(cycle_path, MANIFEST_NAME))
    tables = [row for row in manifest
              if row.get("status") == "OK" and row.get("file") and row.get("field_type") != "AttachmentField"]
    schema_path = os.path.join(cycle_path, SCHEMA_NAME)
    columns = id_columns_from_schema(_read_csv(schema_path)) if os.path.isfile(schema_path) else {}
    if not columns:
        wanted = {}
        for row in manifest:
            if row.get("status") == "SKIPPED" and row.get("field_type") == "AttachmentField":
                wanted.setdefault(row.get("app_id"), set()).add(row.get("data_name"))
        columns = _by_header([(row["table"], os.path.join(cycle_path, row["file"]), row.get("app_id")) for row in tables],
                             wanted)
    return [
        Source(row["table"], os.path.join(cycle_path, row["file"]), row.get("app_name", ""), row.get("app_id", ""),
               "", columns[row["table"]])
        for row in tables if columns.get(row["table"])
    ]


def scan(sources):
    """Every attachment the CSVs reference, once each, in the order first
    seen. Returns (entries, unparsed): unparsed counts non-empty cells in an
    ID column that held no attachment ID at all.

    IDs are picked out by their UUID shape, so a cell holding several of
    them parses the same whether Fulcrum joined them with commas or wrote an
    array literal.
    """
    entries, unparsed = {}, 0
    for source in sources:
        with open(long_path(source.path), newline="", encoding="utf-8-sig") as fh:
            for row in csv.DictReader(fh):
                for column in source.columns:
                    cell = row.get(column) or ""
                    ids = UUID_RE.findall(cell)
                    if cell.strip() and not ids:
                        unparsed += 1
                    for attachment_id in ids:
                        attachment_id = attachment_id.lower()
                        entry = entries.get(attachment_id)
                        if entry is not None:
                            entry.references += 1
                            continue
                        entries[attachment_id] = AttachmentEntry(
                            attachment_id=attachment_id,
                            app_name=source.app_name,
                            app_id=source.app_id,
                            app_slug=source.app_slug,
                            record_id=(row.get("_record_id") or "").strip(),
                            child_record_id=(row.get("_child_record_id") or "").strip(),
                            table=source.table,
                            column=column,
                        )
    return list(entries.values()), unparsed


# ---------------------------------------------------------------------------
# What a landing zone already holds
# ---------------------------------------------------------------------------

class AttachmentState:
    """attachment ID -> where it went, for one landing zone (and tag)."""

    def __init__(self, path):
        self.path = path
        self.entries = {}
        if os.path.isfile(path):
            try:
                with open(path, encoding="utf-8") as fh:
                    self.entries = json.load(fh).get("attachments") or {}
            except (OSError, ValueError, AttributeError) as exc:
                raise AttachmentStateError(
                    f"cannot read {path} ({exc}). Move it aside to start over: the next cycle then "
                    f"sends every attachment again, which is safe")

    @staticmethod
    def path_for(state_dir, env, tag=None):
        return os.path.join(state_dir, f"attachments-{env}{'-' + tag if tag else ''}.json")

    def delivered(self, attachment_id):
        return self.entries.get(attachment_id)

    def save(self):
        body = {"updated_at": datetime.now(timezone.utc).isoformat(), "attachments": self.entries}
        try:
            os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
            write_file(self.path, json.dumps(body, indent=1, sort_keys=True).encode("utf-8"))
        except OSError as exc:
            raise AttachmentStateError(f"cannot write {self.path} -- {exc}")


def read_basis(cycle_path):
    path = os.path.join(cycle_path, BASIS_NAME)
    if not os.path.isfile(path):
        return None
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def basis_problem(cycle_path, env):
    """Why this cycle must not go to env, or "" if it may.

    Its NEW set was worked out against one landing zone's state. Sent to
    another, that landing zone would miss every file it never received.
    """
    basis = read_basis(cycle_path)
    if not basis or basis.get("full_snapshot") or basis.get("env") == env:
        return ""
    return (f"its attachments were chosen against what {str(basis.get('env')).upper()} already has, so "
            f"{env.upper()} would miss files. Export again with --env {env}, or with --full-snapshot")


def record_delivery(cycle_path, env, state_dir):
    """After the landing zone has this cycle's _SUCCESS: note its NEW files
    there. Returns (count, state path); count 0 when there is nothing to note."""
    basis = read_basis(cycle_path)
    index = os.path.join(cycle_path, INDEX_NAME)
    if basis is None or not os.path.isfile(index):
        return 0, ""
    new = [row for row in _read_csv(index) if row.get("status") == "NEW"]
    if not new:
        return 0, ""
    state = AttachmentState(AttachmentState.path_for(state_dir, env, basis.get("tag")))
    folder = os.path.basename(os.path.normpath(cycle_path))
    now = datetime.now(timezone.utc).isoformat()
    for row in new:
        state.entries[row["attachment_id"]] = {
            "cycle": folder, "file": row.get("file", ""), "bytes": int(row["bytes"]) if row.get("bytes") else None,
            "sha256": row.get("sha256", ""), "name": row.get("name", ""), "record_id": row.get("record_id", ""),
            "app_id": row.get("app_id", ""), "uploaded_at": row.get("uploaded_at", ""), "delivered_at": now,
        }
    state.save()
    return len(new), state.path


# ---------------------------------------------------------------------------
# Metadata and downloads
# ---------------------------------------------------------------------------

def with_metadata(client, entries):
    """Yields (entry, metadata, problem) per entry. metadata is the
    Attachments API's dict; when it is None, problem is (status, reason).

    One listing call per record, then single lookups for anything the
    listing didn't return. After an auth or reachability error it stops
    calling the API and reports the rest as FAILED with that reason.
    """
    by_record = {}
    for entry in entries:
        by_record.setdefault(entry.record_id, []).append(entry)
    stopped = ""
    for record_id, group in by_record.items():
        listed = {}
        if record_id and not stopped:
            try:
                listed = {str(item.get("id") or "").lower(): item for item in client.record_attachments(record_id)}
            except (FulcrumAuthError, FulcrumUnavailable) as exc:
                stopped = str(exc)
            except FulcrumError:
                pass  # the single lookups below may still work
        for entry in group:
            if stopped:
                yield entry, None, ("FAILED", f"not tried: {stopped}")
                continue
            metadata = listed.get(entry.attachment_id)
            if metadata is None:
                try:
                    metadata = client.attachment(entry.attachment_id)
                except FulcrumNotFound:
                    # Often just not uploaded yet: a record syncs before its
                    # files do. On 29 Sep two of these in SIMP-1101 were in
                    # Fulcrum an hour later.
                    yield entry, None, ("MISSING", "a record references it, but Fulcrum has no such attachment "
                                                   "(not uploaded yet, or deleted); tried again next cycle")
                    continue
                except (FulcrumAuthError, FulcrumUnavailable) as exc:
                    stopped = str(exc)
                    yield entry, None, ("FAILED", str(exc))
                    continue
                except FulcrumError as exc:
                    yield entry, None, ("FAILED", str(exc))
                    continue
            yield entry, metadata, None


def _size(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def apply_metadata(entry, metadata):
    """Copy what the API says onto the entry. Returns the reason the file
    can't be downloaded yet, or "" if it can."""
    entry.name = str(metadata.get("name") or "")
    entry.uploaded_at = str(metadata.get("uploaded_at") or "")
    entry.bytes = _size(metadata.get("file_size"))
    if not entry.record_id:
        entry.record_id = str(metadata.get("attached_to_id") or "")
    # `complete` decides when present; `status` only when it isn't, so an
    # unfamiliar status word can't hold a finished file back for good.
    complete, status = metadata.get("complete"), str(metadata.get("status") or "").lower()
    if complete is False or (complete is None and status not in ("", "complete")):
        return f"Fulcrum doesn't have the whole file yet (status {status or 'unknown'!r})"
    if not metadata.get("url"):
        return "Fulcrum gave no download URL yet"
    return ""


class Downloader:
    """Fetches files from their signed storage URLs.

    Uses its own session, without Fulcrum's headers: the URL is signed, and
    the API token has no business travelling to the storage host.
    """

    def __init__(self, session=None, timeout=(20, 300), max_attempts=3, log=print):
        self._session = session if session is not None else requests.Session()
        self.timeout = timeout
        self.max_attempts = max_attempts
        self._log = log
        self._sleep = time.sleep

    def fetch(self, url, dest, expected_size=None):
        """Download to dest (via dest.part). Returns (bytes, sha256)."""
        if not str(url).lower().startswith("https://"):
            raise DownloadError("the download URL is not https; refusing it")
        backoff = 2
        for attempt in range(1, self.max_attempts + 1):
            try:
                return self._fetch_once(url, dest, expected_size)
            except UrlExpired:
                raise
            except DownloadError as exc:
                if attempt == self.max_attempts:
                    raise
                self._log(f"  [attachments] {os.path.basename(dest)}: {exc}; retrying in {backoff}s "
                          f"(attempt {attempt}/{self.max_attempts})")
                self._sleep(backoff)
                backoff *= 2
        raise DownloadError("unreachable")

    def _fetch_once(self, url, dest, expected_size):
        part = dest + ".part"
        digest, size = hashlib.sha256(), 0
        try:
            resp = self._session.get(url, stream=True, timeout=self.timeout)
            try:
                if resp.status_code in (401, 403):
                    raise UrlExpired(f"HTTP {resp.status_code} from storage (the signed URL has probably expired)")
                if resp.status_code != 200:
                    raise DownloadError(f"HTTP {resp.status_code} from storage")
                with open(long_path(part), "wb") as fh:
                    for chunk in resp.iter_content(chunk_size=1 << 16):
                        if chunk:
                            fh.write(chunk)
                            digest.update(chunk)
                            size += len(chunk)
            finally:
                resp.close()
        except requests.exceptions.RequestException as exc:
            raise DownloadError(f"download failed -- {exc}")
        except OSError as exc:
            # Disk full, or a path the OS refuses: fail this file, keep the cycle.
            raise DownloadError(f"cannot write {part} -- {exc}")
        if expected_size is not None and size != expected_size:
            os.remove(long_path(part))
            raise DownloadError(f"got {size} bytes, but Fulcrum lists the file as {expected_size}")
        os.replace(long_path(part), long_path(dest))
        return size, digest.hexdigest()


# ---------------------------------------------------------------------------
# The step export_cycle runs
# ---------------------------------------------------------------------------

class AttachmentStep:
    """After the tables: download the attachments this landing zone lacks.

    env and tag name the state the cycle is compared with, i.e. where the
    cycle is meant to go. full_snapshot downloads everything regardless.
    """

    def __init__(self, client, state, env, tag=None, full_snapshot=False, downloader=None,
                 log=print, verbose=False):
        self.client = client
        self.state = state
        self.env = env
        self.tag = tag
        self.full_snapshot = full_snapshot
        self.downloader = downloader if downloader is not None else Downloader(log=log)
        self.log = log
        self.verbose = verbose

    def run(self, result, plan, namer):
        """Download into <cycle>/attachments/ and write _ATTACHMENTS.csv.
        Returns the manifest rows of the files downloaded."""
        entries, unparsed = scan(sources_for_cycle(result, plan))
        wanted = []
        for entry in entries:
            earlier = None if self.full_snapshot else self.state.delivered(entry.attachment_id)
            if earlier:
                entry.status, entry.file, entry.delivered_in = "EARLIER", earlier.get("file", ""), earlier.get("cycle", "")
                entry.name, entry.bytes = earlier.get("name", ""), earlier.get("bytes")
                entry.sha256, entry.uploaded_at = earlier.get("sha256", ""), earlier.get("uploaded_at", "")
            else:
                wanted.append(entry)
        if wanted:
            os.makedirs(os.path.join(result.path, ATTACHMENTS_DIR), exist_ok=True)
        for entry, metadata, problem in with_metadata(self.client, wanted):
            if problem:
                entry.status, entry.error = problem
            else:
                self._download(entry, metadata, result, namer)
            if self.verbose or entry.status == "FAILED":
                self.log(f"  [attachments] {entry.status} {entry.app_name} / {entry.name or entry.attachment_id}"
                         + (f" -- {entry.error}" if entry.error else ""))
        if unparsed:
            self.log(f"  [attachments] WARN: {unparsed} cell(s) in attachment columns held no attachment ID")
        result.attachments = entries
        write_index(result.path, entries)
        with open(os.path.join(result.path, BASIS_NAME), "w", encoding="utf-8") as fh:
            json.dump({"env": self.env, "tag": self.tag, "full_snapshot": self.full_snapshot,
                       "state": os.path.basename(self.state.path)}, fh, indent=2)
        return manifest_rows(entries)

    def _download(self, entry, metadata, result, namer):
        entry.status, entry.error = "PENDING", apply_metadata(entry, metadata)
        if entry.error:
            return
        file_name = namer.attachment_file(entry.app_slug, entry.record_id, entry.attachment_id, entry.name)
        dest = os.path.join(result.path, ATTACHMENTS_DIR, file_name)
        try:
            try:
                size, digest = self.downloader.fetch(metadata["url"], dest, entry.bytes)
            except UrlExpired:
                fresh = self.client.attachment(entry.attachment_id)
                size, digest = self.downloader.fetch(fresh.get("url") or "", dest, entry.bytes)
        except (DownloadError, FulcrumError) as exc:
            entry.status, entry.error = "FAILED", str(exc)
            return
        entry.status, entry.error = "NEW", ""
        entry.file, entry.delivered_in = f"{ATTACHMENTS_DIR}/{file_name}", result.folder
        entry.bytes, entry.sha256 = size, digest


def write_index(cycle_path, entries):
    rows = [{
        "attachment_id": e.attachment_id, "status": e.status, "file": e.file, "delivered_in": e.delivered_in,
        "app_name": e.app_name, "app_id": e.app_id, "record_id": e.record_id, "child_record_id": e.child_record_id,
        "table": e.table, "column": e.column, "name": e.name, "bytes": "" if e.bytes is None else e.bytes,
        "sha256": e.sha256, "uploaded_at": e.uploaded_at, "references": e.references, "error": e.error,
    } for e in entries]
    write_csv(os.path.join(cycle_path, INDEX_NAME), INDEX_FIELDS, rows)


def manifest_rows(entries):
    """One OK manifest row per downloaded file, so delivery sends it and
    checks its size like any table's."""
    return [{
        "file": e.file, "status": "OK", "app_name": e.app_name, "app_id": e.app_id, "table": e.table,
        "data_name": e.column, "field_type": "AttachmentField", "identifier": e.attachment_id,
        "bytes": e.bytes, "sha256": e.sha256, "notes": f"attachment of record {e.record_id}",
    } for e in entries if e.status == "NEW"]


def describe(entries):
    """'3 new (1,204 bytes), 12 already delivered, 1 failed' -- zero counts left out."""
    counts = {status: 0 for status in STATUS_WORDS}
    for entry in entries:
        counts[entry.status] = counts.get(entry.status, 0) + 1
    new_bytes = sum(e.bytes or 0 for e in entries if e.status == "NEW")
    parts = [f"{counts['NEW']} new ({new_bytes:,} bytes)"]
    parts += [f"{counts[status]} {words}" for status, words in STATUS_WORDS.items()
              if status != "NEW" and counts.get(status)]
    return ", ".join(parts)


# ---------------------------------------------------------------------------
# Inventory: count and size, downloading nothing
# ---------------------------------------------------------------------------

@dataclass
class Inventory:
    cycle: str
    entries: list
    unparsed: int
    columns: int     # attachment ID columns found in the cycle's CSVs
    tables: int      # tables that have them


def inventory(client, cycle_path, state=None):
    """What a full snapshot of this cycle's attachments amounts to, from the
    API's metadata. Read-only: downloads nothing, changes no state. With a
    state, entries already delivered there are marked EARLIER."""
    sources = sources_from_folder(cycle_path)
    entries, unparsed = scan(sources)
    for entry, metadata, problem in with_metadata(client, entries):
        if problem:
            entry.status, entry.error = problem
            continue
        reason = apply_metadata(entry, metadata)
        if reason:
            entry.status, entry.error = "PENDING", reason
        elif state is not None and state.delivered(entry.attachment_id):
            entry.status = "EARLIER"
        else:
            entry.status = "NEW"
    return Inventory(cycle=os.path.basename(os.path.normpath(cycle_path)), entries=entries, unparsed=unparsed,
                     columns=sum(len(s.columns) for s in sources), tables=len(sources))
