"""SFTP connection to Southern Star's landing zone.

What this module relies on:

  * the host accepts US addresses only, so a connect timeout from outside
    Southern Star's network usually means the machine isn't allowed in;
  * SFTP works, with password auth, and the account may create folders,
    upload, rename, read and delete in its own folder.

The server key must be pinned (sftp.host_key_fingerprint) and is checked
BEFORE any password is sent. Delivery refuses to run unpinned: an unverified
server would receive Southern Star's full dataset.
"""

import base64
import hashlib
import os
import posixpath
import socket

import paramiko

#: Seconds between SSH keepalives, so a long delivery isn't dropped as idle.
KEEPALIVE_SECONDS = 30


class LandingError(Exception):
    """The landing zone could not be reached, verified or logged into. Nothing
    was sent."""


class UploadError(Exception):
    """An operation on the landing zone failed partway through a delivery."""


def host_key_fingerprint(key):
    """OpenSSH-style fingerprint, e.g. SHA256:ZpHgDxZH3SwM..."""
    digest = hashlib.sha256(key.asbytes()).digest()
    return "SHA256:" + base64.b64encode(digest).decode("ascii").rstrip("=")


def _open_socket(host, port, timeout):
    try:
        return socket.create_connection((host, port), timeout=timeout)
    except socket.gaierror as exc:
        raise LandingError(f"DNS resolution failed for {host} -- {exc}")
    except socket.timeout:
        raise LandingError(
            f"connection to {host}:{port} timed out -- the host only accepts US "
            f"addresses -- check the firewall between this machine and the host"
        )
    except ConnectionRefusedError:
        raise LandingError(f"connection to {host}:{port} refused -- wrong port, or the service is down")
    except OSError as exc:
        raise LandingError(f"connection to {host}:{port} failed -- {exc}")


def connect(host, port, username, password, pinned_fingerprint, timeout=20):
    """Open an authenticated SFTP session. Returns a Landing (a context manager)."""
    if not pinned_fingerprint:
        raise LandingError(
            "sftp.host_key_fingerprint is not set. Copy it from config.example.yaml "
            "(or get it from the server's owner) and retry -- delivery will not send "
            "Southern Star's data to a server it has not verified."
        )
    transport = paramiko.Transport(_open_socket(host, port, timeout))
    transport.banner_timeout = timeout
    try:
        transport.start_client(timeout=timeout)
    except (paramiko.SSHException, EOFError, OSError) as exc:
        transport.close()
        raise LandingError(f"SSH handshake with {host}:{port} failed -- {exc}")

    fingerprint = host_key_fingerprint(transport.get_remote_server_key())
    if fingerprint != pinned_fingerprint.strip():
        transport.close()
        raise LandingError(
            f"host key MISMATCH: {host} presented {fingerprint}, config pins "
            f"{pinned_fingerprint}. Nothing was sent. Confirm with the server's owner "
            f"that the key change is expected before re-pinning."
        )

    try:
        # fallback=True retries as keyboard-interactive, which some managed
        # file-transfer servers require instead of plain password auth.
        transport.auth_password(username, password, fallback=True)
    except paramiko.BadAuthenticationType as exc:
        transport.close()
        raise LandingError(f"{host} does not accept password auth for {username!r} -- allowed: {exc.allowed_types}")
    except paramiko.AuthenticationException:
        transport.close()
        raise LandingError(f"authentication failed for {username!r} -- wrong password, or the account is not enabled")
    except (paramiko.SSHException, EOFError, OSError) as exc:
        transport.close()
        raise LandingError(f"authentication error for {username!r} -- {exc}")

    transport.set_keepalive(KEEPALIVE_SECONDS)
    try:
        sftp = paramiko.SFTPClient.from_transport(transport)
    except (paramiko.SSHException, EOFError, OSError) as exc:
        sftp, cause = None, f" ({exc})"
    else:
        cause = ""
    if sftp is None:
        transport.close()
        raise LandingError(f"logged in as {username!r}, but {host} refused the SFTP subsystem{cause}")
    return Landing(transport, sftp)


class Landing:
    """The operations a delivery needs, on one authenticated SFTP session."""

    def __init__(self, transport, sftp):
        self.transport = transport
        self.sftp = sftp

    def close(self):
        self.sftp.close()
        self.transport.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def resolve(self, path):
        """Absolute remote path ("." is the account's home, `/` on UAT)."""
        return self.sftp.normalize(path)

    def listing(self, path):
        """{name: size} for a remote folder, or None if it does not exist."""
        try:
            return {entry.filename: entry.st_size for entry in self.sftp.listdir_attr(path)}
        except FileNotFoundError:
            return None
        except (IOError, OSError) as exc:
            raise UploadError(f"cannot list {path} -- {exc}")

    def ensure_dir(self, path):
        try:
            self.sftp.stat(path)
        except FileNotFoundError:
            try:
                self.sftp.mkdir(path)
            except (IOError, OSError) as exc:
                raise UploadError(f"cannot create {path} -- {exc}")

    def upload(self, local_path, remote_path, replace=False):
        """Upload as <remote_path>.part, check the size, then rename.

        replace=True removes an existing remote_path first. Only ever used for
        a file of the cycle being delivered, left behind with the wrong size by
        an interrupted delivery -- ours to replace. Returns bytes sent.
        """
        size = os.path.getsize(local_path)
        part = remote_path + ".part"
        name = posixpath.basename(remote_path)
        try:
            with open(local_path, "rb") as fh:
                self.sftp.putfo(fh, part, file_size=size, confirm=False)
            sent = self.sftp.stat(part).st_size
        except FileNotFoundError:
            raise UploadError(f"{name}: the upload vanished from the server -- does it move files away on arrival?")
        except (IOError, OSError) as exc:
            raise UploadError(f"{name}: upload failed -- {exc}")
        if sent != size:
            raise UploadError(f"{name}: sent {size} bytes but the server holds {sent}")
        try:
            if replace:
                self.sftp.remove(remote_path)
            self.sftp.rename(part, remote_path)
        except (IOError, OSError) as exc:
            try:
                # rename refuses to overwrite; posix-rename@openssh.com does not.
                self.sftp.posix_rename(part, remote_path)
            except (IOError, OSError):
                raise UploadError(f"{name}: could not rename {part} to its final name -- {exc}")
        return size
