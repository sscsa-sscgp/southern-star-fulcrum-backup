"""Config loading and validation for the backup.

Nothing environment-specific is hardcoded here: hosts, accounts, folders and
schedules all come from config/config.yaml and the environment, so the same
code runs on any machine.
"""

import os

import yaml

#: Keys whose values must never be printed, logged or put in a traceback.
SECRET_KEYS = frozenset({"password", "api_token"})

REDACTED = "***"

#: Secrets may come from the environment instead of config.yaml, so they never
#: have to sit in a file. The environment wins when both are set.
SECRET_ENV_OVERRIDES = {
    "fulcrum.api_token": "FULCRUM_API_TOKEN",
    "sftp.accounts.uat.password": "SFTP_UAT_PASSWORD",
    "sftp.accounts.prod.password": "SFTP_PROD_PASSWORD",
    "alerts.password": "SMTP_PASSWORD",
}

#: Required for the export.
REQUIRED_KEYS_EXPORT = ("fulcrum.api_token",)

#: The landing (SFTP) accounts: UAT for testing, Production for the real backups.
ENVIRONMENTS = ("uat", "prod")


def required_keys_delivery(env):
    """Keys a delivery to `env` needs. The pinned host key is checked by
    sftp_client.connect, which explains how to obtain it."""
    return ("sftp.host", f"sftp.accounts.{env}.username", f"sftp.accounts.{env}.password")


class ConfigError(Exception):
    """The config is missing or malformed. Always raised before any network
    call, so a bad config fails in a second rather than halfway through a run."""


#: Marks a value Southern Star still has to provide, e.g.
#: "<<SOUTHERN_STAR: SMTP sender address>>" (config/config.example.yaml).
PLACEHOLDER_MARK = "<<SOUTHERN_STAR:"


def is_placeholder(value):
    return isinstance(value, str) and PLACEHOLDER_MARK in value


def placeholders(config, env=None):
    """[(dotted key, placeholder text)] for every placeholder still in config.

    With env, the other landing account's section is left out: a run that
    delivers to Production doesn't need the UAT account filled in.
    """
    found = []

    def walk(node, prefix):
        for key, value in node.items():
            path = f"{prefix}{key}"
            if isinstance(value, dict):
                walk(value, f"{path}.")
            elif isinstance(value, list):
                found.extend((path, item) for item in value if is_placeholder(item))
            elif is_placeholder(value):
                found.append((path, value))

    walk(config or {}, "")
    if env:
        found = [(key, text) for key, text in found
                 if not key.startswith("sftp.accounts.") or key.startswith(f"sftp.accounts.{env}.")]
    return found


class PlaceholderError(ConfigError):
    """A real run with values Southern Star hasn't filled in yet."""

    def __init__(self, found, what="a real run"):
        lines = []
        for key, text in found:
            env_var = SECRET_ENV_OVERRIDES.get(key)
            lines.append(f"    {key}: {text}" + (f"  (or set {env_var})" if env_var else ""))
        super().__init__(
            f"{len(found)} value(s) in the config are still placeholders, so {what} won't start. "
            f"Fill them in first:\n" + "\n".join(lines)
            + "\n  A dry run (run --dry-run) works without them, except for the Fulcrum token.")


def dig(config, dotted_path, default=None):
    """Read a nested key by dotted path, e.g. 'export.staging_dir'."""
    node = config
    for part in dotted_path.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    return node


def _put(config, dotted_path, value):
    parts = dotted_path.split(".")
    node = config
    for part in parts[:-1]:
        if not isinstance(node.get(part), dict):
            node[part] = {}
        node = node[part]
    node[parts[-1]] = value


def load(path, required_keys=REQUIRED_KEYS_EXPORT):
    """Load and validate config.yaml. Returns the parsed dict.

    Every missing key is reported in one error rather than one per run --
    the alternative is discovering them one at a time against a live system.
    """
    try:
        with open(path, "r", encoding="utf-8") as fh:
            config = yaml.safe_load(fh) or {}
    except FileNotFoundError:
        raise ConfigError(
            f"No config file at {path}. Copy config/config.example.yaml to "
            "config/config.yaml and fill it in (config.yaml is git-ignored)."
        )
    except yaml.YAMLError as exc:
        raise ConfigError(f"{path} is not valid YAML -- {exc}")
    if not isinstance(config, dict):
        raise ConfigError(f"{path} must be a YAML mapping at the top level")

    for dotted, env_var in SECRET_ENV_OVERRIDES.items():
        if os.environ.get(env_var):
            _put(config, dotted, os.environ[env_var])

    require(config, required_keys)
    return config


def require(config, required_keys):
    """Raise ConfigError naming every missing key, and the environment
    variable that can supply it when there is one."""
    missing = [key for key in required_keys if not dig(config, key)]
    if missing:
        described = [
            f"{key} (or set {SECRET_ENV_OVERRIDES[key]})" if key in SECRET_ENV_OVERRIDES else key
            for key in missing
        ]
        raise ConfigError("missing/empty required config key(s): " + ", ".join(described))


def redacted_summary(config, prefix=""):
    """One line per leaf key, secrets shown as ***."""
    lines = []
    for key, value in sorted(config.items()):
        path = f"{prefix}{key}"
        if isinstance(value, dict):
            lines.append(redacted_summary(value, prefix=f"{path}."))
        elif key in SECRET_KEYS and value and not is_placeholder(value):
            lines.append(f"  {path}: {REDACTED}")
        else:
            lines.append(f"  {path}: {value!r}")
    return "\n".join(line for line in lines if line)
