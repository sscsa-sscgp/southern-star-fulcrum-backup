"""What a backup cycle exports: every app, and every one of its child tables.

Two sources, because neither is enough alone:

  * forms.json lists the apps, with created_at -- which settles slug collisions
    in a way that never renames an existing app's files; and
  * the Query API's `tables` system table lists the child tables: repeatables
    AND multi-value fields (photos, attachments, record links), each tagged
    with form_id, data_name and field_type. On 25 Sep 2026 Southern Star's org
    had 24 apps and 194 child tables.

Table identifiers are the delicate part. The Query API addresses a table by
name ("App Name/data_name"), by "<form ID>/<data_name>", or -- undocumented --
by "<form ID>/<element key>". Postgres caps identifiers at 63 BYTES, not
characters, and 12 of Southern Star's child-table names are longer. So each
table gets an ordered list of candidate identifiers.

What the identifier check against Southern Star's org showed (25 Sep 2026):
  * "<form ID>/<data_name>" and "<form ID>/<element key>" both resolve, for
    Repeatable, PhotoField and RecordLinkField tables; every long name
    resolved.
  * The limit is bytes: an app name starting with a non-breaking space (2
    bytes in UTF-8) made a 63-character name 64 bytes, and the server cut it.
  * The server rejects an over-long identifier with an explicit error rather
    than quietly truncating it onto another table. export.check_header still
    guards against a CSV that belongs to a different table; it is cheap.
  * AttachmentField tables cannot be queried at all -- see
    UNQUERYABLE_FIELD_TYPES.
"""

from dataclasses import dataclass, field

from src.fulcrum_client import FulcrumError
from src.naming import slugify

#: Postgres identifier limit (NAMEDATALEN - 1), in bytes of UTF-8.
MAX_IDENTIFIER = 63

#: Field types the Query API lists in `tables` but refuses to query. Every
#: AttachmentField table came back "HTTP 400 -- invalid field: <data_name>"
#: under every identifier form. They are skipped, not failed: the attachment
#: files, and the record each belongs to, come from the Attachments API
#: instead (src/attachments.py).
UNQUERYABLE_FIELD_TYPES = frozenset({"AttachmentField"})


@dataclass(eq=False)
class App:
    id: str
    name: str
    created_at: str = ""
    slug: str = ""


@dataclass(eq=False)
class ExportTable:
    app: App
    name: str                      # Query API name, e.g. "Master Well Data/tubulars"
    data_name: str | None = None   # None for the app's own table
    field_type: str | None = None  # e.g. Repeatable, PhotoField (child tables only)
    field_key: str | None = None   # element key, from `tables.field`
    candidates: tuple = ()         # identifiers to try, in order
    parent: str | None = None      # from `tables.parent`

    @property
    def is_child(self):
        return self.data_name is not None


@dataclass
class Plan:
    apps: list                      # App, the ones this cycle exports
    tables: list                    # ExportTable, sorted by app slug then child name
    excluded: list = field(default_factory=list)   # App, left out by export.exclude_apps
    uncovered: list = field(default_factory=list)  # (name, type) in `tables` but not exported
    skipped: list = field(default_factory=list)    # (ExportTable, reason): unqueryable field types
    columns: dict | None = None     # table name -> column names; None if unavailable
    schema_rows: list = field(default_factory=list)  # raw `columns` rows, for _SCHEMA.csv


def assign_slugs(apps):
    """Give every app a file-name slug, unique within the org.

    On a collision the OLDEST app keeps the bare slug and each newer one gets
    a short form-ID suffix. Adding an app later therefore never renames the
    files of an app that already exists -- the DBAs' ingestion keys on those
    names.
    """
    taken = set()
    for app in sorted(apps, key=lambda a: (a.created_at or "", a.id)):
        slug = slugify(app.name)
        if slug in taken:
            slug = f"{slug}_{app.id[:8]}"
        taken.add(slug)
        app.slug = slug
    return apps


def quote_identifier(identifier):
    """Double-quote a table identifier for the Query API's SQL."""
    return '"' + identifier.replace('"', '""') + '"'


def _dedupe(items):
    seen, out = set(), []
    for item in items:
        if item and item not in seen:
            seen.add(item)
            out.append(item)
    return tuple(out)


def identifier_length(identifier):
    """Length as Postgres counts it: bytes of UTF-8, not characters."""
    return len(identifier.encode("utf-8"))


def identifier_candidates(app, name=None, data_name=None, field_key=None):
    """The identifiers to try for one table, most reliable first.

    App tables: the form ID first. It is 36 characters, documented, and does
    not change when someone renames the app.

    Child tables: whatever fits in 63 bytes first (the documented name, then
    "<form ID>/<data_name>"), then "<form ID>/<element key>" (undocumented,
    but always 41 bytes, and verified against Southern Star's org), and only
    then the over-long forms, which the server is expected to reject.
    """
    if data_name is None:
        return _dedupe([app.id, app.name])
    by_id = f"{app.id}/{data_name}"
    fits = [c for c in (name, by_id) if c and identifier_length(c) <= MAX_IDENTIFIER]
    by_key = [f"{app.id}/{field_key}"] if field_key else []
    too_long = [c for c in (name, by_id) if c and identifier_length(c) > MAX_IDENTIFIER]
    return _dedupe(fits + by_key + too_long)


def attachment_column_home(table, columns):
    """Which exported table's CSV carries this attachment field as a column --
    i.e. where the record-to-attachment link survives even though the
    attachment table itself cannot be queried.

    Returns that table's name, "" when none of the app's tables has the
    column, or None when it cannot be told (no `columns` catalog).

    Fulcrum's `tables.parent` names the app even for a field that sits inside
    a repeatable (dry run, 25 Sep 2026: 19 of 32 looked "missing" until the
    repeatables were searched too), so every table of the app is searched:
    the named parent, the app's own table, then its child tables.
    """
    if columns is None:
        return None
    prefix = f"{table.app.name}/"
    children = sorted(name for name in columns if name.startswith(prefix) and name != table.name)
    for name in [table.parent, table.app.name] + children:
        cols = columns.get(name) if name else None
        if cols and any(c == table.data_name or c.startswith(f"{table.data_name}_") for c in cols):
            return name
    return ""


def _matches(app, selectors):
    """True if the app is named by any selector: exact form ID, or name
    compared case-insensitively with surrounding whitespace ignored (one of
    Southern Star's app names starts with a non-breaking space)."""
    name = app.name.strip().casefold()
    for selector in selectors or ():
        selector = str(selector).strip()
        if selector == app.id or selector.casefold() == name:
            return True
    return False


def load_columns(client, log=print):
    """Read the Query API `columns` system table.

    Returns (columns, rows): columns maps table name -> column names, and rows
    are the raw rows (written to _SCHEMA.csv). columns is None when the table is
    unavailable or has an unexpected shape -- the export still runs, but
    without header validation, and says so.
    """
    try:
        rows = client.query_rows("SELECT * FROM columns")
    except FulcrumError as exc:
        log(f"  [catalog] WARN: the `columns` catalog is unavailable ({exc}); CSV headers will not be validated")
        return None, []
    if not rows:
        log("  [catalog] WARN: the `columns` catalog is empty; CSV headers will not be validated")
        return None, []
    table_key = next((k for k in ("table_name", "table") if k in rows[0]), None)
    column_key = next((k for k in ("name", "column_name") if k in rows[0]), None)
    if not table_key or not column_key:
        log(f"  [catalog] WARN: `columns` has unexpected columns {sorted(rows[0])}; CSV headers will not be validated")
        return None, rows
    columns = {}
    for row in rows:
        columns.setdefault(str(row[table_key]), []).append(str(row[column_key]))
    return columns, rows


def build_plan(client, exclude=(), only=(), log=print):
    """Everything one cycle exports, in a stable order."""
    apps = [
        App(id=form["id"], name=form.get("name") or form["id"], created_at=form.get("created_at") or "")
        for form in client.forms()
        if form.get("id")
    ]
    # Slug the whole org, excluded apps included, so a slug never depends on
    # which apps a given config happens to leave out.
    assign_slugs(apps)
    all_ids = {app.id for app in apps}
    excluded = [app for app in apps if _matches(app, exclude)]
    selected = [app for app in apps if app not in excluded and (not only or _matches(app, only))]
    by_id = {app.id: app for app in selected}

    table_rows = client.query_rows("SELECT * FROM tables")
    columns, schema_rows = load_columns(client, log)

    tables = [ExportTable(app=app, name=app.name, candidates=identifier_candidates(app)) for app in selected]
    uncovered, skipped = [], []
    for row in table_rows:
        name = str(row.get("name") or "")
        form_id = row.get("form_id")
        if form_id not in all_ids:
            # System tables (photos, projects, ...), and apps forms.json does
            # not list, such as Issues and Tasks.
            uncovered.append((name, str(row.get("type") or "")))
            continue
        if "/" not in name:
            continue  # an app's own table; built from forms.json above
        app = by_id.get(form_id)
        if app is None:
            continue  # child of an excluded app, or outside --app
        data_name = row.get("data_name") or name.split("/", 1)[1]
        field_key = row.get("field") or None
        table = ExportTable(
            app=app,
            name=name,
            data_name=data_name,
            field_type=row.get("field_type"),
            field_key=field_key,
            candidates=identifier_candidates(app, name, data_name, field_key),
            parent=row.get("parent") or None,
        )
        if table.field_type in UNQUERYABLE_FIELD_TYPES:
            skipped.append((table, f"the Query API refuses {table.field_type} tables "
                                   f"('invalid field'); attachments come from the Attachments API"))
        else:
            tables.append(table)

    order = lambda t: (t.app.slug, t.is_child, t.data_name or "")  # noqa: E731
    tables.sort(key=order)
    skipped.sort(key=lambda item: order(item[0]))
    return Plan(
        apps=sorted(selected, key=lambda a: a.slug),
        tables=tables,
        excluded=excluded,
        uncovered=sorted(uncovered),
        skipped=skipped,
        columns=columns,
        schema_rows=schema_rows,
    )
