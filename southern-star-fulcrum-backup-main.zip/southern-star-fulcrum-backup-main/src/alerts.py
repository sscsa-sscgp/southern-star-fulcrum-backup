"""Failure alerts by email (acceptance criterion 3: a failed run produces a log
entry and an alert).

Alerts go to the recipients in config (alerts.recipients). For Southern Star
that includes help@southernstar.com, which opens a Freshservice ticket; IT
routes it on the subject line and/or the From address, so both are fixed and
set in config (alerts.subject, alerts.sender), never varied per run.
Everything about the run -- machine, backup folder, exit code, every failure
-- goes in the body.

The mail goes through Southern Star's internal relay, never an outside
service. Check the settings with `python -m src.main alert-test`. Until
alerts.smtp_host is set, no email is sent: a failure is in the log file and
the exit code only.
"""

import smtplib
import socket
from dataclasses import dataclass, field
from datetime import datetime
from email.message import EmailMessage
from email.utils import formatdate, make_msgid

from src.config import dig, is_placeholder

DEFAULT_SUBJECT = "[Fulcrum Backup] FAILED"

#: How many failures an alert lists before pointing at the log for the rest.
MAX_LISTED_FAILURES = 100
SECURITY_MODES = ("none", "starttls", "ssl")
DEFAULT_TIMEOUT = 30

#: What each exit code means, and what to do about it (main.py documents the codes).
EXIT_CODES = {
    1: ("incomplete",
        "A table failed or a delivery was interrupted (the landing-zone folder has no _SUCCESS, so "
        "ingestion ignores it), or an attachment failed to download (the backup was delivered "
        "without it). Re-running the same command is safe: a delivery resumes, and failed "
        "attachments are tried again by the next backup."),
    2: ("configuration problem",
        "Check config/config.yaml and the environment variables named in the log. Nothing was "
        "exported or sent."),
    3: ("Fulcrum unreachable, or its API token was rejected",
        "Check outbound HTTPS to api.fulcrumapp.com from this machine, and that the Fulcrum token "
        "is still valid (a 401 means it was revoked or belongs to another org)."),
    4: ("landing zone unreachable, unverified or login rejected",
        "Check port 22 to the SFTP host, the SFTP password, and whether the server's key changed "
        "(a host key MISMATCH must be confirmed with the server's owner before re-pinning)."),
    5: ("unexpected error",
        "The log has the full error. Please send it to the Fulcrum team."),
    6: ("another backup run was still in progress",
        "This run did nothing. The log names the run holding the lock and when it started. If "
        "that's hours ago it is stuck: end that process (its lock is released as soon as it "
        "exits) and re-run."),
}


class AlertConfigError(Exception):
    """The alerts section of the config is set but unusable."""


@dataclass
class AlertSettings:
    host: str
    port: int
    sender: str
    recipients: list
    security: str = "none"
    username: str = ""
    password: str = field(default="", repr=False)
    subject: str = DEFAULT_SUBJECT
    timeout: float = DEFAULT_TIMEOUT


def settings(config):
    """AlertSettings from config, or None when alerts are off (no smtp_host).

    Raises AlertConfigError when smtp_host is set but the rest can't work,
    or when any alerts value is still a Southern Star placeholder.
    """
    pending = sorted(key for key, value in (dig(config or {}, "alerts") or {}).items()
                     if is_placeholder(value) or (isinstance(value, list) and any(map(is_placeholder, value))))
    if pending:
        raise AlertConfigError("alerts settings are still placeholders: "
                               + ", ".join(f"alerts.{key}" for key in pending))
    host = dig(config or {}, "alerts.smtp_host")
    if not host:
        return None
    recipients = dig(config, "alerts.recipients") or []
    if isinstance(recipients, str):
        recipients = [part.strip() for part in recipients.split(",") if part.strip()]
    sender = dig(config, "alerts.sender") or ""
    security = str(dig(config, "alerts.security") or "none").lower()
    missing = [key for key, value in (("alerts.sender", sender), ("alerts.recipients", recipients)) if not value]
    if missing:
        raise AlertConfigError(f"alerts.smtp_host is set, but {' and '.join(missing)} "
                               f"{'is' if len(missing) == 1 else 'are'} empty")
    if security not in SECURITY_MODES:
        raise AlertConfigError(f"alerts.security must be one of {', '.join(SECURITY_MODES)}, got {security!r}")
    try:
        port = int(dig(config, "alerts.smtp_port") or (465 if security == "ssl" else 25))
    except (TypeError, ValueError):
        raise AlertConfigError(f"alerts.smtp_port must be a number, got {dig(config, 'alerts.smtp_port')!r}")
    return AlertSettings(
        host=str(host), port=port, sender=str(sender), recipients=[str(r) for r in recipients],
        security=security, username=str(dig(config, "alerts.username") or ""),
        password=str(dig(config, "alerts.password") or ""),
        subject=str(dig(config, "alerts.subject") or DEFAULT_SUBJECT),
        timeout=float(dig(config, "alerts.timeout_sec") or DEFAULT_TIMEOUT),
    )


def _message(alert, subject, body):
    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = alert.sender
    message["To"] = ", ".join(alert.recipients)
    message["Date"] = formatdate(localtime=True)
    message["Message-ID"] = make_msgid(domain=alert.sender.rpartition("@")[2] or None)
    message.set_content(body)
    return message


def _failure_lines(failures):
    if not failures:
        return ["  (nothing more specific than the exit code; see the log)"]
    lines = [f"  - {failure}" for failure in failures[:MAX_LISTED_FAILURES]]
    if len(failures) > MAX_LISTED_FAILURES:
        lines.append(f"  ... and {len(failures) - MAX_LISTED_FAILURES} more in the log file")
    return lines


def failure_body(*, command, code, failures=(), env=None, folder=None, log_path=None, tail=(),
                 host=None, expected_host=None, when=None):
    meaning, advice = EXIT_CODES.get(code, ("failed", "The log has the details."))
    host = host or socket.gethostname()
    when = when or datetime.now()
    machine = host if not expected_host or expected_host.lower() == host.lower() \
        else f"{host} (the config expects {expected_host})"
    return "\n".join([
        f"The Fulcrum backup failed on {host} at {when:%Y-%m-%d %H:%M}.",
        "",
        f"Machine:       {machine}",
        f"Command:       {command}",
        f"Landing zone:  {env.upper() if env else 'not reached'}",
        f"Backup folder: {folder or 'none (it stopped before a backup folder was made)'}",
        f"Exit code:     {code} ({meaning})",
        f"Log file:      {log_path or 'not written'}",
        "",
        f"What failed ({len(failures)}):",
        *_failure_lines(list(failures)),
        "",
        f"What to do: {advice}",
        "",
        "Last lines of the log:",
        "",
        *[f"  {line}" for line in tail],
    ])


def failure_message(alert, **details):
    """The email for a failed run: the fixed subject and From that Southern
    Star's IT routes on, and everything about this run in the body."""
    return _message(alert, alert.subject, failure_body(**details))


def sample_failure_message(alert, host=None, expected_host=None):
    """What alert-test sends: a real-looking failure alert, same subject and
    From, so the Freshservice routing is tested too. The body says it's a test."""
    host = host or socket.gethostname()
    body = failure_body(
        command="alert-test", code=1, host=host, expected_host=expected_host, folder="backup_20261104_2000_CT (sample)",
        failures=['table "Example App/example_repeatable": sample failure -- this is a test',
                  "attachment 00000000-0000-0000-0000-000000000000 (Example App, record 1): sample failure"],
        tail=["(sample alert: nothing ran)"])
    banner = ("*** THIS IS A TEST ALERT, sent with `python -m src.main alert-test`. Nothing has failed and no "
              "action is needed, other than checking that it arrived and was routed. ***\n\n")
    return _message(alert, alert.subject, banner + body)


def send(alert, message, smtp=smtplib.SMTP, smtp_ssl=smtplib.SMTP_SSL):
    """Send through the relay. Returns the recipients it refused ({} if none).
    Raises smtplib.SMTPException or OSError; describe_error() explains them."""
    if alert.security == "ssl":
        server = smtp_ssl(alert.host, alert.port, timeout=alert.timeout)
    else:
        server = smtp(alert.host, alert.port, timeout=alert.timeout)
    with server:
        if alert.security == "starttls":
            server.starttls()
        if alert.username:
            server.login(alert.username, alert.password)
        return server.send_message(message)


def check_relay(alert, smtp=smtplib.SMTP, smtp_ssl=smtplib.SMTP_SSL):
    """For preflight: does the relay accept our sender and every recipient?
    Goes as far as RCPT TO, then resets: nothing is ever sent. Returns a list
    of problems ([] when the relay would take the alert)."""
    problems = []
    if alert.security == "ssl":
        server = smtp_ssl(alert.host, alert.port, timeout=alert.timeout)
    else:
        server = smtp(alert.host, alert.port, timeout=alert.timeout)
    with server:
        server.ehlo()
        if alert.security == "starttls":
            server.starttls()
            server.ehlo()
        if alert.username:
            server.login(alert.username, alert.password)
        code, reply = server.mail(alert.sender)
        if code != 250:
            problems.append(f"refused the sender {alert.sender!r}: {code} {reply.decode(errors='replace')}")
        else:
            for recipient in alert.recipients:
                code, reply = server.rcpt(recipient)
                if code not in (250, 251):
                    problems.append(f"refused the recipient {recipient!r}: {code} {reply.decode(errors='replace')}")
        server.rset()
    return problems


def describe_error(exc, alert):
    """One line saying what went wrong with the relay, and where to look."""
    where = f"{alert.host}:{alert.port}"
    if isinstance(exc, smtplib.SMTPSenderRefused):
        return (f"the relay {where} refused the sender {alert.sender!r} ({exc.smtp_code}) -- ask IT to "
                f"allow this sender, and this machine, to relay")
    if isinstance(exc, smtplib.SMTPRecipientsRefused):
        return f"the relay {where} refused every recipient: {', '.join(exc.recipients)}"
    if isinstance(exc, smtplib.SMTPAuthenticationError):
        return f"the relay {where} rejected alerts.username / alerts.password ({exc.smtp_code})"
    if isinstance(exc, smtplib.SMTPNotSupportedError):
        return f"the relay {where} doesn't support what alerts.security / alerts.username ask for -- {exc}"
    if isinstance(exc, (socket.timeout, TimeoutError)):
        return f"timed out connecting to the relay {where} -- is it reachable from this machine?"
    if isinstance(exc, ConnectionRefusedError):
        return f"the relay {where} refused the connection -- wrong port, or a firewall in the way"
    if isinstance(exc, socket.gaierror):
        return f"the relay host {alert.host!r} doesn't resolve -- check alerts.smtp_host"
    return f"sending through {where} failed -- {exc}"
