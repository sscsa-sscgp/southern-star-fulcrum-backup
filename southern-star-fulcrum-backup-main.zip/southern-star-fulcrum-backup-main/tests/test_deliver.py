"""Tests for delivery (src/deliver.py, src/sftp_client.py) and the run command.

Real cycles are produced by the export against the fake Fulcrum API from
test_export.py, then delivered to the in-process SFTP server from sftp_stub.py.
Nothing here touches Southern Star.
"""

import json
import os
import shutil
import sys

import pytest
import yaml

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import src.main as cli  # noqa: E402
from src.catalog import build_plan  # noqa: E402
from src.deliver import DeliveryError, cycle_files, deliver_cycle, find_cycle, is_delivered  # noqa: E402
from src.export import MANIFEST_NAME, SUCCESS_NAME, export_cycle  # noqa: E402
from src.naming import Namer  # noqa: E402
from src.sftp_client import LandingError, UploadError, connect  # noqa: E402
from sftp_stub import SFTPTestServer  # noqa: E402
from test_export import APPS, FIXED_NOW, FakeFulcrum, make_client, quiet, sample_data  # noqa: E402

CYCLE = "backup_20261014_2000_CT"


def make_cycle(staging, now=FIXED_NOW):
    fake = FakeFulcrum(APPS, sample_data(), key_supported=True)
    client = make_client(fake)
    plan = build_plan(client, log=quiet)
    result = export_cycle(client, plan, Namer(), str(staging), batch_size=10, log=quiet, now=now)
    assert result.complete
    return result.path


def open_landing(server, fingerprint="pinned"):
    pinned = server.fingerprint if fingerprint == "pinned" else fingerprint
    return connect("127.0.0.1", server.port, server.username, server.password, pinned, timeout=5)


def local_files(cycle):
    return {name: os.path.getsize(os.path.join(cycle, name))
            for name in os.listdir(cycle) if not name.startswith(".")}


def remote_files(folder):
    return {name: os.path.getsize(os.path.join(folder, name)) for name in os.listdir(folder)}


# ---------------------------------------------------------------------------
# deliver_cycle
# ---------------------------------------------------------------------------

def test_delivery_sends_every_file_and_writes_success_last(tmp_path):
    cycle = make_cycle(tmp_path / "staging")
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server:
        with open_landing(server) as landing:
            result = deliver_cycle(landing, cycle, ".", "uat", log=quiet)
        events = list(server.events)

    remote = landing_root / CYCLE
    assert remote_files(remote) == local_files(cycle)       # same files, same sizes, no .part
    assert result.remote_path == f"/{CYCLE}"
    assert result.uploaded[-1] == SUCCESS_NAME and not result.kept
    # _SUCCESS is the very last thing written, and it arrives by rename.
    assert events[-1] == ("rename", f"/{CYCLE}/{SUCCESS_NAME}.part", f"/{CYCLE}/{SUCCESS_NAME}")
    # Every file went up under a temporary name first.
    assert all(path.endswith(".part") for kind, path, *_ in events if kind == "write")
    marker = json.load(open(os.path.join(cycle, ".delivered-uat.json"), encoding="utf-8"))
    assert marker["remote_path"] == f"/{CYCLE}" and not marker["already_delivered"]


def test_incomplete_cycle_is_not_delivered(tmp_path):
    cycle = make_cycle(tmp_path / "staging")
    os.remove(os.path.join(cycle, SUCCESS_NAME))
    with pytest.raises(DeliveryError, match="did not complete"):
        cycle_files(cycle)


def test_second_delivery_leaves_a_delivered_folder_untouched(tmp_path):
    cycle = make_cycle(tmp_path / "staging")
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server:
        with open_landing(server) as landing:
            deliver_cycle(landing, cycle, ".", "uat", log=quiet)
        writes_before = len(server.events)
        with open_landing(server) as landing:
            again = deliver_cycle(landing, cycle, ".", "uat", log=quiet)
        assert again.already_delivered
        assert len(server.events) == writes_before


def test_interrupted_delivery_resumes_and_never_touches_foreign_files(tmp_path):
    cycle = make_cycle(tmp_path / "staging")
    names = sorted(local_files(cycle))
    good, truncated = [n for n in names if n.endswith(".csv") and not n.startswith("_")][:2]
    landing_root = tmp_path / "landing"
    remote = landing_root / CYCLE
    remote.mkdir(parents=True)
    shutil.copy(os.path.join(cycle, good), remote / good)                  # arrived intact
    (remote / truncated).write_bytes(b"cut short")                         # wrong size
    (remote / f"{names[-1]}.part").write_bytes(b"stale temp file")         # our leftover
    (remote / "notes_from_southern_star.txt").write_text("not ours")               # foreign

    with SFTPTestServer(str(landing_root)) as server:
        with open_landing(server) as landing:
            result = deliver_cycle(landing, cycle, ".", "uat", log=quiet)

    assert good in result.kept
    assert truncated in result.uploaded
    assert result.unknown_remote == ["notes_from_southern_star.txt"]
    assert (remote / "notes_from_southern_star.txt").read_text() == "not ours"
    on_server = remote_files(remote)
    del on_server["notes_from_southern_star.txt"]
    assert on_server == local_files(cycle)


def test_refused_rename_leaves_no_success_behind(tmp_path):
    cycle = make_cycle(tmp_path / "staging")
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root), deny_rename=True) as server:
        with open_landing(server) as landing:
            with pytest.raises(UploadError, match="rename"):
                deliver_cycle(landing, cycle, ".", "uat", log=quiet)
    assert not (landing_root / CYCLE / SUCCESS_NAME).exists()
    assert not is_delivered(cycle, "uat")


@pytest.mark.parametrize("fingerprint, message", [
    (None, "not set"),
    ("SHA256:" + "A" * 43, "MISMATCH"),
])
def test_unverified_server_gets_nothing(tmp_path, fingerprint, message):
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server:
        with pytest.raises(LandingError, match=message):
            open_landing(server, fingerprint=fingerprint)
        assert server.events == []


def test_wrong_password_is_a_landing_error(tmp_path):
    with SFTPTestServer(str(tmp_path)) as server:
        with pytest.raises(LandingError, match="authentication failed"):
            connect("127.0.0.1", server.port, server.username, "wrong", server.fingerprint, timeout=5)


def test_find_cycle_picks_the_newest_undelivered_complete_cycle(tmp_path):
    staging = tmp_path / "staging"
    older = make_cycle(staging, now=FIXED_NOW)
    newer = make_cycle(staging, now=FIXED_NOW.replace(hour=13))   # 8 AM Chicago
    os.utime(os.path.join(older, SUCCESS_NAME), (1, 1))
    assert find_cycle(str(staging), "uat") == newer
    open(os.path.join(newer, ".delivered-uat.json"), "w").close()
    assert find_cycle(str(staging), "uat") == older
    assert find_cycle(str(staging), "prod") == newer              # per environment
    os.remove(os.path.join(older, SUCCESS_NAME))
    assert find_cycle(str(staging), "uat") is None


# ---------------------------------------------------------------------------
# CLI: run and deliver
# ---------------------------------------------------------------------------

def write_config(tmp_path, server, **extra):
    config = {
        "fulcrum": {"api_token": "test-token"},
        "export": {"staging_dir": str(tmp_path / "staging"), "batch_size": 10, "state_dir": str(tmp_path / "state")},
        "sftp": {
            "host": "127.0.0.1",
            "port": server.port,
            "timeout_sec": 5,
            "host_key_fingerprint": server.fingerprint,
            "accounts": {"uat": {"username": server.username, "password": server.password, "remote_dir": "."}},
        },
    }
    config.update(extra)
    path = tmp_path / "config.yaml"
    path.write_text(yaml.safe_dump(config), encoding="utf-8")
    return str(path)


@pytest.fixture
def fake_fulcrum(monkeypatch):
    fake = FakeFulcrum(APPS, sample_data(), key_supported=True)
    monkeypatch.setattr(cli, "FulcrumClient", lambda token, base_url=None: make_client(fake))
    return fake


def test_run_exports_and_delivers(tmp_path, fake_fulcrum, capsys):
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server:
        config = write_config(tmp_path, server)
        code = cli.main(["run", "--config", config, "--tag", "dev"])
        out = capsys.readouterr().out
        assert code == 0, out
        [folder] = os.listdir(landing_root)
        assert folder.startswith("dev_backup_")
        assert (landing_root / folder / SUCCESS_NAME).exists()
        assert (landing_root / folder / MANIFEST_NAME).exists()
        assert "DELIVERED (_SUCCESS written last)" in out

        # Nothing new to deliver afterwards.
        code = cli.main(["deliver", "--config", config])
        assert code == 0
        assert "Nothing to deliver" in capsys.readouterr().out


def test_run_checks_the_landing_zone_before_exporting(tmp_path, fake_fulcrum, capsys):
    with SFTPTestServer(str(tmp_path)) as server:
        config = write_config(tmp_path, server)
    # The server is gone now: the preflight must fail before any export work.
    code = cli.main(["run", "--config", config])
    assert code == 4
    assert "refused" in capsys.readouterr().out
    assert fake_fulcrum.queries == []
    assert not (tmp_path / "staging").exists()


def test_tagged_cycles_never_go_to_production(tmp_path, fake_fulcrum, capsys):
    with SFTPTestServer(str(tmp_path)) as server:
        config = write_config(tmp_path, server)
        sftp_prod = {"prod": {"username": "p", "password": "p"}}
        data = yaml.safe_load(open(config, encoding="utf-8"))
        data["sftp"]["accounts"].update(sftp_prod)
        open(config, "w", encoding="utf-8").write(yaml.safe_dump(data))
        code = cli.main(["run", "--config", config, "--tag", "dev", "--env", "prod"])
    assert code == 2
    assert "not Production" in capsys.readouterr().out


def test_missing_landing_password_names_its_environment_variable(tmp_path, monkeypatch, capsys):
    monkeypatch.delenv("SFTP_UAT_PASSWORD", raising=False)
    with SFTPTestServer(str(tmp_path)) as server:
        config = write_config(tmp_path, server)
    data = yaml.safe_load(open(config, encoding="utf-8"))
    del data["sftp"]["accounts"]["uat"]["password"]
    open(config, "w", encoding="utf-8").write(yaml.safe_dump(data))
    code = cli.main(["deliver", "--config", config])
    assert code == 2
    assert "SFTP_UAT_PASSWORD" in capsys.readouterr().out
