"""Tests for the run log and failure alerts (src/runlog.py, src/alerts.py).

Alerts go through tests/smtp_stub.py, a real SMTP conversation on localhost,
and runs use the fakes from test_attachments.py. Nothing leaves the machine.
"""

import os
import sys
import time
from datetime import datetime, timedelta

import pytest
import yaml

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import src.main as cli  # noqa: E402
from src import alerts, runlog  # noqa: E402
from src.config import load, redacted_summary  # noqa: E402
from sftp_stub import SFTPTestServer  # noqa: E402
from smtp_stub import SMTPStub  # noqa: E402
from test_attachments import A1, cli_fakes, write_config  # noqa: E402,F401  (cli_fakes is a fixture)

RECIPIENTS = ["myles.shade@example.com", "help@example.com"]
SENDER = "svc-fulcrum-backup@example.com"


def with_alerts(config_path, relay=None, **overrides):
    """Add an alerts section to a test config: pointed at relay, or left off."""
    data = yaml.safe_load(open(config_path, encoding="utf-8"))
    data["alerts"] = {"smtp_host": "127.0.0.1" if relay else None, "smtp_port": relay.port if relay else None,
                      "sender": SENDER, "recipients": RECIPIENTS, **overrides}
    with open(config_path, "w", encoding="utf-8") as fh:
        yaml.safe_dump(data, fh)
    return config_path


def log_files(logs_dir):
    return sorted(logs_dir.iterdir()) if logs_dir.exists() else []


# ---------------------------------------------------------------------------
# A failed run
# ---------------------------------------------------------------------------

def test_a_failed_run_emails_the_fixed_subject_and_keeps_its_exit_code(tmp_path, cli_fakes, logs_in_tmp, capsys):
    with SFTPTestServer(str(tmp_path)) as server:
        config = write_config(tmp_path, server)
    # The SFTP server is gone, so the landing-zone check fails before any export.
    with SMTPStub() as relay:
        code = cli.main(["run", "--config", with_alerts(config, relay)])
    out = capsys.readouterr().out

    assert code == 4
    [(sender, recipients, message)] = relay.messages
    assert sender == SENDER and recipients == RECIPIENTS
    assert message["Subject"] == "[Fulcrum Backup] FAILED"           # fixed: their IT routes on it
    assert "Backup folder: none (it stopped before a backup folder was made)" in message.get_content()
    body = message.get_content()
    assert "Exit code:     4 (landing zone unreachable" in body and "Landing zone:  UAT" in body
    assert "What failed (1):\n  - connection to 127.0.0.1" in body.replace("\r\n", "\n")
    assert "[FAIL]" in body                                  # the log's last lines are quoted
    [log] = log_files(logs_in_tmp)
    assert f"Log file:      {log}" in body
    assert "Alert sent to myles.shade@example.com, help@example.com" in out
    logged = log.read_text(encoding="utf-8")
    assert "[FAIL]" in logged and "Alert sent to" in logged and logged.startswith("[")


def test_a_failed_attachment_names_the_backup_folder(tmp_path, cli_fakes, capsys):
    _api, storage = cli_fakes
    storage.failing[A1] = 99
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server, SMTPStub() as relay:
        code = cli.main(["run", "--config", with_alerts(write_config(tmp_path, server), relay), "--tag", "dev"])
    assert code == 1
    [folder] = os.listdir(landing_root)                     # delivered anyway
    [(_sender, _recipients, message)] = relay.messages
    assert message["Subject"] == "[Fulcrum Backup] FAILED"
    assert f"Backup folder: {folder}" in message.get_content()
    assert "Exit code:     1 (incomplete)" in message.get_content()


def test_a_successful_run_sends_nothing_and_still_logs(tmp_path, cli_fakes, logs_in_tmp, capsys):
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server, SMTPStub() as relay:
        code = cli.main(["run", "--config", with_alerts(write_config(tmp_path, server), relay), "--tag", "dev"])
    assert code == 0
    assert relay.messages == []
    [log] = log_files(logs_in_tmp)
    assert "DELIVERED" in log.read_text(encoding="utf-8")
    assert f"Log: {log}" in capsys.readouterr().out


def test_with_alerts_off_a_failure_is_logged_only(tmp_path, cli_fakes, logs_in_tmp, capsys):
    with SFTPTestServer(str(tmp_path)) as server:
        config = write_config(tmp_path, server)
    code = cli.main(["run", "--config", with_alerts(config, relay=None)])
    assert code == 4
    assert "Alerts are off (alerts.smtp_host is not set)" in capsys.readouterr().out
    assert len(log_files(logs_in_tmp)) == 1


def test_a_refused_sender_does_not_hide_the_failure(tmp_path, cli_fakes, capsys):
    with SFTPTestServer(str(tmp_path)) as server:
        config = write_config(tmp_path, server)
    with SMTPStub(refuse_sender=True) as relay:
        code = cli.main(["run", "--config", with_alerts(config, relay)])
    assert code == 4                                         # the backup's code, not the mail's
    out = capsys.readouterr().out
    assert f"refused the sender {SENDER!r} (553)" in out and "ask IT to allow this sender" in out


def test_a_half_filled_alerts_section_is_reported_not_fatal(tmp_path, cli_fakes, capsys):
    with SFTPTestServer(str(tmp_path)) as server:
        config = write_config(tmp_path, server)
    with SMTPStub() as relay:
        code = cli.main(["run", "--config", with_alerts(config, relay, sender=None)])
    assert code == 4 and relay.messages == []
    assert "no failure alert sent: alerts.smtp_host is set, but alerts.sender is empty" in capsys.readouterr().out


def test_an_unexpected_error_is_logged_alerted_and_exits_5(tmp_path, monkeypatch, logs_in_tmp, capsys):
    def broken_run(args):
        cli._load_config(args.config, ())
        raise RuntimeError("a bug")

    monkeypatch.setitem(cli.COMMANDS, "run", broken_run)
    with SFTPTestServer(str(tmp_path)) as server, SMTPStub() as relay:
        code = cli.main(["run", "--config", with_alerts(write_config(tmp_path, server), relay)])
    assert code == 5
    [(_sender, _recipients, message)] = relay.messages
    assert "Exit code:     5 (unexpected error)" in message.get_content()
    [log] = log_files(logs_in_tmp)
    logged = log.read_text(encoding="utf-8")
    assert "RuntimeError('a bug')" in logged and "Traceback" in logged


def test_dry_runs_and_read_only_commands_write_no_log(tmp_path, cli_fakes, logs_in_tmp):
    with SFTPTestServer(str(tmp_path)) as server:
        config = write_config(tmp_path, server)
    assert cli.main(["export", "--config", config, "--dry-run"]) == 0
    assert log_files(logs_in_tmp) == []


def test_logging_dir_from_config(tmp_path, cli_fakes, logs_in_tmp):
    with SFTPTestServer(str(tmp_path)) as server:
        config = write_config(tmp_path, server)
    data = yaml.safe_load(open(config, encoding="utf-8"))
    data["logging"] = {"dir": str(tmp_path / "custom-logs")}
    open(config, "w", encoding="utf-8").write(yaml.safe_dump(data))
    cli.main(["run", "--config", config])
    assert len(os.listdir(tmp_path / "custom-logs")) == 1 and log_files(logs_in_tmp) == []


# ---------------------------------------------------------------------------
# alert-test, for Southern Star to check their relay during UAT
# ---------------------------------------------------------------------------

def test_alert_test_sends_a_test_email(tmp_path, capsys):
    config = tmp_path / "config.yaml"
    config.write_text("{}", encoding="utf-8")
    with SMTPStub() as relay:
        code = cli.main(["alert-test", "--config", with_alerts(str(config), relay)])
    assert code == 0, capsys.readouterr().out
    [(_sender, recipients, message)] = relay.messages
    assert message["Subject"] == "[Fulcrum Backup] FAILED" and recipients == RECIPIENTS   # routing is tested too
    assert message.get_content().startswith("*** THIS IS A TEST ALERT")


@pytest.mark.parametrize("overrides, message", [
    ({"smtp_host": None}, "alerts are off"),
    ({"recipients": []}, "alerts.recipients is empty"),
    ({"security": "tls13"}, "alerts.security must be one of"),
])
def test_alert_test_names_what_is_missing(tmp_path, capsys, overrides, message):
    config = tmp_path / "config.yaml"
    config.write_text("{}", encoding="utf-8")
    with SMTPStub() as relay:
        code = cli.main(["alert-test", "--config", with_alerts(str(config), relay, **overrides)])
    assert code == 2
    assert message in capsys.readouterr().out


def test_alert_test_says_when_the_relay_is_unreachable(tmp_path, capsys):
    config = tmp_path / "config.yaml"
    config.write_text("{}", encoding="utf-8")
    with SMTPStub() as relay:
        port = relay.port
    with_alerts(str(config), relay, smtp_port=port)          # the relay has stopped listening
    assert cli.main(["alert-test", "--config", str(config)]) == 4
    assert "refused the connection" in capsys.readouterr().out


# ---------------------------------------------------------------------------
# Settings and the pieces underneath
# ---------------------------------------------------------------------------

class FakeSMTP:
    """Records what send() asks of the relay: STARTTLS, login, the message."""
    calls = []

    def __init__(self, host, port, timeout=None):
        FakeSMTP.calls.append(("connect", host, port))

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        pass

    def starttls(self):
        FakeSMTP.calls.append(("starttls",))

    def login(self, username, password):
        FakeSMTP.calls.append(("login", username, password))

    def send_message(self, message):
        FakeSMTP.calls.append(("send", message["Subject"]))
        return {}


def test_starttls_and_login_when_configured():
    FakeSMTP.calls = []
    config = {"alerts": {"smtp_host": "relay.example.com", "sender": SENDER, "recipients": "a@x.com, b@x.com",
                         "security": "starttls", "username": "svc", "password": "pw"}}
    alert = alerts.settings(config)
    assert alert.port == 25 and alert.recipients == ["a@x.com", "b@x.com"]
    alerts.send(alert, alerts.sample_failure_message(alert, host="box1"), smtp=FakeSMTP)
    assert FakeSMTP.calls == [("connect", "relay.example.com", 25), ("starttls",), ("login", "svc", "pw"),
                              ("send", "[Fulcrum Backup] FAILED")]


def test_the_smtp_password_is_a_secret(tmp_path, monkeypatch):
    path = tmp_path / "config.yaml"
    path.write_text(yaml.safe_dump({"alerts": {"smtp_host": "relay", "username": "svc"}}), encoding="utf-8")
    monkeypatch.setenv("SMTP_PASSWORD", "hunter2")
    config = load(str(path), ())
    assert alerts.settings({**config, "alerts": {**config["alerts"], "sender": SENDER,
                                                 "recipients": RECIPIENTS}}).password == "hunter2"
    summary = redacted_summary(config)
    assert "hunter2" not in summary and "alerts.password: ***" in summary
    assert "hunter2" not in repr(alerts.settings({**config, "alerts": {**config["alerts"], "sender": SENDER,
                                                                         "recipients": RECIPIENTS}}))


def test_prune_removes_only_our_old_logs(tmp_path):
    old = tmp_path / "fulcrum-backup_run_20260101_080000.log"
    new = tmp_path / "fulcrum-backup_run_20261027_080000.log"
    theirs = tmp_path / "something-else.log"
    for path in (old, new, theirs):
        path.write_text("x")
    long_ago = time.time() - 200 * 86400
    os.utime(old, (long_ago, long_ago))
    os.utime(theirs, (long_ago, long_ago))
    assert runlog.prune(str(tmp_path), keep_days=90) == 1
    assert sorted(p.name for p in tmp_path.iterdir()) == sorted([new.name, theirs.name])


def test_the_log_holds_lines_until_it_knows_where_to_write(tmp_path):
    class Console:
        text = ""

        def write(self, s):
            Console.text += s

        def flush(self):
            pass

    log = runlog.RunLog("run", Console(), now=datetime(2026, 11, 4, 20, 0, 0))
    log.write("before the config\npart")
    path = log.open(str(tmp_path))
    log.write("ial line\n")
    log.close()
    assert os.path.basename(path) == "fulcrum-backup_run_20261104_200000.log"
    lines = open(path, encoding="utf-8").read().splitlines()
    assert [line.split("] ", 1)[1] for line in lines] == ["before the config", "partial line"]
    assert Console.text == "before the config\npartial line\n"
    assert list(log.tail) == ["before the config", "partial line"]
    assert datetime.now() - timedelta(minutes=1) < datetime.strptime(lines[0][1:20], "%Y-%m-%d %H:%M:%S")
