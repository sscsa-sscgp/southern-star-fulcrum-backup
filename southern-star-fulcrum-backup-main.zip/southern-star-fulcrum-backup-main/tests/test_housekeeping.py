"""Tests for the run lock and staging cleanup (src/housekeeping.py)."""

import os
import subprocess
import sys
import textwrap
import time

import pytest
import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import src.main as cli  # noqa: E402
from src.export import MANIFEST_NAME, SUCCESS_NAME  # noqa: E402
from src.housekeeping import RunLock, RunLocked, prune_staging  # noqa: E402
from sftp_stub import SFTPTestServer  # noqa: E402
from smtp_stub import SMTPStub  # noqa: E402
from test_alerts import with_alerts  # noqa: E402
from test_attachments import cli_fakes, write_config  # noqa: E402,F401  (cli_fakes is a fixture)


# ---------------------------------------------------------------------------
# The run lock
# ---------------------------------------------------------------------------

def test_a_held_lock_stops_the_run_and_alerts(tmp_path, cli_fakes, capsys):
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server, SMTPStub() as relay:
        config = with_alerts(write_config(tmp_path, server), relay)
        with RunLock(str(tmp_path / "state"), "run"):
            code = cli.main(["run", "--config", config, "--tag", "dev"])
    out = capsys.readouterr().out
    assert code == 6
    assert "another backup run is in progress: 'run' on" in out and "This run did nothing" in out
    assert os.listdir(landing_root) == [] and not (tmp_path / "staging").exists()
    [(_sender, _recipients, message)] = relay.messages
    assert "Exit code:     6 (another backup run was still in progress)" in message.get_content()


def test_the_lock_is_released_after_a_run(tmp_path, cli_fakes, capsys):
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server:
        config = write_config(tmp_path, server)
        assert cli.main(["run", "--config", config, "--tag", "dev"]) == 0
        assert cli.main(["deliver", "--config", config]) == 0      # would be 6 if the lock had leaked
    assert "Nothing to deliver" in capsys.readouterr().out
    assert not (tmp_path / "state" / "run.lock.json").exists()


def test_the_lock_is_released_when_the_block_raises(tmp_path):
    with pytest.raises(RuntimeError):
        with RunLock(str(tmp_path), "run"):
            raise RuntimeError("boom")
    with RunLock(str(tmp_path), "run"):
        pass


HOLDER = textwrap.dedent("""
    import sys
    sys.path.insert(0, sys.argv[1])
    from src.housekeeping import RunLock
    lock = RunLock(sys.argv[2], "run")
    lock.__enter__()
    print("locked", flush=True)
    sys.stdin.read()          # hold the lock until killed
""")


def test_another_process_holds_the_lock_until_it_dies(tmp_path):
    holder = subprocess.Popen([sys.executable, "-c", HOLDER, ROOT, str(tmp_path)],
                              stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
    try:
        assert holder.stdout.readline().strip() == "locked"
        with pytest.raises(RunLocked, match=f"process {holder.pid}"):
            with RunLock(str(tmp_path), "deliver"):
                pass
    finally:
        holder.kill()             # dies without releasing anything itself
        holder.wait(timeout=10)
    with RunLock(str(tmp_path), "deliver"):   # the OS dropped the lock with the process
        pass


# ---------------------------------------------------------------------------
# Staging cleanup
# ---------------------------------------------------------------------------

def make_cycle(staging, name, age_hours, complete=True, delivered=None):
    path = staging / name
    (path / "attachments").mkdir(parents=True)
    (path / "attachments" / "file.pdf").write_bytes(b"x")
    (path / MANIFEST_NAME).write_text("file,status\n")
    if complete:
        (path / SUCCESS_NAME).write_text("")
    if delivered:
        (path / f".delivered-{delivered}.json").write_text("{}")
    stamp = time.time() - age_hours * 3600
    os.utime(path / MANIFEST_NAME, (stamp, stamp))
    return path


def test_prune_keeps_the_newest_and_never_an_undelivered_backup(tmp_path):
    staging = tmp_path / "staging"
    make_cycle(staging, "backup_6", 0, delivered="prod")
    make_cycle(staging, "backup_5", 12, delivered="prod")
    make_cycle(staging, "backup_4", 24, delivered="prod")             # old, delivered: goes
    make_cycle(staging, "backup_3", 36, complete=False)                # old, never completed: goes
    make_cycle(staging, "backup_2", 48)                                # old, complete, undelivered: stays
    make_cycle(staging, "backup_1", 60, delivered="uat")               # old, but protected
    (staging / "notes").mkdir()                                        # not ours: no manifest

    removed, undelivered = prune_staging(str(staging), keep=2, protect=[str(staging / "backup_1")])
    assert sorted(removed) == ["backup_3", "backup_4"]
    assert undelivered == ["backup_2"]
    assert sorted(os.listdir(staging)) == ["backup_1", "backup_2", "backup_5", "backup_6", "notes"]


def test_prune_without_a_staging_folder_does_nothing(tmp_path):
    assert prune_staging(str(tmp_path / "missing"), keep=2) == ([], [])


def test_a_run_cleans_up_old_delivered_backups(tmp_path, cli_fakes, capsys):
    staging = tmp_path / "staging"
    make_cycle(staging, "dev_backup_20260101_0800_CT", 24 * 30, delivered="uat")
    make_cycle(staging, "dev_backup_20260101_2000_CT", 24 * 29, delivered="uat")
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server:
        config = write_config(tmp_path, server)
        data = yaml.safe_load(open(config, encoding="utf-8"))
        data["export"]["keep_cycles"] = 2
        open(config, "w", encoding="utf-8").write(yaml.safe_dump(data))
        assert cli.main(["run", "--config", config, "--tag", "dev"]) == 0
    assert "cleanup: removed 1 old local backup(s), keeping the newest 2" in capsys.readouterr().out
    remaining = sorted(os.listdir(staging))
    assert len(remaining) == 2 and "dev_backup_20260101_0800_CT" not in remaining
    assert "dev_backup_20260101_2000_CT" in remaining
