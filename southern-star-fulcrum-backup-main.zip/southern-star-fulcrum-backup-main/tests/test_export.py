"""Tests for the export core (src/).

A fake Fulcrum API serves forms.json and the Query API from in-memory tables.
It reproduces Southern Star's awkward cases: an app
name with a leading non-breaking space, child-table names over 63 characters,
and two of them sharing their first 63 characters -- plus a mode where an
over-long identifier is truncated and resolves to the WRONG table, which is
the failure the header check exists to catch.
"""

import csv
import hashlib
import io
import json
import os
import re
import sys
from datetime import datetime, timezone

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import src.main as cli  # noqa: E402
from src.catalog import App, ExportTable, assign_slugs, attachment_column_home, build_plan, identifier_candidates  # noqa: E402
from src.config import ConfigError, load  # noqa: E402
from src.export import (  # noqa: E402
    MANIFEST_NAME, SCHEMA_NAME, SUCCESS_NAME, HeaderMismatch, check_header, count_records, export_cycle,
)
from src.fulcrum_client import FulcrumAuthError, FulcrumClient  # noqa: E402
from src.naming import Namer, NamingError, slugify  # noqa: E402

MWD_ID = "94b6ae8c-9a38-4593-a865-e943353ddeaa"
PAST_ID = "86e50fb1-7aff-4264-a0b5-813f65b3813c"
COPY_ID = "af601b30-472c-42b3-8fbf-6a64f2a7d712"
PAST = "Past Years Monthly WHP & Annular Pressure forms"
COPY = "\xa0[Fulcrum PS] Form 42 SSCGP (Copy)"
SHORT_CHILD = f"{PAST}/select_well_past_years"                 # 70 chars
LONG_CHILD = f"{PAST}/select_well_past_years_repeat_fields"     # 84 chars, same first 63
ATTACHMENTS = "Master Well Data/well_notes_attachments"

# Child tables that are not repeatables. The Query API refuses AttachmentField
# tables with "invalid field" (identifier check, 25 Sep 2026: 32 of 32).
FIELD_TYPES = {ATTACHMENTS: "AttachmentField"}

APPS = [
    (MWD_ID, "Master Well Data", "2025-01-01T00:00:00Z"),
    (PAST_ID, PAST, "2025-02-01T00:00:00Z"),
    (COPY_ID, COPY, "2026-08-01T00:00:00Z"),
]

# 8 PM in Chicago (CDT, UTC-5) -- the evening run.
FIXED_NOW = datetime(2026, 10, 15, 1, 0, tzinfo=timezone.utc)
STAMP = "20261014_2000"


def sample_data():
    return {
        "Master Well Data": (
            ["_record_id", "_status", "well_name", "notes", "well_notes_attachments"],
            [["r1", "Active", "Webb 52", "line one\nline two", "{a1}"], ["r2", "Plugged", "Webb 54H", "", ""]],
        ),
        ATTACHMENTS: (["_record_id", "attachment_id"], [["r1", "a1"]]),
        "Master Well Data/tubulars": (
            ["_child_record_id", "_record_id", "_parent_id", "size"],
            [[f"c{i:02d}", "r1", "r1", str(i)] for i in range(25)],
        ),
        PAST: (["_record_id", "year"], [["p1", "2020"]]),
        SHORT_CHILD: (["_child_record_id", "_record_id", "well"], [["s1", "p1", "Webb 52"]]),
        LONG_CHILD: (["_child_record_id", "_record_id", "pressure"], [["f1", "p1", "812"]]),
        COPY: (["_record_id", "valve"], []),
    }


class Resp:
    def __init__(self, status=200, json_body=None, content=b""):
        self.status_code = status
        self._json = json_body
        self.content = content
        self.text = content.decode("utf-8") if content else json.dumps(json_body)
        self.headers = {}

    def json(self):
        if self._json is None:
            raise ValueError("no JSON body")
        return self._json


class FakeFulcrum:
    """In-memory stand-in for forms.json + the Query API.

    key_supported   "<form_id>/<element key>" resolves (undocumented in reality)
    truncate_long   identifiers over 63 chars are cut to 63 and matched against
                    table names, first match wins -- i.e. the wrong-table case
    per_page_cap    the API silently returns at most this many rows per request
    """

    def __init__(self, apps, data, key_supported=False, truncate_long=False,
                 per_page_cap=None, columns_available=True, count_status=None):
        self.apps = apps
        self.data = data
        self.key_supported = key_supported
        self.truncate_long = truncate_long
        self.per_page_cap = per_page_cap
        self.columns_available = columns_available
        self.count_status = count_status
        self.name_by_id = {app_id: name for app_id, name, _ in apps}
        self.id_by_name = {name: app_id for app_id, name, _ in apps}
        self.keys = {}
        self.queries = []

    def tables_rows(self):
        rows = [
            {"name": name, "type": "form", "parent": None, "form_id": app_id,
             "field": None, "field_type": None, "data_name": None}
            for app_id, name, _ in self.apps
        ]
        for index, name in enumerate(sorted(n for n in self.data if "/" in n)):
            app_name, data_name = name.split("/", 1)
            key = f"k{index:03d}"
            self.keys[f"{self.id_by_name[app_name]}/{key}"] = name
            rows.append({"name": name, "type": "repeatable", "parent": app_name,
                         "form_id": self.id_by_name[app_name], "field": key,
                         "field_type": FIELD_TYPES.get(name, "Repeatable"), "data_name": data_name})
        rows.append({"name": "Issues", "type": "system", "parent": None, "form_id": None,
                     "field": None, "field_type": None, "data_name": None})
        return rows

    def resolve(self, ident):
        table = self._resolve(ident)
        return None if FIELD_TYPES.get(table) == "AttachmentField" else table

    def _resolve(self, ident):
        if ident in self.data and len(ident.encode("utf-8")) <= 63:
            return ident
        if ident in self.name_by_id:
            return self.name_by_id[ident]
        if ident in self.keys and self.key_supported:
            return self.keys[ident]
        if "/" in ident and len(ident.encode("utf-8")) <= 63:
            head, tail = ident.split("/", 1)
            if head in self.name_by_id and f"{self.name_by_id[head]}/{tail}" in self.data:
                return f"{self.name_by_id[head]}/{tail}"
        if self.truncate_long and len(ident) > 63:
            for name in sorted(self.data):
                if name[:63] == ident[:63]:
                    return name
        return None

    def get(self, url, headers=None, params=None, timeout=None):
        params = params or {}
        if url.endswith("/api/v2/forms.json"):
            forms = [{"id": i, "name": n, "created_at": c} for i, n, c in self.apps]
            return Resp(200, {"forms": forms, "total_pages": 1})
        sql = params.get("q", "")
        self.queries.append(sql)
        if sql == "SELECT * FROM tables":
            return Resp(200, {"rows": self.tables_rows()})
        if sql == "SELECT * FROM columns":
            if not self.columns_available:
                return Resp(400, {"error": 'relation "columns" does not exist'})
            rows = [{"table_name": t, "name": c, "type": "text"} for t, (h, _) in self.data.items() for c in h]
            return Resp(200, {"rows": rows})
        match = re.fullmatch(r'SELECT COUNT\(\*\) AS n FROM "((?:[^"]|"")*)"', sql)
        if match:
            if self.count_status:
                return Resp(self.count_status, {"error": "Unauthorized"})
            table = self.resolve(match.group(1).replace('""', '"'))
            if table is None:
                return Resp(400, {"error": "relation does not exist"})
            return Resp(200, {"rows": [{"n": len(self.data[table][1])}]})
        match = re.fullmatch(r'SELECT \* FROM "((?:[^"]|"")*)"(?: ORDER BY (.+?))?(?: LIMIT (\d+)(?: OFFSET (\d+))?)?', sql)
        if match:
            table = self.resolve(match.group(1).replace('""', '"'))
            if table is None:
                return Resp(400, {"error": "relation does not exist"})
            header, rows = self.data[table]
            offset = int(match.group(4) or 0)
            limit = int(match.group(3)) if match.group(3) is not None else None
            chosen = rows[offset:] if limit is None else rows[offset:offset + limit]
            cap = int(params.get("per_page") or 20000)
            if self.per_page_cap:
                cap = min(cap, self.per_page_cap)
            buffer = io.StringIO()
            writer = csv.writer(buffer, lineterminator="\n")
            if params.get("headers", "true") == "true":
                writer.writerow(header)
            writer.writerows(chosen[:cap])
            return Resp(200, content=buffer.getvalue().encode("utf-8"))
        return Resp(400, {"error": f"fake does not understand: {sql}"})


def quiet(*_args, **_kwargs):
    pass


def make_client(fake):
    client = FulcrumClient("test-token", session=fake, log=quiet)
    client._sleep = lambda _seconds: None
    return client


def run_export(tmp_path, fake, batch_size=10, **kwargs):
    client = make_client(fake)
    plan = build_plan(client, log=quiet, **kwargs)
    result = export_cycle(client, plan, Namer(), str(tmp_path), batch_size=batch_size, log=quiet, now=FIXED_NOW)
    return plan, result, tmp_path / f"backup_{STAMP}_CT"


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.reader(fh))


# ---------------------------------------------------------------------------
# Naming and catalog
# ---------------------------------------------------------------------------

def test_slugify_handles_southern_star_names():
    assert slugify(COPY) == "fulcrum_ps_form_42_sscgp_copy"
    assert slugify("Current Year Monthly WHP & Annular Pressure Form") == "current_year_monthly_whp_annular_pressure_form"
    assert slugify("") == "unnamed"


def test_slug_collision_suffixes_only_the_newer_app():
    older = App(id="aaaaaaaa-1111", name="Form 42 (SSCGP)", created_at="2025-01-01")
    newer = App(id="bbbbbbbb-2222", name="Form 42 SSCGP", created_at="2026-01-01")
    assign_slugs([newer, older])
    assert older.slug == "form_42_sscgp"
    assert newer.slug == "form_42_sscgp_bbbbbbbb"


def test_identifier_candidates_prefer_what_fits_in_63_chars():
    mwd = App(id=MWD_ID, name="Master Well Data")
    past = App(id=PAST_ID, name=PAST)
    assert identifier_candidates(mwd) == (MWD_ID, "Master Well Data")
    assert identifier_candidates(mwd, "Master Well Data/tubulars", "tubulars", "k1") == (
        "Master Well Data/tubulars", f"{MWD_ID}/tubulars", f"{MWD_ID}/k1")
    # 70-char name: only the form-ID form fits.
    assert identifier_candidates(past, SHORT_CHILD, "select_well_past_years", "k2")[0] == f"{PAST_ID}/select_well_past_years"
    # 84-char name: neither fits, so the element key goes first.
    assert identifier_candidates(past, LONG_CHILD, "select_well_past_years_repeat_fields", "k3") == (
        f"{PAST_ID}/k3", LONG_CHILD, f"{PAST_ID}/select_well_past_years_repeat_fields")


def test_identifier_limit_counts_bytes_not_characters():
    # The real case from the identifier check: 63 characters, but the leading
    # non-breaking space is 2 bytes, so the name is 64 bytes and the server cut
    # it ("invalid field: fittingsmissingorbrokenphot").
    copy = App(id=COPY_ID, name=COPY)
    name = f"{COPY}/fittingsmissingorbrokenphoto"
    assert (len(name), len(name.encode("utf-8"))) == (63, 64)
    assert identifier_candidates(copy, name, "fittingsmissingorbrokenphoto", "3fd7")[0] == f"{COPY_ID}/3fd7"


def test_namer_uses_central_time_and_templates():
    namer = Namer()
    assert namer.stamp(FIXED_NOW) == STAMP
    assert namer.cycle_folder(STAMP) == f"backup_{STAMP}_CT"
    assert Namer(tag="Dev").cycle_folder(STAMP) == f"dev_backup_{STAMP}_CT"
    assert namer.table_file("master_well_data", STAMP) == f"master_well_data__{STAMP}.csv"
    assert namer.child_table_file("master_well_data", "tubulars", STAMP) == f"master_well_data__tubulars__{STAMP}.csv"


@pytest.mark.parametrize("override", [
    {"table_file": "{app}.csv"},               # no timestamp: acceptance criterion 2
    {"table_file": "{app}/{stamp}.csv"},       # path separator
    {"child_table_file": "{bogus}_{stamp}.csv"},
    {"timezone": "Mars/Olympus_Mons"},
])
def test_bad_naming_config_is_rejected(override):
    with pytest.raises(NamingError):
        Namer(override)


def test_missing_timezone_database_names_the_python_and_the_fix(monkeypatch):
    # A venv without tzdata, on Windows.
    import src.naming as naming

    def no_database(key):
        raise naming.ZoneInfoNotFoundError(key)

    monkeypatch.setattr(naming, "ZoneInfo", no_database)
    monkeypatch.setattr(naming, "_has_tz_database", lambda: False)
    monkeypatch.setattr(naming.sys, "executable", r"D:\repo\.venv\Scripts\python.exe")
    with pytest.raises(NamingError) as caught:
        Namer()
    message = str(caught.value)
    assert "tzdata package is not installed in D:\\repo\\.venv\\Scripts\\python.exe" in message
    assert message.endswith(r"D:\repo\.venv\Scripts\python.exe -m pip install -r requirements.txt")

    monkeypatch.setattr(naming.sys, "executable", r"C:\Program Files\Python311\python.exe")
    with pytest.raises(NamingError, match=r'& "C:\\Program Files\\Python311\\python.exe" -m pip'):
        Namer()


def test_unknown_timezone_is_reported_as_such():
    with pytest.raises(NamingError, match="unknown timezone 'Mars/Olympus_Mons'"):
        Namer({"timezone": "Mars/Olympus_Mons"})


def test_plan_filters_and_reports_uncovered_tables():
    client = make_client(FakeFulcrum(APPS, sample_data()))
    plan = build_plan(client, exclude=[" [Fulcrum PS] Form 42 SSCGP (Copy)"], log=quiet)
    assert [a.name for a in plan.excluded] == [COPY]
    assert COPY not in {t.app.name for t in plan.tables}
    assert ("Issues", "system") in plan.uncovered

    only = build_plan(client, only=["Master Well Data"], log=quiet)
    assert {t.name for t in only.tables} == {"Master Well Data", "Master Well Data/tubulars"}


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

def test_full_export_writes_exact_csvs_manifest_and_success(tmp_path):
    fake = FakeFulcrum(APPS, sample_data(), key_supported=True)
    plan, result, folder = run_export(tmp_path, fake)

    assert result.complete, [r.error for r in result.failed]
    assert (folder / SUCCESS_NAME).exists()
    assert not list(folder.glob("*.part"))

    mwd = read_csv(folder / f"master_well_data__{STAMP}.csv")
    assert mwd[0] == ["_record_id", "_status", "well_name", "notes", "well_notes_attachments"]
    assert mwd[1][3] == "line one\nline two"          # embedded newline survives
    assert len(mwd) == 3

    # 25 rows at batch_size 10: three pages, one header, no row twice.
    tubulars_path = folder / f"master_well_data__tubulars__{STAMP}.csv"
    tubulars = read_csv(tubulars_path)
    assert tubulars[0] == ["_child_record_id", "_record_id", "_parent_id", "size"]
    assert [row[0] for row in tubulars[1:]] == [f"c{i:02d}" for i in range(25)]
    assert any('ORDER BY "_child_record_id"' in q for q in fake.queries)

    manifest = {row["table"]: row for row in csv.DictReader(open(folder / MANIFEST_NAME, newline="", encoding="utf-8"))}
    assert {n for n, row in manifest.items() if row["status"] == "OK"} == {t.name for t in plan.tables}
    assert manifest[ATTACHMENTS]["status"] == "SKIPPED"
    tub = manifest["Master Well Data/tubulars"]
    assert (tub["status"], tub["rows"]) == ("OK", "25")
    data = tubulars_path.read_bytes()
    assert tub["sha256"] == hashlib.sha256(data).hexdigest() and tub["bytes"] == str(len(data))

    # The 84-char table resolved through its element key, the 70-char one by form ID.
    assert manifest[LONG_CHILD]["identifier"].startswith(f"{PAST_ID}/k")
    assert manifest[SHORT_CHILD]["identifier"] == f"{PAST_ID}/select_well_past_years"

    schema_tables = {row["table_name"] for row in csv.DictReader(open(folder / SCHEMA_NAME, newline="", encoding="utf-8"))}
    assert schema_tables == {t.name for t in plan.tables}


def test_attachment_field_tables_are_skipped_not_failed(tmp_path):
    fake = FakeFulcrum(APPS, sample_data(), key_supported=True)
    plan, result, folder = run_export(tmp_path, fake)
    assert [t.name for t, _ in plan.skipped] == [ATTACHMENTS]
    assert ATTACHMENTS not in {t.name for t in plan.tables}
    assert result.complete and (folder / SUCCESS_NAME).exists()
    # The record -> attachment link survives in the app table's own CSV.
    [(skipped_table, _)] = plan.skipped
    assert attachment_column_home(skipped_table, plan.columns) == "Master Well Data"
    assert not any(ATTACHMENTS in q for q in fake.queries)


def test_attachment_column_inside_a_repeatable_is_found():
    # Fulcrum names the app as `parent` even when the field sits inside a
    # repeatable, so the repeatable tables have to be searched as well.
    mwd = App(id=MWD_ID, name="Master Well Data")
    table = ExportTable(app=mwd, name="Master Well Data/add_attachment_workover",
                        data_name="add_attachment_workover", parent="Master Well Data")
    columns = {
        "Master Well Data": ["_record_id", "well_name"],
        "Master Well Data/well_workovers": ["_child_record_id", "_record_id", "add_attachment_workover"],
    }
    assert attachment_column_home(table, columns) == "Master Well Data/well_workovers"
    assert attachment_column_home(table, {"Master Well Data": ["_record_id"]}) == ""
    assert attachment_column_home(table, None) is None


def test_identifier_resolving_to_another_table_is_never_written(tmp_path):
    # No element-key support, and over-long identifiers get truncated: the
    # 84-char name then resolves to its 70-char sibling.
    fake = FakeFulcrum(APPS, sample_data(), truncate_long=True)
    _, result, folder = run_export(tmp_path, fake)

    assert not result.complete
    assert not (folder / SUCCESS_NAME).exists()
    [failed] = result.failed
    assert failed.table.name == LONG_CHILD
    assert "columns are those of" in failed.error
    # The sibling's data must not appear under this table's name.
    assert not (folder / f"past_years_monthly_whp_annular_pressure_forms__select_well_past_years_repeat_fields__{STAMP}.csv").exists()
    manifest = {row["table"]: row for row in csv.DictReader(open(folder / MANIFEST_NAME, newline="", encoding="utf-8"))}
    assert manifest[LONG_CHILD]["status"] == "FAILED"


def test_rows_cut_short_by_the_api_page_size_are_a_failure(tmp_path):
    fake = FakeFulcrum(APPS, sample_data(), key_supported=True, per_page_cap=10)
    _, result, _ = run_export(tmp_path, fake, batch_size=20)
    [failed] = result.failed
    assert failed.table.name == "Master Well Data/tubulars"
    assert "row count mismatch" in failed.error


def test_export_without_columns_catalog_still_completes(tmp_path):
    fake = FakeFulcrum(APPS, sample_data(), key_supported=True, columns_available=False)
    plan, result, folder = run_export(tmp_path, fake)
    assert plan.columns is None
    assert result.complete
    assert not (folder / SCHEMA_NAME).exists()


def test_rejected_token_aborts_but_keeps_the_manifest(tmp_path):
    fake = FakeFulcrum(APPS, sample_data(), count_status=401)
    with pytest.raises(FulcrumAuthError):
        run_export(tmp_path, fake)
    folder = tmp_path / f"backup_{STAMP}_CT"
    assert (folder / MANIFEST_NAME).exists()
    assert not (folder / SUCCESS_NAME).exists()


def test_second_cycle_in_the_same_minute_refuses_to_overwrite(tmp_path):
    fake = FakeFulcrum(APPS, sample_data(), key_supported=True)
    run_export(tmp_path, fake)
    with pytest.raises(FileExistsError):
        run_export(tmp_path, fake)


def test_check_header_notes_quirks_but_rejects_another_tables_columns():
    columns = {"A": ["x", "y"], "B": ["x", "z"]}
    assert check_header(["y", "x"], "A", columns) == ""
    with pytest.raises(HeaderMismatch):
        check_header(["x", "z"], "A", columns)
    assert "extra ['w']" in check_header(["x", "y", "w"], "A", columns)


def test_count_records_counts_records_not_lines():
    assert count_records(b'a,b\n1,"x\ny"\n2,z\n', has_header=True) == 2


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _cli_config(tmp_path):
    path = tmp_path / "config.yaml"
    path.write_text("fulcrum:\n  api_token: test-token\n", encoding="utf-8")
    return str(path)


def test_dry_run_prints_the_plan_and_writes_nothing(tmp_path, monkeypatch, capsys):
    fake = FakeFulcrum(APPS, sample_data())
    monkeypatch.setattr(cli, "FulcrumClient", lambda token, base_url=None: make_client(fake))
    staging = tmp_path / "staging"
    code = cli.main(["export", "--config", _cli_config(tmp_path), "--staging", str(staging), "--dry-run"])
    out = capsys.readouterr().out
    assert code == 0
    assert not staging.exists()
    assert "names over 63 bytes" in out and LONG_CHILD in out
    assert "1 tables skipped: AttachmentField 1" in out
    assert not any(q.startswith("SELECT COUNT") for q in fake.queries)


def test_check_identifiers_reports_the_unresolvable_table(tmp_path, monkeypatch, capsys):
    fake = FakeFulcrum(APPS, sample_data(), truncate_long=True)
    monkeypatch.setattr(cli, "FulcrumClient", lambda token, base_url=None: make_client(fake))
    code = cli.main(["export", "--config", _cli_config(tmp_path), "--dry-run", "--check-identifiers"])
    out = capsys.readouterr().out
    assert code == 1
    assert f"FAIL {LONG_CHILD}" in out
    assert f"FALLBACK {SHORT_CHILD}" not in out   # its first candidate works


def test_config_token_can_come_from_the_environment(tmp_path, monkeypatch):
    path = tmp_path / "config.yaml"
    path.write_text("fulcrum: {}\n", encoding="utf-8")
    monkeypatch.delenv("FULCRUM_API_TOKEN", raising=False)
    with pytest.raises(ConfigError, match="FULCRUM_API_TOKEN"):
        load(str(path))
    monkeypatch.setenv("FULCRUM_API_TOKEN", "from-env")
    assert load(str(path))["fulcrum"]["api_token"] == "from-env"
