"""Tests for the handoff to Southern Star's VM: placeholders, the dry run,
one alert per run listing every failure, preflight, and --at-hours."""

import os
import sys
from datetime import datetime

import pytest
import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import src.main as cli  # noqa: E402
from src import preflight  # noqa: E402
from src.config import load, placeholders  # noqa: E402
from src.deliver import DRY_RUN_MARKER, find_cycle  # noqa: E402
from sftp_stub import SFTPTestServer  # noqa: E402
from smtp_stub import SMTPStub  # noqa: E402
from test_alerts import SENDER, with_alerts  # noqa: E402
from test_attachments import A1, A2, cli_fakes, write_config  # noqa: E402,F401  (cli_fakes is a fixture)

EXAMPLE = os.path.join(ROOT, "config", "config.example.yaml")


def edit_config(path, change):
    data = yaml.safe_load(open(path, encoding="utf-8"))
    change(data)
    open(path, "w", encoding="utf-8").write(yaml.safe_dump(data))
    return path


# ---------------------------------------------------------------------------
# Placeholders
# ---------------------------------------------------------------------------

def test_the_example_config_lists_exactly_what_southern_star_owes(monkeypatch):
    for var in ("FULCRUM_API_TOKEN", "SFTP_PROD_PASSWORD", "SFTP_UAT_PASSWORD", "SMTP_PASSWORD"):
        monkeypatch.delenv(var, raising=False)
    keys = [key for key, _ in placeholders(load(EXAMPLE, ()), "prod")]
    assert keys == [
        "site.vm_hostname", "site.install_path", "fulcrum.api_token",
        "sftp.accounts.prod.username", "sftp.accounts.prod.password", "sftp.accounts.prod.remote_dir",
        "alerts.sender", "alerts.smtp_host", "alerts.smtp_port", "alerts.security",
    ]


def test_environment_variables_fill_their_placeholders(monkeypatch):
    monkeypatch.setenv("FULCRUM_API_TOKEN", "real-token")
    monkeypatch.setenv("SFTP_PROD_PASSWORD", "real-password")
    keys = [key for key, _ in placeholders(load(EXAMPLE, ()), "prod")]
    assert "fulcrum.api_token" not in keys and "sftp.accounts.prod.password" not in keys


def placeholder_config(tmp_path, server):
    config = write_config(tmp_path, server)

    def change(data):
        data["site"] = {"vm_hostname": "<<SOUTHERN_STAR: VM hostname>>"}
        data["sftp"]["accounts"]["uat"]["remote_dir"] = "<<SOUTHERN_STAR: SFTP target directory>>"
        data["alerts"] = {"sender": "<<SOUTHERN_STAR: SMTP sender address>>"}
    return edit_config(config, change)


def test_a_real_run_refuses_to_start_and_lists_every_placeholder(tmp_path, cli_fakes, capsys):
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server:
        code = cli.main(["run", "--config", placeholder_config(tmp_path, server)])
        events = list(server.events)
    out = capsys.readouterr().out
    assert code == 2
    assert "3 value(s) in the config are still placeholders, so a real run won't start" in out
    for line in ("site.vm_hostname: <<SOUTHERN_STAR: VM hostname>>",
                 "sftp.accounts.uat.remote_dir: <<SOUTHERN_STAR: SFTP target directory>>",
                 "alerts.sender: <<SOUTHERN_STAR: SMTP sender address>>"):
        assert line in out
    assert "no failure alert sent: alerts settings are still placeholders: alerts.sender" in out
    assert events == [] and not (tmp_path / "staging").exists()


def test_deliver_and_alert_test_refuse_too(tmp_path, cli_fakes, capsys):
    with SFTPTestServer(str(tmp_path / "landing")) as server:
        config = placeholder_config(tmp_path, server)
        assert cli.main(["deliver", "--config", config]) == 2
        assert cli.main(["alert-test", "--config", config]) == 2
    assert "alerts settings are still placeholders" in capsys.readouterr().out


def test_the_other_landing_account_may_keep_its_placeholders(tmp_path, cli_fakes):
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server:
        config = edit_config(write_config(tmp_path, server), lambda d: d["sftp"]["accounts"].update(
            prod={"username": "<<SOUTHERN_STAR: SFTP username>>"}))
        assert cli.main(["run", "--config", config, "--tag", "dev"]) == 0


# ---------------------------------------------------------------------------
# Dry run
# ---------------------------------------------------------------------------

def test_a_dry_run_pulls_locally_with_placeholders_and_uploads_nothing(tmp_path, cli_fakes, logs_in_tmp, capsys):
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server, SMTPStub() as relay:
        config = placeholder_config(tmp_path, server)
        code = cli.main(["run", "--config", config, "--dry-run"])
        events = list(server.events)
    out = capsys.readouterr().out
    assert code == 0, out
    assert events == [] and relay.messages == []
    [folder] = os.listdir(tmp_path / "staging")
    assert folder.startswith("backup_") and folder.endswith("_CT")      # the production name, no prefix
    cycle = tmp_path / "staging" / folder
    assert (cycle / "_SUCCESS").is_file() and (cycle / DRY_RUN_MARKER).is_file()
    assert len(os.listdir(cycle / "attachments")) == 5
    assert "Nothing was uploaded and no email was sent" in out
    assert len(list(logs_in_tmp.iterdir())) == 1                          # logged like a real run
    assert find_cycle(str(tmp_path / "staging"), "uat") is None           # deliver never picks it up


def test_a_failing_dry_run_exits_1_but_sends_no_alert(tmp_path, cli_fakes, capsys):
    _api, storage = cli_fakes
    storage.failing[A1] = 99
    with SFTPTestServer(str(tmp_path / "landing")) as server, SMTPStub() as relay:
        config = with_alerts(write_config(tmp_path, server), relay)
        assert cli.main(["run", "--config", config, "--dry-run"]) == 1
    assert relay.messages == []
    assert "Dry run: no alert sent." in capsys.readouterr().out


def test_a_dry_run_still_needs_the_fulcrum_token(tmp_path, cli_fakes, capsys):
    with SFTPTestServer(str(tmp_path)) as server:
        config = edit_config(write_config(tmp_path, server), lambda d: d["fulcrum"].update(
            api_token="<<SOUTHERN_STAR: service account API token>>"))
    assert cli.main(["run", "--config", config, "--dry-run"]) == 2
    assert "set FULCRUM_API_TOKEN" in capsys.readouterr().out


# ---------------------------------------------------------------------------
# One alert per run, listing everything that failed
# ---------------------------------------------------------------------------

def test_one_alert_lists_every_failure(tmp_path, cli_fakes, capsys):
    _api, storage = cli_fakes
    storage.failing[A1] = 99
    storage.failing[A2] = 99
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server, SMTPStub() as relay:
        config = edit_config(with_alerts(write_config(tmp_path, server), relay),
                             lambda d: d.update(site={"vm_hostname": "SSCGP-BKP01"}))
        code = cli.main(["run", "--config", config, "--tag", "dev"])
    assert code == 1
    [(_sender, _recipients, message)] = relay.messages                   # one email, not one per failure
    body = message.get_content().replace("\r\n", "\n")
    assert message["Subject"] == "[Fulcrum Backup] FAILED"
    assert "What failed (2):" in body
    assert f"  - attachment {A1} (Master Well Data, record" in body
    assert f"  - attachment {A2} (Master Well Data, record" in body
    assert "(the config expects SSCGP-BKP01)" in body


def test_a_failed_table_is_listed_and_the_backup_is_not_delivered(tmp_path, cli_fakes, capsys):
    api, _storage = cli_fakes
    api.count_status = None
    api.data["Master Well Data/well_workovers"] = (["_child_record_id"], [["c1"], ["c2"]])
    api.per_page_cap = 1     # the fetch comes back short: a row-count mismatch on that table
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server, SMTPStub() as relay:
        config = with_alerts(write_config(tmp_path, server), relay)
        code = cli.main(["run", "--config", config, "--tag", "dev"])
    assert code == 1 and os.listdir(landing_root) == []
    body = relay.messages[0][2].get_content()
    assert 'table "Master Well Data/well_workovers"' in body and "not delivered: the export is incomplete" in body


# ---------------------------------------------------------------------------
# Preflight
# ---------------------------------------------------------------------------

class FakeClient:
    def __init__(self, token, base_url=None, log=None):
        self.token = token

    def get_json(self, path, params=None):
        return {"forms": [], "total_count": 24}

    def query_rows(self, sql):
        return [{"n": 239}]


class Answer:
    status_code = 403


def run_preflight(tmp_path, config, env="uat"):
    folders = {"staging": str(tmp_path / "staging"), "state": str(tmp_path / "state"), "logs": str(tmp_path / "logs")}
    return {c.item: c for c in preflight.run_checks(load(config, ()), env, folders, ROOT,
                                                    client_factory=FakeClient, http_get=lambda url, timeout: Answer())}


def test_preflight_passes_item_by_item_and_sends_nothing(tmp_path, monkeypatch):
    monkeypatch.setenv("FULCRUM_API_TOKEN", "real-token")
    with SFTPTestServer(str(tmp_path)) as server, SMTPStub() as relay:
        config = with_alerts(write_config(tmp_path, server), relay)
        checks = run_preflight(tmp_path, config)
        events = list(server.events)
    statuses = {item: check.status for item, check in checks.items()}
    assert statuses == {
        "placeholders": "PASS", "python": "PASS", "timezone": "PASS", "staging folder": "PASS",
        "state folder": "PASS", "logs folder": "PASS", "machine": "SKIP", "install path": "SKIP",
        "Fulcrum API": "PASS", "Fulcrum Query API": "PASS", "attachment downloads": "PASS",
        "SFTP login": "PASS", "SFTP landing directory": "PASS", "SMTP relay": "PASS",
    }
    assert "24 apps visible" in checks["Fulcrum API"].detail
    assert relay.messages == [] and events == []                          # nothing sent, nothing written


def test_preflight_skips_what_is_still_a_placeholder_and_fails_what_is_wrong(tmp_path, monkeypatch):
    monkeypatch.delenv("FULCRUM_API_TOKEN", raising=False)
    with SFTPTestServer(str(tmp_path)) as server, SMTPStub(refuse_sender=True) as relay:
        config = edit_config(with_alerts(write_config(tmp_path, server), relay), lambda d: (
            d["sftp"]["accounts"]["uat"].update(username="<<SOUTHERN_STAR: SFTP username>>"),
            d.update(site={"vm_hostname": "not-this-machine"})))
        checks = run_preflight(tmp_path, config)
    assert checks["placeholders"].status == "FAIL" and "sftp.accounts.uat.username" in checks["placeholders"].detail
    assert checks["SFTP"].status == "SKIP"
    assert checks["machine"].status == "WARN"
    assert checks["Fulcrum token"].status == "WARN"                      # read from the file, not the env
    assert checks["SMTP relay"].status == "FAIL" and f"refused the sender {SENDER!r}" in checks["SMTP relay"].detail


def test_preflight_command_prints_pass_fail_and_exits_1_when_not_ready(tmp_path, cli_fakes, monkeypatch, capsys):
    monkeypatch.setattr(preflight, "FulcrumClient", FakeClient)
    monkeypatch.setattr(preflight.requests, "get", lambda url, timeout: Answer())
    with SFTPTestServer(str(tmp_path)) as server:
        code = cli.main(["preflight", "--config", placeholder_config(tmp_path, server)])
    out = capsys.readouterr().out
    assert code == 1
    assert "[FAIL] placeholders: 3 value(s) still to fill in" in out
    assert "[SKIP] SFTP: still placeholders: sftp.accounts.uat.remote_dir" in out
    assert "[PASS] Fulcrum API" in out
    assert "Still to fill in:" in out and "RESULT: NOT READY" in out


# ---------------------------------------------------------------------------
# --at-hours, for cron on a UTC machine
# ---------------------------------------------------------------------------

class FrozenDatetime(datetime):
    hour_utc = 13

    @classmethod
    def now(cls, tz=None):
        moment = datetime(2026, 11, 4, cls.hour_utc, 0, tzinfo=__import__("datetime").timezone.utc)
        return moment.astimezone(tz) if tz else moment


@pytest.mark.parametrize("hour_utc, runs", [
    (14, True),    # 08:00 CST (4 Nov, after daylight saving ends)
    (13, False),   # 07:00 CST
    (2, True),     # 20:00 CST
    (1, False),    # 19:00 CST
])
def test_at_hours_runs_only_at_8_and_20_central(tmp_path, monkeypatch, capsys, hour_utc, runs):
    FrozenDatetime.hour_utc = hour_utc
    monkeypatch.setattr(cli, "datetime", FrozenDatetime)
    called = []
    monkeypatch.setitem(cli.COMMANDS, "run", lambda args: called.append(args) or 0)
    config = tmp_path / "config.yaml"
    config.write_text("{}", encoding="utf-8")
    assert cli.main(["run", "--config", str(config), "--at-hours", "8,20"]) == 0
    assert bool(called) == runs
    if not runs:
        assert "Not a scheduled hour" in capsys.readouterr().out


def test_relative_config_paths_are_under_the_install_folder():
    assert cli._state_dir({"export": {"state_dir": "state"}}) == os.path.join(cli.BASE_DIR, "state")
    assert cli._state_dir({"export": {"state_dir": "/var/lib/backup/state"}}) == "/var/lib/backup/state"
    assert cli.DEFAULT_CONFIG == os.path.join(ROOT, "config", "config.yaml")
