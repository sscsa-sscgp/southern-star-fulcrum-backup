"""Shared test setup."""

import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import src.main as cli  # noqa: E402


@pytest.fixture(autouse=True)
def logs_in_tmp(tmp_path, monkeypatch):
    """CLI runs write log files; keep them out of the repo."""
    monkeypatch.setattr(cli, "DEFAULT_LOG_DIR", str(tmp_path / "logs"))
    return tmp_path / "logs"
