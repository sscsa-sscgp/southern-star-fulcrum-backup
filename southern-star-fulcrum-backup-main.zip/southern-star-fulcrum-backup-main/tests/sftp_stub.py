"""In-process SFTP server for tests: paramiko's server side over a temp directory.

Tests never touch Southern Star's file-transfer host. This server runs the real client code paths (handshake,
host-key check, password auth, SFTP operations) against localhost instead.

`events` records every mutating operation in order, so tests can assert what
happened when -- for example that _SUCCESS is the very last file written.
"""

import base64
import hashlib
import os
import socket
import threading

import paramiko


def fingerprint_of(key):
    digest = hashlib.sha256(key.asbytes()).digest()
    return "SHA256:" + base64.b64encode(digest).decode("ascii").rstrip("=")


class _StubServer(paramiko.ServerInterface):
    def __init__(self, username, password):
        self.username = username
        self.password = password

    def get_allowed_auths(self, username):
        return "password"

    def check_auth_password(self, username, password):
        if (username, password) == (self.username, self.password):
            return paramiko.AUTH_SUCCESSFUL
        return paramiko.AUTH_FAILED

    def check_channel_request(self, kind, chanid):
        return paramiko.OPEN_SUCCEEDED


class _StubHandle(paramiko.SFTPHandle):
    def stat(self):
        try:
            return paramiko.SFTPAttributes.from_stat(os.fstat(self.readfile.fileno()))
        except OSError as exc:
            return paramiko.SFTPServer.convert_errno(exc.errno)


class _StubSFTP(paramiko.SFTPServerInterface):
    """Serves a temp directory. deny_rename simulates a drop box that forbids
    renames, which temp-name-then-rename uploads depend on."""

    def __init__(self, server, root, deny_rename=False, events=None):
        super().__init__(server)
        self.root = root
        self.deny_rename = deny_rename
        self.events = events if events is not None else []

    def _real(self, path):
        return os.path.join(self.root, self.canonicalize(path).lstrip("/"))

    def _attrs(self, real, name=None):
        attr = paramiko.SFTPAttributes.from_stat(os.stat(real))
        if name is not None:
            attr.filename = name
        return attr

    def list_folder(self, path):
        real = self._real(path)
        try:
            return [self._attrs(os.path.join(real, name), name) for name in os.listdir(real)]
        except OSError as exc:
            return paramiko.SFTPServer.convert_errno(exc.errno)

    def stat(self, path):
        try:
            return self._attrs(self._real(path))
        except OSError as exc:
            return paramiko.SFTPServer.convert_errno(exc.errno)

    lstat = stat

    def open(self, path, flags, attr):
        real = self._real(path)
        try:
            fd = os.open(real, flags | getattr(os, "O_BINARY", 0), 0o644)
        except OSError as exc:
            return paramiko.SFTPServer.convert_errno(exc.errno)
        if flags & (os.O_WRONLY | os.O_RDWR):
            self.events.append(("write", self.canonicalize(path)))
        mode = "wb" if flags & os.O_WRONLY else ("r+b" if flags & os.O_RDWR else "rb")
        handle = _StubHandle(flags)
        handle.filename = real
        handle.readfile = handle.writefile = os.fdopen(fd, mode)
        return handle

    def remove(self, path):
        try:
            os.remove(self._real(path))
        except OSError as exc:
            return paramiko.SFTPServer.convert_errno(exc.errno)
        self.events.append(("remove", self.canonicalize(path)))
        return paramiko.SFTP_OK

    def rename(self, oldpath, newpath):
        if self.deny_rename:
            return paramiko.SFTP_PERMISSION_DENIED
        if os.path.exists(self._real(newpath)):
            # SFTP v3 rename does not overwrite; OpenSSH refuses too.
            return paramiko.SFTP_FAILURE
        try:
            os.rename(self._real(oldpath), self._real(newpath))
        except OSError as exc:
            return paramiko.SFTPServer.convert_errno(exc.errno)
        self.events.append(("rename", self.canonicalize(oldpath), self.canonicalize(newpath)))
        return paramiko.SFTP_OK

    def mkdir(self, path, attr):
        try:
            os.mkdir(self._real(path))
        except OSError as exc:
            return paramiko.SFTPServer.convert_errno(exc.errno)
        self.events.append(("mkdir", self.canonicalize(path)))
        return paramiko.SFTP_OK

    def rmdir(self, path):
        try:
            os.rmdir(self._real(path))
        except OSError as exc:
            return paramiko.SFTPServer.convert_errno(exc.errno)
        self.events.append(("rmdir", self.canonicalize(path)))
        return paramiko.SFTP_OK


class SFTPTestServer:
    """Accepts any number of connections on localhost until stopped."""

    def __init__(self, root, username="fulcrum_test", password="s3cret", deny_rename=False):
        self.root = root
        self.username = username
        self.password = password
        self.deny_rename = deny_rename
        self.events = []
        self.host_key = paramiko.RSAKey.generate(2048)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(8)
        self.sock.settimeout(0.2)
        self.port = self.sock.getsockname()[1]
        self.transports = []
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._serve, daemon=True)

    def _serve(self):
        while not self._stop.is_set():
            try:
                conn, _ = self.sock.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            transport = paramiko.Transport(conn)
            transport.add_server_key(self.host_key)
            transport.set_subsystem_handler(
                "sftp", paramiko.SFTPServer, _StubSFTP, self.root, self.deny_rename, self.events)
            try:
                transport.start_server(server=_StubServer(self.username, self.password))
            except (paramiko.SSHException, EOFError, OSError):
                continue
            self.transports.append(transport)

    def __enter__(self):
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        for transport in self.transports:
            transport.close()
        self.sock.close()
        self._thread.join(timeout=2)

    @property
    def fingerprint(self):
        return fingerprint_of(self.host_key)
