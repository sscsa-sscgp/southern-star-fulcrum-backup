"""A minimal in-process SMTP relay, so the alert tests drive smtplib for real.

Speaks just enough SMTP for smtplib.send_message: EHLO/HELO, MAIL, RCPT,
DATA, RSET, NOOP, QUIT. refuse_sender makes it answer MAIL FROM with 553,
like a relay that only accepts senders it knows.
"""

import email
import email.policy
import socketserver
import threading


class _Handler(socketserver.StreamRequestHandler):
    def _reply(self, line):
        self.wfile.write((line + "\r\n").encode("ascii"))

    def handle(self):
        relay = self.server.relay
        sender, recipients = None, []
        self._reply("220 stub relay ready")
        while True:
            raw = self.rfile.readline()
            if not raw:
                return
            line = raw.decode("utf-8", "replace").rstrip("\r\n")
            verb = line.split(" ", 1)[0].upper()
            if verb in ("EHLO", "HELO"):
                self._reply("250 stub")
            elif verb == "MAIL":
                if relay.refuse_sender:
                    self._reply("553 5.7.1 sender not allowed to relay")
                    continue
                sender = line.split(":", 1)[1].strip().split()[0].strip("<>")
                self._reply("250 OK")
            elif verb == "RCPT":
                recipients.append(line.split(":", 1)[1].strip().strip("<>"))
                self._reply("250 OK")
            elif verb == "DATA":
                self._reply("354 end with <CRLF>.<CRLF>")
                lines = []
                while True:
                    chunk = self.rfile.readline()
                    if chunk in (b".\r\n", b".\n", b""):
                        break
                    lines.append(chunk[1:] if chunk.startswith(b"..") else chunk)
                message = email.message_from_bytes(b"".join(lines), policy=email.policy.default)
                relay.messages.append((sender, list(recipients), message))
                sender, recipients = None, []
                self._reply("250 queued")
            elif verb in ("RSET", "NOOP"):
                self._reply("250 OK")
            elif verb == "QUIT":
                self._reply("221 bye")
                return
            else:
                self._reply("502 not implemented")


class SMTPStub:
    def __init__(self, refuse_sender=False):
        self.refuse_sender = refuse_sender
        self.messages = []
        self._server = socketserver.ThreadingTCPServer(("127.0.0.1", 0), _Handler)
        self._server.daemon_threads = True
        self._server.relay = self
        self.port = self._server.server_address[1]

    def __enter__(self):
        threading.Thread(target=self._server.serve_forever, daemon=True).start()
        return self

    def __exit__(self, *exc):
        self._server.shutdown()
        self._server.server_close()
