"""Tests for record attachments (src/attachments.py) and their delivery.

A fake Attachments API and a fake storage host sit behind the fake Fulcrum
from test_export.py. The attachment columns are shaped like Southern Star's:
<field> holds the attachment IDs, <field>_names
the file names, and the `columns` catalog marks both as AttachmentField, the
IDs with an empty part.
"""

import csv
import hashlib
import json
import os
import sys
from datetime import timedelta

import pytest
import yaml

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import src.main as cli  # noqa: E402
from src.attachments import (  # noqa: E402
    ATTACHMENTS_DIR, BASIS_NAME, INDEX_NAME, AttachmentState, AttachmentStep, Downloader, Source, scan,
)
from src.catalog import build_plan  # noqa: E402
from src.deliver import DeliveryError, deliver_cycle  # noqa: E402
from src.export import MANIFEST_NAME, SUCCESS_NAME, export_cycle, long_path  # noqa: E402
from src.naming import Namer, NamingError  # noqa: E402
from src.sftp_client import UploadError, connect  # noqa: E402
from sftp_stub import SFTPTestServer  # noqa: E402
from test_export import FIXED_NOW, FakeFulcrum, Resp, make_client, quiet  # noqa: E402

MWD_ID = "94b6ae8c-9a38-4593-a865-e943353ddeaa"
SEAL_ID = "2f81caf8-70f9-4c49-8a3c-8d3dd2f5a09d"
APPS = [
    (MWD_ID, "Master Well Data", "2025-01-01T00:00:00Z"),
    (SEAL_ID, "Wellhead Seal Testing", "2025-03-01T00:00:00Z"),
]


def uid(n):
    return f"{n:08x}-0000-4000-8000-{n:012x}"


R1, R2, R3, R4, C1 = uid(0x101), uid(0x102), uid(0x103), uid(0x104), uid(0x201)
A1, A2, A3, A4, A5, A6 = (uid(n) for n in range(0xA01, 0xA07))

#: The unqueryable AttachmentField tables, and the fields' data names.
ATTACHMENT_TABLES = {"Master Well Data/cad_wellhead_drawing", "Master Well Data/add_attachment_workover",
                     "Wellhead Seal Testing/upload_attachment_upper_test_port_on_dspa"}
ATTACHMENT_FIELDS = {name.split("/", 1)[1] for name in ATTACHMENT_TABLES}
SECOND_CYCLE = FIXED_NOW + timedelta(hours=12)


def attachment_data():
    return {
        "Master Well Data": (
            ["_record_id", "_status", "well_name", "cad_wellhead_drawing", "cad_wellhead_drawing_names"],
            [[R1, "Active", "Webb 52", A1, "Wellhead A.pdf"],
             [R2, "Plugged", "Webb 54H", f"{A2},{A3}", "B.pdf,C.docx"],
             [R3, "Active", "Webb 60", "", ""]],
        ),
        "Master Well Data/well_workovers": (
            ["_child_record_id", "_record_id", "_parent_id", "add_attachment_workover", "add_attachment_workover_names"],
            [[C1, R1, R1, A4, "workover notes.xlsx"]],
        ),
        "Master Well Data/cad_wellhead_drawing": (["_record_id", "attachment_id"], []),
        "Master Well Data/add_attachment_workover": (["_record_id", "attachment_id"], []),
        "Wellhead Seal Testing": (
            ["_record_id", "upload_attachment_upper_test_port_on_dspa", "upload_attachment_upper_test_port_on_dspa_names"],
            [[R4, A5, "s.s elk#33 void test fail.xlsx"]],
        ),
        "Wellhead Seal Testing/upload_attachment_upper_test_port_on_dspa": (["_record_id", "attachment_id"], []),
    }


class AttachmentApi(FakeFulcrum):
    """The fake Fulcrum, plus a `columns` catalog with field_type and part,
    and the Attachments API: list per record, get one by ID."""

    def __init__(self, files=None):
        super().__init__(APPS, attachment_data(), key_supported=True)
        self.files = files if files is not None else {
            A1: {"record": R1, "name": "Wellhead A.pdf", "content": b"%PDF-1.7 wellhead A"},
            A2: {"record": R2, "name": "B.pdf", "content": b"%PDF-1.7 b"},
            A3: {"record": R2, "name": "C.docx", "content": b"PK docx c" * 50},
            A4: {"record": R1, "name": "workover notes.xlsx", "content": b"PK xlsx workover"},
            A5: {"record": R4, "name": "s.s elk#33 void test fail.xlsx", "content": b"PK xlsx seal"},
        }
        self.api_calls = []

    def tables_rows(self):
        rows = super().tables_rows()
        for row in rows:
            if row["name"] in ATTACHMENT_TABLES:
                row["field_type"] = "AttachmentField"
        return rows

    def resolve(self, ident):
        table = super().resolve(ident)
        return None if table in ATTACHMENT_TABLES else table

    def meta(self, attachment_id):
        f = self.files[attachment_id]
        complete = f.get("complete", True)
        return {
            "id": attachment_id, "owners": [{"type": "record", "id": f["record"]}], "name": f["name"],
            "file_size": len(f["content"]), "url": f"https://storage.test/{attachment_id}?v={f.get('version', 0)}",
            "uploaded_at": "2026-09-01T12:00:00Z", "complete": complete, "attached_to_id": f["record"],
            "attached_to_type": "record", "status": "complete" if complete else "processing",
        }

    def get(self, url, headers=None, params=None, timeout=None):
        params = params or {}
        if url.endswith("/api/v2/attachments"):
            assert params.get("owner_type") == "record"
            self.api_calls.append(("list", params.get("record_id")))
            items = [self.meta(a) for a, f in self.files.items()
                     if f["record"] == params.get("record_id") and not f.get("unlisted")]
            return Resp(200, {"attachments": items, "total": len(items), "total_count": len(items)})
        if "/api/v2/attachments/" in url:
            attachment_id = url.rsplit("/", 1)[1]
            self.api_calls.append(("get", attachment_id))
            if attachment_id not in self.files:
                return Resp(404, {"error": "Not Found"})
            self.files[attachment_id]["version"] = self.files[attachment_id].get("version", 0) + 1  # a fresh URL
            return Resp(200, self.meta(attachment_id))
        if params.get("q") == "SELECT * FROM columns" and self.columns_available:
            rows = []
            for table, (header, _) in self.data.items():
                for column in header:
                    base = column[:-len("_names")] if column.endswith("_names") else column
                    is_attachment = base in ATTACHMENT_FIELDS and table not in ATTACHMENT_TABLES
                    rows.append({"table_name": table, "name": column, "type": "array" if is_attachment else "text",
                                 "field_type": "AttachmentField" if is_attachment else None,
                                 "data_name": base if is_attachment else None,
                                 "part": ("names" if column.endswith("_names") else None) if is_attachment else None})
            return Resp(200, {"rows": rows})
        return super().get(url, headers=headers, params=params, timeout=timeout)


class Download:
    def __init__(self, status, content=b""):
        self.status_code = status
        self.content = content

    def iter_content(self, chunk_size=1):
        for start in range(0, len(self.content), chunk_size):
            yield self.content[start:start + chunk_size]

    def close(self):
        pass


class FakeStorage:
    """The signed-URL storage host. Records every request it gets."""

    def __init__(self, api):
        self.api = api
        self.requests = []
        self.failing = {}      # attachment ID -> how many more times to answer 500
        self.expired = set()   # URLs that answer 403

    def get(self, url, headers=None, stream=False, timeout=None):
        self.requests.append((url, headers))
        attachment_id = url.split("/")[-1].split("?")[0]
        if url in self.expired:
            return Download(403)
        if self.failing.get(attachment_id):
            self.failing[attachment_id] -= 1
            return Download(500)
        f = self.api.files.get(attachment_id)
        return Download(200, f["content"]) if f else Download(404)


def downloader_for(storage):
    downloader = Downloader(session=storage, log=quiet)
    downloader._sleep = lambda _seconds: None
    return downloader


def export_with_attachments(tmp_path, api, storage, now=FIXED_NOW, env="uat", tag=None, full_snapshot=False):
    client = make_client(api)
    state = AttachmentState(AttachmentState.path_for(str(tmp_path / "state"), env, tag))
    step = AttachmentStep(client, state, env, tag=tag, full_snapshot=full_snapshot,
                          downloader=downloader_for(storage), log=quiet)
    plan = build_plan(client, log=quiet)
    return export_cycle(client, plan, Namer(tag=tag), str(tmp_path / "staging"), batch_size=10, log=quiet,
                        now=now, attachments=step)


def rows_of(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def deliver_to(server, cycle, tmp_path, env="uat"):
    with connect("127.0.0.1", server.port, server.username, server.password, server.fingerprint, timeout=5) as landing:
        return deliver_cycle(landing, cycle, ".", env, log=quiet, state_dir=str(tmp_path / "state"))


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

def test_attachments_are_read_from_the_csvs_and_downloaded(tmp_path):
    api = AttachmentApi()
    result = export_with_attachments(tmp_path, api, FakeStorage(api))

    assert result.complete and os.path.isfile(os.path.join(result.path, SUCCESS_NAME))
    by_id = {entry.attachment_id: entry for entry in result.attachments}
    assert set(by_id) == {A1, A2, A3, A4, A5}
    assert {entry.status for entry in by_id.values()} == {"NEW"}
    # Two IDs in one cell, both found; one inside a repeatable, tied to its item.
    assert by_id[A2].record_id == by_id[A3].record_id == R2
    assert (by_id[A4].table, by_id[A4].record_id, by_id[A4].child_record_id) == ("Master Well Data/well_workovers", R1, C1)
    # Named by app, record and attachment; the original name only in the index.
    assert by_id[A5].file == f"{ATTACHMENTS_DIR}/wellhead_seal_testing__{R4}__{A5}.xlsx"
    for entry in by_id.values():
        with open(os.path.join(result.path, *entry.file.split("/")), "rb") as fh:
            assert fh.read() == api.files[entry.attachment_id]["content"]

    manifest = [row for row in rows_of(os.path.join(result.path, MANIFEST_NAME)) if row["field_type"] == "AttachmentField"]
    ok = {row["identifier"]: row for row in manifest if row["status"] == "OK"}
    assert set(ok) == {A1, A2, A3, A4, A5}
    content = api.files[A3]["content"]
    assert ok[A3]["bytes"] == str(len(content)) and ok[A3]["sha256"] == hashlib.sha256(content).hexdigest()

    index = {row["attachment_id"]: row for row in rows_of(os.path.join(result.path, INDEX_NAME))}
    assert index[A5]["name"] == "s.s elk#33 void test fail.xlsx"
    assert index[A5]["delivered_in"] == result.folder and index[A5]["status"] == "NEW"
    with open(os.path.join(result.path, BASIS_NAME), encoding="utf-8") as fh:
        assert json.load(fh)["env"] == "uat"


def test_without_a_catalog_the_id_columns_are_found_by_field_name(tmp_path):
    api = AttachmentApi()
    api.columns_available = False    # `columns` unavailable: fall back to the skipped tables' data names
    result = export_with_attachments(tmp_path, api, FakeStorage(api))
    assert {entry.attachment_id for entry in result.attachments} == {A1, A2, A3, A4, A5}
    assert {entry.column for entry in result.attachments} == {
        "cad_wellhead_drawing", "add_attachment_workover", "upload_attachment_upper_test_port_on_dspa"}


def test_ids_parse_whatever_the_cell_format(tmp_path):
    path = tmp_path / "t.csv"
    path.write_text(
        "_record_id,files\n"
        f'{R1},"{A1},{A2}"\n'
        f'{R2},"{{{A3},{A4}}}"\n'
        f'{R3},"[""{A5}"", ""{A6}""]"\n'
        f"{R4},not an id\n",
        encoding="utf-8")
    entries, unparsed = scan([Source("T", str(path), "App", "app-id", "app", ["files"])])
    assert [e.attachment_id for e in entries] == [A1, A2, A3, A4, A5, A6]
    assert unparsed == 1


def test_the_api_token_never_goes_to_the_storage_host(tmp_path):
    api = AttachmentApi()
    storage = FakeStorage(api)
    export_with_attachments(tmp_path, api, storage)
    assert storage.requests
    assert all(not headers and "test-token" not in url for url, headers in storage.requests)
    assert "X-ApiToken" not in Downloader()._session.headers


def test_pending_and_missing_attachments_leave_the_cycle_complete(tmp_path):
    api = AttachmentApi()
    api.files[A2]["complete"] = False   # still uploading from a device
    del api.files[A3]                   # referenced, but gone from Fulcrum
    result = export_with_attachments(tmp_path, api, FakeStorage(api))

    status = {entry.attachment_id: entry.status for entry in result.attachments}
    assert status == {A1: "NEW", A2: "PENDING", A3: "MISSING", A4: "NEW", A5: "NEW"}
    assert result.complete and not result.attachment_failures
    assert os.path.isfile(os.path.join(result.path, SUCCESS_NAME))
    files = os.listdir(os.path.join(result.path, ATTACHMENTS_DIR))
    assert len(files) == 3 and not any(name.endswith(".part") for name in files)


def test_a_failed_download_does_not_hold_back_the_tables(tmp_path):
    api = AttachmentApi()
    storage = FakeStorage(api)
    storage.failing[A1] = 99
    result = export_with_attachments(tmp_path, api, storage)

    assert [entry.attachment_id for entry in result.attachment_failures] == [A1]
    assert "HTTP 500" in result.attachment_failures[0].error
    assert result.complete and os.path.isfile(os.path.join(result.path, SUCCESS_NAME))
    manifest_ids = {row["identifier"] for row in rows_of(os.path.join(result.path, MANIFEST_NAME))}
    assert A1 not in manifest_ids and A4 in manifest_ids


def test_an_expired_url_is_refreshed_once(tmp_path):
    api = AttachmentApi()
    storage = FakeStorage(api)
    storage.expired.add(f"https://storage.test/{A1}?v=0")
    result = export_with_attachments(tmp_path, api, storage)
    assert {e.attachment_id: e.status for e in result.attachments}[A1] == "NEW"
    assert ("get", A1) in api.api_calls


def test_lookups_are_one_listing_per_record(tmp_path):
    api = AttachmentApi()
    api.files[A4]["unlisted"] = True   # the listing misses it; a single lookup finds it
    export_with_attachments(tmp_path, api, FakeStorage(api))
    assert sorted(call for call in api.api_calls if call[0] == "list") == [("list", r) for r in sorted((R1, R2, R4))]
    assert [call for call in api.api_calls if call[0] == "get"] == [("get", A4)]


# ---------------------------------------------------------------------------
# Delivery and the incremental cycle (acceptance criterion 5)
# ---------------------------------------------------------------------------

def test_delivery_sends_the_attachments_folder_and_then_records_them(tmp_path):
    api = AttachmentApi()
    result = export_with_attachments(tmp_path, api, FakeStorage(api))
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server:
        delivery = deliver_to(server, result.path, tmp_path)
        events = list(server.events)

    remote = landing_root / result.folder
    assert sorted(os.listdir(remote / ATTACHMENTS_DIR)) == sorted(os.listdir(os.path.join(result.path, ATTACHMENTS_DIR)))
    assert (remote / INDEX_NAME).is_file() and not (remote / BASIS_NAME).exists()
    assert ("mkdir", f"/{result.folder}/{ATTACHMENTS_DIR}") in events
    assert events[-1] == ("rename", f"/{result.folder}/{SUCCESS_NAME}.part", f"/{result.folder}/{SUCCESS_NAME}")
    assert delivery.attachments_recorded == 5
    state = AttachmentState(AttachmentState.path_for(str(tmp_path / "state"), "uat"))
    assert set(state.entries) == {A1, A2, A3, A4, A5}
    assert state.entries[A1]["cycle"] == result.folder


def test_a_failed_delivery_records_nothing(tmp_path):
    api = AttachmentApi()
    result = export_with_attachments(tmp_path, api, FakeStorage(api))
    (tmp_path / "landing").mkdir()
    with SFTPTestServer(str(tmp_path / "landing"), deny_rename=True) as server:
        with pytest.raises(UploadError, match="rename"):
            deliver_to(server, result.path, tmp_path)
    assert not os.path.exists(AttachmentState.path_for(str(tmp_path / "state"), "uat"))
    again = export_with_attachments(tmp_path, api, FakeStorage(api), now=SECOND_CYCLE)
    assert {entry.status for entry in again.attachments} == {"NEW"}


def test_the_next_cycle_sends_only_what_is_new(tmp_path):
    """The controlled test set: after a delivered cycle, add one attachment;
    the next cycle holds exactly that file, and its count and bytes match."""
    api = AttachmentApi()
    first = export_with_attachments(tmp_path, api, FakeStorage(api))
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server:
        deliver_to(server, first.path, tmp_path)

        new_file = b"%PDF-1.7 added between cycles" * 3
        api.files[A6] = {"record": R3, "name": "added.pdf", "content": new_file}
        header, rows = api.data["Master Well Data"]
        rows[2][3:5] = [A6, "added.pdf"]
        api.api_calls.clear()
        second = export_with_attachments(tmp_path, api, FakeStorage(api), now=SECOND_CYCLE)
        deliver_to(server, second.path, tmp_path)

    status = {entry.attachment_id: entry for entry in second.attachments}
    assert status[A6].status == "NEW"
    assert {status[a].status for a in (A1, A2, A3, A4, A5)} == {"EARLIER"}
    assert status[A1].delivered_in == first.folder and status[A1].file.startswith(f"{ATTACHMENTS_DIR}/")
    sent = os.listdir(landing_root / second.folder / ATTACHMENTS_DIR)
    assert len(sent) == 1
    assert sum(os.path.getsize(landing_root / second.folder / ATTACHMENTS_DIR / n) for n in sent) == len(new_file)
    assert api.api_calls == [("list", R3)]   # nothing asked about what UAT already has


def test_an_undelivered_cycle_does_not_count_as_delivered(tmp_path):
    api = AttachmentApi()
    export_with_attachments(tmp_path, api, FakeStorage(api))
    second = export_with_attachments(tmp_path, api, FakeStorage(api), now=SECOND_CYCLE)
    assert {entry.status for entry in second.attachments} == {"NEW"}


def test_full_snapshot_sends_everything_again(tmp_path):
    api = AttachmentApi()
    first = export_with_attachments(tmp_path, api, FakeStorage(api))
    with SFTPTestServer(str(tmp_path)) as server:
        deliver_to(server, first.path, tmp_path)
    again = export_with_attachments(tmp_path, api, FakeStorage(api), now=SECOND_CYCLE, full_snapshot=True)
    assert {entry.status for entry in again.attachments} == {"NEW"}
    assert len(os.listdir(os.path.join(again.path, ATTACHMENTS_DIR))) == 5


def test_a_failed_attachment_is_tried_again_next_cycle(tmp_path):
    api = AttachmentApi()
    storage = FakeStorage(api)
    storage.failing[A1] = 99
    first = export_with_attachments(tmp_path, api, storage)
    with SFTPTestServer(str(tmp_path)) as server:
        deliver_to(server, first.path, tmp_path)
    second = export_with_attachments(tmp_path, api, FakeStorage(api), now=SECOND_CYCLE)
    assert [entry.attachment_id for entry in second.attachments if entry.status == "NEW"] == [A1]


def test_tagged_cycles_keep_their_own_state(tmp_path):
    api = AttachmentApi()
    dev = export_with_attachments(tmp_path, api, FakeStorage(api), tag="dev")
    with SFTPTestServer(str(tmp_path)) as server:
        deliver_to(server, dev.path, tmp_path)
    real = export_with_attachments(tmp_path, api, FakeStorage(api), now=SECOND_CYCLE)
    assert {entry.status for entry in real.attachments} == {"NEW"}   # dev deliveries don't count
    assert os.path.isfile(AttachmentState.path_for(str(tmp_path / "state"), "uat", "dev"))


def test_a_cycle_made_for_uat_is_refused_by_production(tmp_path):
    api = AttachmentApi()
    for_uat = export_with_attachments(tmp_path, api, FakeStorage(api))
    snapshot = export_with_attachments(tmp_path, api, FakeStorage(api), now=SECOND_CYCLE, full_snapshot=True)
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server:
        with pytest.raises(DeliveryError, match="PROD would miss files"):
            deliver_to(server, for_uat.path, tmp_path, env="prod")
        assert server.events == []
        deliver_to(server, snapshot.path, tmp_path, env="prod")   # a full snapshot is fine anywhere
    assert (landing_root / snapshot.folder / SUCCESS_NAME).is_file()


def test_an_interrupted_delivery_resumes_inside_the_attachments_folder(tmp_path):
    api = AttachmentApi()
    result = export_with_attachments(tmp_path, api, FakeStorage(api))
    local_dir = os.path.join(result.path, ATTACHMENTS_DIR)
    intact, cut = sorted(os.listdir(local_dir))[:2]
    remote_dir = tmp_path / "landing" / result.folder / ATTACHMENTS_DIR
    remote_dir.mkdir(parents=True)
    with open(os.path.join(local_dir, intact), "rb") as fh:
        (remote_dir / intact).write_bytes(fh.read())
    (remote_dir / cut).write_bytes(b"cut")

    with SFTPTestServer(str(tmp_path / "landing")) as server:
        delivery = deliver_to(server, result.path, tmp_path)
    assert f"{ATTACHMENTS_DIR}/{intact}" in delivery.kept
    assert f"{ATTACHMENTS_DIR}/{cut}" in delivery.uploaded
    assert sorted(os.listdir(remote_dir)) == sorted(os.listdir(local_dir))
    assert all(os.path.getsize(remote_dir / n) == os.path.getsize(os.path.join(local_dir, n)) for n in os.listdir(local_dir))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def write_config(tmp_path, server):
    config = {
        "fulcrum": {"api_token": "test-token"},
        "export": {"staging_dir": str(tmp_path / "staging"), "batch_size": 10, "state_dir": str(tmp_path / "state")},
        "sftp": {
            "host": "127.0.0.1", "port": server.port, "timeout_sec": 5, "host_key_fingerprint": server.fingerprint,
            "accounts": {"uat": {"username": server.username, "password": server.password, "remote_dir": "."}},
        },
    }
    path = tmp_path / "config.yaml"
    path.write_text(yaml.safe_dump(config), encoding="utf-8")
    return str(path)


@pytest.fixture
def cli_fakes(monkeypatch):
    api = AttachmentApi()
    storage = FakeStorage(api)
    monkeypatch.setattr(cli, "FulcrumClient", lambda token, base_url=None: make_client(api))
    monkeypatch.setattr(cli, "Downloader", lambda: downloader_for(storage))
    return api, storage


def test_run_downloads_delivers_and_reports(tmp_path, cli_fakes, capsys):
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server:
        code = cli.main(["run", "--config", write_config(tmp_path, server), "--tag", "dev"])
    out = capsys.readouterr().out
    assert code == 0, out
    assert "attachments: 5 new (" in out
    assert "5 attachments recorded as delivered" in out
    [folder] = os.listdir(landing_root)
    assert len(os.listdir(landing_root / folder / ATTACHMENTS_DIR)) == 5


def test_run_exits_1_when_an_attachment_failed_but_still_delivers(tmp_path, cli_fakes, capsys):
    _api, storage = cli_fakes
    storage.failing[A1] = 99
    landing_root = tmp_path / "landing"
    landing_root.mkdir()
    with SFTPTestServer(str(landing_root)) as server:
        code = cli.main(["run", "--config", write_config(tmp_path, server), "--tag", "dev"])
    out = capsys.readouterr().out
    assert code == 1
    assert f"FAIL attachment {A1}" in out and "the next cycle tries them again" in out
    [folder] = os.listdir(landing_root)
    assert (landing_root / folder / SUCCESS_NAME).is_file()


def test_attachments_command_counts_without_downloading(tmp_path, cli_fakes, capsys):
    api, storage = cli_fakes
    client = make_client(api)
    cycle = export_cycle(client, build_plan(client, log=quiet), Namer(), str(tmp_path / "staging"),
                         batch_size=10, log=quiet, now=FIXED_NOW).path   # tables only, no attachment step
    with SFTPTestServer(str(tmp_path)) as server:
        config = write_config(tmp_path, server)
    code = cli.main(["attachments", "--config", config, "--cycle", cycle])
    out = capsys.readouterr().out
    total = sum(len(f["content"]) for f in api.files.values())
    assert code == 0, out
    assert "attachments referenced: 5, in 3 records of 2 apps" in out
    assert f"ready in Fulcrum: 5, {total:,} bytes" in out
    assert "its next cycle downloads 5" in out
    assert storage.requests == []                    # nothing downloaded
    assert not (tmp_path / "state").exists()         # no state touched


# ---------------------------------------------------------------------------
# Names and paths
# ---------------------------------------------------------------------------

def test_attachment_file_names():
    assert Namer().attachment_file("wellhead_seal_testing", R4, A5, "s.s elk#33 void test fail.xlsx") \
        == f"wellhead_seal_testing__{R4}__{A5}.xlsx"
    named = Namer({"attachment_file": "{app}__{record_id}__{attachment_id}__{name}{ext}"})
    assert named.attachment_file("app", R1, A1, "s.s elk#33 void test fail.xlsx") \
        == f"app__{R1}__{A1}__s.s_elk_33_void_test_fail.xlsx"
    assert named.attachment_file("app", R1, A1, "no extension") == f"app__{R1}__{A1}__no_extension"
    assert named.attachment_file("app", R1, A1, "weird.ext with space").endswith("__weird.ext_with_space")


@pytest.mark.parametrize("template", [
    "{app}__{attachment_id}{ext}",               # no record: acceptance criterion 4
    "{app}/{record_id}__{attachment_id}{ext}",   # path separator
    "{app}__{record_id}__{attachment_id}{bogus}",
])
def test_bad_attachment_templates_are_rejected(template):
    with pytest.raises(NamingError):
        Namer({"attachment_file": template})


def test_long_paths_get_the_extended_form_only_on_windows():
    deep = "D:\\staging\\" + "x" * 250 + "\\file.pdf"
    assert long_path(deep, windows=True) == "\\\\?\\" + deep
    assert long_path("\\\\server\\share\\" + "x" * 250, windows=True).startswith("\\\\?\\UNC\\server\\share\\")
    assert long_path("D:\\staging\\short.pdf", windows=True) == "D:\\staging\\short.pdf"
    assert long_path("/tmp/" + "x" * 300, windows=False) == "/tmp/" + "x" * 300
